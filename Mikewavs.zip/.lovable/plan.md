
# Linkable Asset: The Independent Music Marketing Stack 2026

## Why this format

Editorial link magnets in the music-business niche tend to be one of three shapes: original data reports, free tools, or **opinionated curated directories**. Curated directories are the fastest to ship and the most repeatedly citable — newsletters, blog roundups, and Reddit threads link to "the best X stack" posts for years.

Mikewavs already has the credibility (real client list, working rollout builder, existing artist-resource library) to publish an authoritative one. This is also defensible: an outsider can't fake the opinions on which CRM works for music, why Linkfire beats Linktree for releases, etc.

## What gets built

A new resource page at **`/resources/music-marketing-stack`** (new top-level `resources` section so it doesn't dilute `/blog` or `/tools`). One long, scannable page with:

1. **Intro** — what "the stack" means and how Mike picks tools (criteria: owns data, scales with team, works with music).
2. **Sections (the actual link bait):**
   - Smart links & pre-saves (Linkfire, Feature.fm, Toneden)
   - Distribution (DistroKid, UnitedMasters, Stem, The Orchard, AWAL)
   - CRM & email (Klaviyo, Beehiiv, ConvertKit, Mailchimp)
   - SMS (Community, Laylo, SuperPhone)
   - Website platforms (Webflow, Framer, Wordpress, Shopify, Squarespace)
   - Ads & paid (Meta Ads Manager, TikTok Ads, Chartmetric for targeting)
   - Analytics (GA4, Chartmetric, Songstats, Plausible)
   - Merch & e-comm (Shopify, Big Cartel, Fourthwall)
   - Content & creative (CapCut, Splice, Notion, Frame.io)
   - AI / new (Suno for ideation, ChatGPT for copy, Claude for strategy)
3. **Per-tool card**: logo (optional), one-line verdict, "best for", "skip if", price band, link.
4. **"Mikewavs default stack"** box — opinionated pick of one tool per category. This is what gets screenshotted and shared.
5. **"Last updated"** date — visible, with a commitment to quarterly refresh. Freshness signals matter for both link-worthiness and rankings.
6. **CTA** to the rollout builder + consultation.

## SEO + GEO hooks

- `head()` with title "The Independent Music Marketing Stack (2026) — Mikewavs", description, canonical, og.
- JSON-LD: `ItemList` (each tool as a `ListItem` with `SoftwareApplication` or `Thing`), plus `BreadcrumbList` (Home → Resources → Music Marketing Stack), plus an `Article` block authored by Mike Wavs.
- Anchor links per section so the page can be cited deep ("the CRM section of Mikewavs' stack").
- Add to `public/llms.txt` and the dynamic sitemap (priority 0.9, monthly changefreq).
- Internal links: every relevant blog post (release checklist, EPK, fanbase, artist websites) gets a "See the full stack" link to this page; this page links out to relevant service pages.

## Outreach plan (outside the build, called out so it's not forgotten)

The page itself is not the win — the win is what you do after publish. Plan deliverables I won't build but will note in the page footer / README:
1. Submit to /r/WeAreTheMusicMakers, /r/musicmarketing, Indie Hackers.
2. Email pitch to: Hypebot, Music Ally, Bandzoogle blog, DIY Musician, Cherie Hu's Water & Music, The Future of Music newsletter (and the other names in your existing newsletters post — pitch reciprocal links).
3. LinkedIn + IG carousel of "Mikewavs default stack" → drives the screenshot share loop.

## Out of scope (will not do this round)

- Original-data report (would need to anonymize rollout-builder lead data — separate decision).
- Filterable JS gallery / search (adds complexity; v1 is a long static page).
- Logos for every tool (legal/asset overhead; v1 is text-first, can add logos in v2).
- Touching any existing pages' design.

## Files & code (technical detail)

- New route: `src/routes/resources.music-marketing-stack.tsx` with `head()` exporting all SEO metadata + JSON-LD.
- New data module: `src/lib/marketing-stack-data.ts` (categories + tools array, easy to update quarterly).
- New layout: reuse existing `glass-card` patterns and typography — no new components, no new fonts, no new colors.
- Update: `src/routes/sitemap[.]xml.ts` (add the route), `public/llms.txt` (add a "Resources" section), and 4 existing blog posts (`how-to-promote-your-music`, `music-release-checklist`, `how-to-build-a-fanbase`, `electronic-press-kit-guide`) get one inline link to the new page.
- No new npm packages.

## What I need from you to start

1. **Confirm the URL**: `/resources/music-marketing-stack` (new `/resources` section), or fold it under `/blog/music-marketing-stack`? New section is better for link bait; blog is simpler.
2. **Tool list veto/additions**: I'll draft the 60–80 tools across the 10 categories above using my best judgment of what Mike actually recommends. You can mark up the draft before I write final copy, or just trust me and edit after.
