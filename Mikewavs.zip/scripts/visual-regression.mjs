#!/usr/bin/env node
// Simple visual regression harness.
// Usage:
//   node scripts/visual-regression.mjs update   # write baselines
//   node scripts/visual-regression.mjs check    # diff against baselines (exit 1 on regression)
// Env: BASE_URL (default http://localhost:5173), THRESHOLD (0..1, default 0.1), MAX_DIFF (% default 0.5)
import { chromium } from "playwright";
import pixelmatch from "pixelmatch";
import { PNG } from "pngjs";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { existsSync } from "node:fs";
import path from "node:path";

const BASE_URL = process.env.BASE_URL ?? "http://localhost:5173";
const THRESHOLD = Number(process.env.THRESHOLD ?? 0.1);
const MAX_DIFF_PCT = Number(process.env.MAX_DIFF ?? 0.5);

const ROOT = path.resolve(path.dirname(new URL(import.meta.url).pathname), "..");
const BASELINE_DIR = path.join(ROOT, "tests/visual/baselines");
const ACTUAL_DIR = path.join(ROOT, "tests/visual/actual");
const DIFF_DIR = path.join(ROOT, "tests/visual/diffs");

const TARGETS = [
  { name: "home-desktop", path: "/", width: 1440, height: 900 },
  { name: "home-mobile", path: "/", width: 390, height: 844 },
  { name: "services-web-desktop", path: "/services/web", width: 1440, height: 900 },
  { name: "rollout-builder-desktop", path: "/tools/music-rollout-builder", width: 1440, height: 900 },
  { name: "contact-desktop", path: "/contact", width: 1440, height: 900 },
  { name: "blog-index-desktop", path: "/blog", width: 1440, height: 900 },
];

const HIDE_DYNAMIC_CSS = `
  *, *::before, *::after {
    animation: none !important;
    transition: none !important;
    caret-color: transparent !important;
  }
  [data-anim] { opacity: 1 !important; transform: none !important; }
  .animate-marquee, .animate-marquee-reverse, .animate-pulse-glow { animation: none !important; }
  video, iframe { visibility: hidden !important; }
`;

async function capture(browser, target) {
  const context = await browser.newContext({
    viewport: { width: target.width, height: target.height },
    deviceScaleFactor: 1,
    reducedMotion: "reduce",
  });
  const page = await context.newPage();
  const url = new URL(target.path, BASE_URL).toString();
  await page.goto(url, { waitUntil: "networkidle", timeout: 60_000 });
  await page.addStyleTag({ content: HIDE_DYNAMIC_CSS });
  await page.evaluate(() => document.fonts && document.fonts.ready);
  await page.waitForTimeout(400);
  const buf = await page.screenshot({ fullPage: true, animations: "disabled", caret: "hide" });
  await context.close();
  return buf;
}

async function ensureDirs(mode) {
  await mkdir(BASELINE_DIR, { recursive: true });
  await mkdir(ACTUAL_DIR, { recursive: true });
  if (mode === "check") await mkdir(DIFF_DIR, { recursive: true });
}

async function update() {
  const browser = await chromium.launch();
  try {
    for (const target of TARGETS) {
      const buf = await capture(browser, target);
      await writeFile(path.join(BASELINE_DIR, `${target.name}.png`), buf);
      console.log(`baseline  ${target.name}  (${buf.length} bytes)`);
    }
  } finally {
    await browser.close();
  }
}

async function check() {
  const browser = await chromium.launch();
  const failures = [];
  try {
    for (const target of TARGETS) {
      const baselinePath = path.join(BASELINE_DIR, `${target.name}.png`);
      if (!existsSync(baselinePath)) {
        console.warn(`skip      ${target.name}  (no baseline — run 'update' first)`);
        continue;
      }
      const actualBuf = await capture(browser, target);
      await writeFile(path.join(ACTUAL_DIR, `${target.name}.png`), actualBuf);
      const baseline = PNG.sync.read(await readFile(baselinePath));
      const actual = PNG.sync.read(actualBuf);
      if (baseline.width !== actual.width || baseline.height !== actual.height) {
        failures.push(target.name);
        console.log(`FAIL      ${target.name}  size ${actual.width}x${actual.height} vs baseline ${baseline.width}x${baseline.height}`);
        continue;
      }
      const { width, height } = baseline;
      const diff = new PNG({ width, height });
      const mismatched = pixelmatch(baseline.data, actual.data, diff.data, width, height, {
        threshold: THRESHOLD,
        includeAA: false,
      });
      const pct = (mismatched / (width * height)) * 100;
      const ok = pct <= MAX_DIFF_PCT;
      console.log(`${ok ? "ok       " : "FAIL     "} ${target.name}  ${mismatched} px (${pct.toFixed(3)}%)`);
      if (!ok) {
        await writeFile(path.join(DIFF_DIR, `${target.name}.png`), PNG.sync.write(diff));
        failures.push(target.name);
      }
    }
  } finally {
    await browser.close();
  }
  if (failures.length) {
    console.error(`\n${failures.length} visual regression(s). See tests/visual/diffs/.`);
    process.exit(1);
  }
}

const mode = process.argv[2];
await ensureDirs(mode);
if (mode === "update") await update();
else if (mode === "check") await check();
else {
  console.error("Usage: node scripts/visual-regression.mjs <update|check>");
  process.exit(2);
}
