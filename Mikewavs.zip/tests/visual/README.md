# Visual regression

Lightweight screenshot diffing to catch accidental color/layout regressions across the main pages. Powered by Playwright + pixelmatch.

## One-time setup

Install the Chromium runtime Playwright drives:

    bunx playwright install chromium

## Workflow

1. Start the dev server: `bun run dev` (defaults to http://localhost:5173).
2. Capture baselines when the design is in a known-good state:

       bun run visual:update

   Commit the PNGs in `tests/visual/baselines/`.

3. After future design tweaks, run:

       bun run visual:check

   The script exits non-zero if any page differs by more than `MAX_DIFF` % of pixels (default 0.5%). Failing pages get a pixel-diff PNG in `tests/visual/diffs/` and the rendered page in `tests/visual/actual/` (both gitignored).

## Configuration

| Var         | Default                 | Meaning                                   |
| ----------- | ----------------------- | ----------------------------------------- |
| `BASE_URL`  | http://localhost:5173   | Server to screenshot                      |
| `THRESHOLD` | 0.1                     | pixelmatch per-pixel YIQ threshold (0..1) |
| `MAX_DIFF`  | 0.5                     | Max % of differing pixels allowed         |

Edit the `TARGETS` array in `scripts/visual-regression.mjs` to add/remove pages or viewports.

## Captured pages

- `/` at 1440x900 and 390x844
- `/services/web` at 1440x900
- `/tools/music-rollout-builder` at 1440x900
- `/contact` at 1440x900
- `/blog` at 1440x900

Animations, marquees, carets, and `<video>`/`<iframe>` content are suppressed via injected CSS so diffs stay deterministic. Re-run `visual:update` and commit fresh baselines whenever an intentional design change lands.
