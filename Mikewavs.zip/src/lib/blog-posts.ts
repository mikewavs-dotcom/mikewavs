export type Section =
  | { type: "p"; text: string }
  | { type: "h2"; text: string }
  | { type: "h3"; text: string }
  | { type: "ul"; items: string[] }
  | { type: "ol"; items: string[] };

export type RelatedLink =
  | { kind: "post"; slug: string }
  | { kind: "service"; slug: string }
  | { kind: "resource"; slug: string };

export type BlogPost = {
  slug: string;
  title: string;
  metaTitle: string;
  description: string;
  category: string;
  published: string;
  readingTime: string;
  eyebrow: string;
  h1: string;
  intro: string;
  sections: Section[];
  tags?: string[];
  relatedLinks?: RelatedLink[];
};

import { siteUrl } from "@/lib/site";

export const BLOG_BASE = siteUrl("/blog");

export const posts: BlogPost[] = [
  {
    slug: "how-to-promote-your-music",
    title: "How to Promote Your Music in 2026",
    metaTitle: "How to Promote Your Music in 2026: A Strategist's Playbook",
    description:
      "A working playbook from a music digital strategist: how to promote your music in 2026 across owned channels, social, playlisting, and ads — without burning your budget.",
    category: "Marketing",
    published: "2026-04-28",
    readingTime: "9 min read",
    eyebrow: "Guide · Digital Strategy",
    h1: "How to Promote Your Music in 2026: A Strategist's Playbook",
    intro:
      "Most artists promote music the wrong way around — they start with the platforms (Spotify, TikTok, Instagram) and end with the system (website, email, CRM). This guide flips it. We'll walk through what actually works to promote your music in 2026, in the order a strategist would build it.",
    sections: [
      { type: "h2", text: "1. Start with owned channels, not platforms" },
      {
        type: "p",
        text: "Every dollar you spend driving attention to a rented platform (Spotify, IG, TikTok) loses value the second the algorithm changes. Before you promote anything, make sure you own the destination: an artist website, an email list, and ideally SMS. That's where promotion compounds.",
      },
      {
        type: "ul",
        items: [
          "A real artist site with EPK, music, tour, store, and a single capture form",
          "Email tool (Beehiiv, Mailchimp, Klaviyo) with a welcome sequence",
          "Linkfire or Feature.fm smart links so you keep first-party data on every click",
        ],
      },
      { type: "h2", text: "2. Build the rollout around one campaign goal" },
      {
        type: "p",
        text: "Pick one number per release — first-week saves, email signups, ticket pre-sales, merch sold. Every post, ad, and asset for the next 6–8 weeks gets evaluated against that number. Without a goal you're just posting.",
      },
      { type: "h2", text: "3. Earned + paid social, in that order" },
      {
        type: "p",
        text: "Spend the first two weeks of a rollout testing organic short-form content (Reels, TikTok, Shorts). The clips that overperform organically are the ones you put paid budget behind. Boosting average content is the fastest way to waste money.",
      },
      { type: "h3", text: "What to test" },
      {
        type: "ul",
        items: [
          "Studio / process clips with hook-first captions",
          "Visualizer cuts (5–15s) of the strongest moment in the song",
          "Talking-head context — why this song exists",
          "Fan-facing posts that ask a question, not announce a date",
        ],
      },
      { type: "h2", text: "4. Playlisting: real, not pay-for-play" },
      {
        type: "p",
        text: "Use SubmitHub or Groover for honest curator outreach, pitch your distributor for editorial, and ignore anything promising guaranteed adds. Algorithmic playlists (Discover Weekly, Release Radar) are downstream of save rate, so your job is making your existing fans save the song in week one.",
      },
      { type: "h2", text: "5. Paid media — only after the song proves itself" },
      {
        type: "p",
        text: "Run a small Meta test ($5–10/day) against a Linkfire smart link once you have 2–3 creatives with strong organic signal. Track cost-per-click and cost-per-stream conversion in the smart link dashboard. If a creative beats $0.20 CPC consistently, scale it.",
      },
      { type: "h2", text: "6. Close the loop with CRM" },
      {
        type: "p",
        text: "Every campaign should add measurable subscribers to email/SMS. That's the asset that makes the next release cheaper to promote. Without it, you're starting from zero every single time.",
      },
      { type: "h2", text: "The order matters" },
      {
        type: "p",
        text: "Owned → goal → organic → playlisting → paid → CRM. Most artists invert it and wonder why nothing sticks.",
      },
    ],
    tags: [
      "music marketing",
      "release strategy",
      "direct to fan",
      "artist promotion",
    ],
    relatedLinks: [
      { kind: "post", slug: "music-release-checklist" },
      { kind: "post", slug: "how-to-build-a-fanbase" },
      { kind: "service", slug: "artist-label-marketing" },
      { kind: "resource", slug: "music-marketing-stack" },
    ],
  },
  {
    slug: "electronic-press-kit-guide",
    title: "How to Build an EPK That Books Shows",
    metaTitle: "How to Build an Electronic Press Kit (EPK) That Actually Books Shows",
    description:
      "A music strategist's guide to building an electronic press kit (EPK) that actually gets responses from venues, festivals, sync supervisors, and press in 2026.",
    category: "Branding",
    published: "2026-05-06",
    readingTime: "7 min read",
    eyebrow: "Guide · Branding",
    h1: "How to Build an Electronic Press Kit (EPK) That Actually Books Shows",
    intro:
      "An electronic press kit is the artist version of a sales page. If yours is a Google Drive folder of PDFs, you're losing bookings to artists with worse music and better EPKs. Here's what to include, what to cut, and how to host it.",
    sections: [
      { type: "h2", text: "What an EPK is for" },
      {
        type: "p",
        text: "An EPK answers one question for a venue booker, festival programmer, sync supervisor, or journalist: 'Is this artist worth my time?' They will spend 90 seconds on the page. Everything below the fold needs to justify the first 90 seconds.",
      },
      { type: "h2", text: "The 7 sections every EPK needs" },
      {
        type: "ol",
        items: [
          "Hero — name, genre tag, hero photo, one-sentence positioning, latest release CTA",
          "Music — embedded player (Spotify, SoundCloud, or self-hosted) with the strongest 3 songs",
          "Bio — short (50 words) and long (250 words) versions side by side",
          "Press quotes & coverage — 4–6 logos with pull quotes linking to the source",
          "Live — recent shows, capacity numbers if flattering, a 60-second live video",
          "Stats — monthly listeners, IG/TikTok followers, email list size, top markets",
          "Contact — booking, management, press, sync — separate emails, not a single 'info@'",
        ],
      },
      { type: "h2", text: "What to cut" },
      {
        type: "ul",
        items: [
          "Auto-playing video or audio. Lethal.",
          "Walls of paragraph text with no headings",
          "Outdated stats (anything older than 3 months reads as inactive)",
          "Generic stock-photo backgrounds and lyric-video screenshots",
        ],
      },
      { type: "h2", text: "Where to host it" },
      {
        type: "p",
        text: "Host the EPK on your own domain at /epk. A dedicated page (not a downloadable PDF) means you can update stats and press without re-sending files, and you can track which contacts actually opened it. PDFs are fine as a downloadable backup — never as the main version.",
      },
      { type: "h2", text: "Updating cadence" },
      {
        type: "p",
        text: "Refresh the EPK every release cycle and after any meaningful press hit, new tour announce, or milestone (1M streams, festival add, sync placement). Set a calendar reminder — most artists update theirs twice in their career.",
      },
    ],
    tags: ["electronic press kit", "epk", "artist branding", "music bookings"],
    relatedLinks: [
      { kind: "post", slug: "artist-website-examples" },
      { kind: "post", slug: "how-to-promote-your-music" },
      { kind: "service", slug: "website-digital-setup" },
      { kind: "resource", slug: "music-marketing-stack" },
    ],
  },
  {
    slug: "artist-website-examples",
    title: "12 Artist Website Examples Worth Stealing From",
    metaTitle: "12 Artist Website Examples Worth Stealing From (2026)",
    description:
      "Twelve artist website examples that get direct-to-fan strategy right — what to copy, what to skip, and the structural moves that turn visitors into subscribers.",
    category: "Web Design",
    published: "2026-05-13",
    readingTime: "8 min read",
    eyebrow: "Reference · Web Design",
    h1: "12 Artist Website Examples Worth Stealing From (2026)",
    intro:
      "Most artist websites are a Linktree with a custom domain. The artists below treat their site as the center of their business — store, EPK, mailing list, tour calendar, and release archive in one place. Here's what to steal from each.",
    sections: [
      { type: "h2", text: "What separates a great artist site from a bad one" },
      {
        type: "p",
        text: "Before the list — the pattern every site below shares: a single primary action above the fold (subscribe, pre-save, buy ticket), real photography (not vendor stock), a fast load on mobile, and a clear store / tour / music split in the nav. Everything else is decoration.",
      },
      { type: "h2", text: "The 12" },
      {
        type: "ol",
        items: [
          "Bon Iver — manifesto-style hero, store + tour above the fold",
          "Tame Impala — long-scroll editorial layout, all news in one feed",
          "Charli XCX (BRAT) — the case study in committing to one visual identity sitewide",
          "Tyler, the Creator — clean grid of eras, store integrated into the navigation",
          "Frank Ocean (blonded) — minimal nav, content does the work",
          "FKA twigs — gallery-first, slow reveals, treats the site like a portfolio",
          "Phoebe Bridgers — store-led, no hero video, subscription CTA on every page",
          "Arctic Monkeys — tour-led design, instant ticket access",
          "Mac DeMarco — bedroom-aesthetic done intentionally, not as a shortcut",
          "Vince Staples — joke-first copy, dead-simple navigation",
          "Mitski — newsletter-led, treats fans like readers, not followers",
          "ROSALÍA — full-bleed art direction, language toggle for global audience",
        ],
      },
      { type: "h2", text: "Structural moves to copy" },
      {
        type: "ul",
        items: [
          "Email capture above the fold AND in the footer — the most common signup point varies by visitor",
          "Store and Tour as top-level nav items, not buried under 'More'",
          "A dedicated /epk page even if you don't link it publicly — share the URL with bookers",
          "Press / quotes on the home page, not a separate buried route",
          "Smart links (Linkfire/Feature.fm) for every release so analytics survive a platform change",
        ],
      },
      { type: "h2", text: "Things to skip" },
      {
        type: "ul",
        items: [
          "Hero video autoplay (kills mobile load, kills SEO)",
          "Hamburger-only nav on desktop — make the main routes visible",
          "'Latest tweet' embeds",
          "Splash-page intros before the actual home page",
        ],
      },
    ],
    tags: ["artist websites", "web design", "direct to fan", "music"],
    relatedLinks: [
      { kind: "post", slug: "electronic-press-kit-guide" },
      { kind: "post", slug: "how-to-build-a-fanbase" },
      { kind: "service", slug: "website-digital-setup" },
    ],
  },
  {
    slug: "how-to-build-a-fanbase",
    title: "How to Build a Real Fanbase",
    metaTitle: "How to Build a Real Fanbase Without Going Viral",
    description:
      "A direct-to-fan strategist's guide to building a real, durable music fanbase — how the math works, what to focus on per follower tier, and the systems that compound.",
    category: "Direct-to-Fan",
    published: "2026-05-20",
    readingTime: "7 min read",
    eyebrow: "Strategy · Direct-to-Fan",
    h1: "How to Build a Real Fanbase Without Going Viral",
    intro:
      "Going viral isn't a strategy. The artists with stable careers built fanbases the same way for the last 20 years: a small group of real fans, then systems that turn casual listeners into that small group, on repeat. Here's how the math actually works.",
    sections: [
      { type: "h2", text: "The 1,000 true fans math, updated" },
      {
        type: "p",
        text: "Kevin Kelly's number still holds — a thousand fans paying $100/year is a $100K/year career. In music in 2026, that $100 is realistic: an album on vinyl, two tickets, a t-shirt. The question isn't whether the model works, it's whether you have a system to find and keep those 1,000 people.",
      },
      { type: "h2", text: "Focus by tier" },
      { type: "h3", text: "0 – 1,000 monthly listeners" },
      {
        type: "p",
        text: "Your job is consistency, not reach. Release on a schedule (every 6–10 weeks), capture every contact (email + SMS) from your site and shows, and reply to every DM. Nothing else.",
      },
      { type: "h3", text: "1,000 – 10,000 monthly listeners" },
      {
        type: "p",
        text: "Add structure: a release calendar, basic ads ($5–10/day) on your best-performing organic content, a merch drop tied to each release, and your first proper EPK so you can book real rooms.",
      },
      { type: "h3", text: "10,000+" },
      {
        type: "p",
        text: "Now you're running a business. CRM segmentation (superfans vs casual), VIP/membership tier, paid playlisting tests, and a manager-led rollout playbook. The work changes from creating attention to converting it.",
      },
      { type: "h2", text: "The three systems that compound" },
      {
        type: "ol",
        items: [
          "Email/SMS list — the only audience the algorithm can't take from you",
          "Content engine — a repeatable format you can ship weekly without burning out",
          "Release cadence — predictable drops train both fans and the algorithm",
        ],
      },
      { type: "h2", text: "What to stop doing" },
      {
        type: "ul",
        items: [
          "Buying followers or streams — destroys the per-follower engagement that algorithms reward",
          "Posting daily without a format — burnout content reads as desperation",
          "Treating Spotify monthly listeners as a fanbase metric (it's a reach metric, not a loyalty one)",
        ],
      },
    ],
    tags: ["fanbase", "direct to fan", "music marketing", "crm"],
    relatedLinks: [
      { kind: "post", slug: "how-to-promote-your-music" },
      { kind: "post", slug: "music-industry-newsletters" },
      { kind: "service", slug: "fan-capture-crm" },
      { kind: "resource", slug: "music-marketing-stack" },
    ],
  },
  {
    slug: "music-release-checklist",
    title: "The Music Release Checklist",
    metaTitle: "The Music Release Checklist: 8 Weeks Out to Drop Day",
    description:
      "A complete music release checklist: every step from 8 weeks out to release day, built around how a digital strategist actually runs an indie or label rollout.",
    category: "Releases",
    published: "2026-05-27",
    readingTime: "6 min read",
    eyebrow: "Checklist · Releases",
    h1: "The Music Release Checklist: 8 Weeks Out to Drop Day",
    intro:
      "This is the actual checklist we run with Mikewavs clients — independent artists and small labels — for a single or EP release. Adjust dates for a full album (add 4 weeks); the structure stays the same.",
    sections: [
      { type: "h2", text: "8 weeks out — pre-production" },
      {
        type: "ul",
        items: [
          "Final masters and metadata locked",
          "Cover art delivered in print and digital sizes",
          "Distributor upload (DistroKid, UnitedMasters, Symphonic, etc.) scheduled",
          "Smart link (Linkfire / Feature.fm) created for pre-save",
          "Content shoot booked — visualizer, BTS, vertical clips",
        ],
      },
      { type: "h2", text: "6 weeks out — assets" },
      {
        type: "ul",
        items: [
          "All vertical clips edited (10–15 of them, not 3)",
          "Press release and EPK updated with the new song",
          "Pre-save link tested on iOS + Android + desktop",
          "Email and SMS subscribers tagged for this rollout",
        ],
      },
      { type: "h2", text: "4 weeks out — announce" },
      {
        type: "ul",
        items: [
          "Announce post with cover art, date, pre-save link",
          "Editorial pitch to distributor (3 weeks minimum before release)",
          "Curator outreach via SubmitHub / Groover starts",
          "First email to list — exclusive snippet or behind-the-scenes",
        ],
      },
      { type: "h2", text: "2 weeks out — pressure" },
      {
        type: "ul",
        items: [
          "Daily short-form content from the shoot",
          "Paid test ($5–10/day) on the highest-performing organic clip",
          "Tour / show announces aligned to release week if possible",
          "Second email — pre-save reminder + the story behind the song",
        ],
      },
      { type: "h2", text: "Release week" },
      {
        type: "ol",
        items: [
          "Monday: warm-up post, last pre-save push",
          "Wednesday: short visualizer or lyric clip drops",
          "Friday (release day): full visualizer, smart link post, email + SMS blast, story takeover",
          "Saturday/Sunday: react-to-fans content, repost the best fan posts",
        ],
      },
      { type: "h2", text: "Week +1 — momentum" },
      {
        type: "ul",
        items: [
          "Scale paid budget behind whichever creative converted in week one",
          "Pitch any earned editorial / press now (algorithmic playlists are still warm)",
          "Capture stats for the post-mortem doc (saves, listeners, signups, sales)",
          "Schedule next release announce within 4 weeks to keep cadence",
        ],
      },
      { type: "h2", text: "The point of the checklist" },
      {
        type: "p",
        text: "Rollouts fail because of missing steps, not bad songs. A boring checklist that you actually run beats a brilliant strategy you forget halfway through.",
      },
    ],
    tags: ["music release", "release checklist", "rollout", "release marketing"],
    relatedLinks: [
      { kind: "post", slug: "how-to-promote-your-music" },
      { kind: "post", slug: "electronic-press-kit-guide" },
      { kind: "service", slug: "creative-direction-project-management" },
      { kind: "resource", slug: "music-marketing-stack" },
    ],
  },
  {
    slug: "music-industry-newsletters",
    title: "Best Music Industry Newsletters",
    metaTitle: "Best Music Industry Newsletters for Artists & Managers (2026)",
    description:
      "A curated guide to the music industry newsletters artists, managers, and labels actually read — for digital strategy, release marketing, and fan growth.",
    category: "Resources",
    published: "2026-05-30",
    readingTime: "6 min read",
    eyebrow: "Guide · Digital Strategy",
    h1: "The Best Music Industry Newsletters for Artists & Managers",
    intro: "",
    sections: [],
    tags: ["music industry newsletters", "music business", "resources"],
    relatedLinks: [
      { kind: "post", slug: "how-to-build-a-fanbase" },
      { kind: "post", slug: "how-to-promote-your-music" },
      { kind: "service", slug: "artist-label-marketing" },
    ],
  },
  {
    slug: "music-pr-for-independent-artists",
    title: "Music PR for Independent Artists",
    metaTitle: "Music PR for Independent Artists: What Actually Works in 2026",
    description:
      "A working music PR guide for independent artists: what publicists actually do, when to hire one, how to pitch yourself, and how to measure if PR is working.",
    category: "Marketing",
    published: "2026-06-17",
    readingTime: "8 min read",
    eyebrow: "Guide · Music PR",
    h1: "Music PR for Independent Artists: What Actually Works",
    intro:
      "Most independent artists either skip music PR entirely or burn $2–5k on a publicist before they're ready to use the coverage. This guide cuts through both — what music PR really is in 2026, when it's worth paying for, and how to DIY a credible push when you can't.",
    sections: [
      { type: "h2", text: "What music PR is — and what it isn't" },
      {
        type: "p",
        text: "Music PR is the work of placing your story in front of people who write about, program, or curate music. That's blogs, magazines, Spotify and Apple editorial, radio shows, podcasts, tastemaker newsletters, and increasingly, individual TikTok and YouTube creators with engaged audiences. PR is not advertising — you don't pay for the placement, you earn it. And it's not playlist pitching for cheap Spotify adds — that's a separate (often shadier) hustle.",
      },
      {
        type: "p",
        text: "Good PR does three things for an independent artist: builds third-party credibility (someone other than you saying you're worth paying attention to), creates assets you can repurpose for months (quotes, screenshots, press page bullets), and opens doors with bookers, sync agents, and labels who pre-screen by press.",
      },
      { type: "h2", text: "When PR is worth paying for" },
      {
        type: "p",
        text: "Hiring a publicist makes sense when three things are true at the same time:",
      },
      {
        type: "ol",
        items: [
          "You have a real release window — a single, EP, album, or tour announce — 6 to 10 weeks out.",
          "Your music, visuals, and EPK are finished and on-brand. Publicists pitch the package you give them; a weak press kit cancels out a good pitch.",
          "You have somewhere to send the traffic. A live website with email capture, a working pre-save, and at least one merch or ticket SKU. Otherwise coverage converts to nothing.",
        ],
      },
      {
        type: "p",
        text: "If any of those three are missing, your money is better spent fixing them first. A $3,000 publicist pointing at a Linktree with no fan capture is the most common waste of money in the indie release cycle.",
      },
      { type: "h2", text: "How to pick a publicist (without getting scammed)" },
      { type: "h3", text: "Red flags" },
      {
        type: "ul",
        items: [
          "Guaranteed placements in specific outlets. Real publicists pitch — they don't guarantee.",
          "Flat 'press packages' under $500 with dozens of named blogs. These are usually mass-blasts to dead inboxes.",
          "No discoverable roster, no recent placements you can verify, no real bio.",
          "Pay-for-coverage language — 'sponsored review,' 'feature slot' — without 'sponsored' tagging on the published piece. That's not PR, that's an ad pretending to be press.",
        ],
      },
      { type: "h3", text: "Green flags" },
      {
        type: "ul",
        items: [
          "A roster you recognize at your tier (not Drake — artists 1–2 levels above you).",
          "Clarity on which 30–80 outlets they'll target and why, before you pay.",
          "Honest timelines: 4–6 week ramp, results 2–8 weeks after pitch, no 'viral' language.",
          "Reporting: a clean weekly recap of pitches sent, opens, replies, placements.",
        ],
      },
      { type: "h2", text: "DIY music PR: a 4-week sprint" },
      {
        type: "p",
        text: "If you can't afford a publicist yet, you can run a credible push yourself. It will not match a great publicist's contact book, but it will absolutely outperform doing nothing — and the muscle you build here makes you a better client later.",
      },
      { type: "h3", text: "Week 1 — assets and target list" },
      {
        type: "ul",
        items: [
          "Finalize your EPK: one paragraph bio (50 words), longer bio (150 words), high-res press photo, links to streams, two recent press mentions if you have them.",
          "Build a list of 30 specific contacts — not outlets. Real human names with real email addresses. Use Submithub sparingly, prefer Muck Rack, Twitter/IG bios, and newsletter mastheads.",
          "Group your list into three tiers: realistic (small blogs, niche newsletters), stretch (mid-tier publications in your genre), and dream (tier-1 outlets).",
        ],
      },
      { type: "h3", text: "Week 2 — write your pitch" },
      {
        type: "p",
        text: "Your pitch is one short email per contact. The structure: a one-line hook tied to why this specific writer would care, two lines of context (who you are, what's coming, why now), one private streaming link, EPK link, and a single ask. No attachments. No 'hope you're well.' No 'just wanted to follow up' as the entire body of a second email.",
      },
      { type: "h3", text: "Week 3 — send in waves" },
      {
        type: "ul",
        items: [
          "Send 10 pitches per day, three days running. Personalize the first line and the hook for every single one.",
          "Use a free tracker (Streak, Mixmax) so you can see opens.",
          "If a contact opens twice and doesn't reply within 5 business days, send one short follow-up. One. Not three.",
        ],
      },
      { type: "h3", text: "Week 4 — convert and repurpose" },
      {
        type: "ul",
        items: [
          "Every placement, no matter how small, gets screenshot, archived, and added to your press page.",
          "Pull quotes for IG carousels and your EPK.",
          "Reply to every writer who covered you with a thank-you and a soft offer for the next release.",
          "Update your email list with the wins — your existing fans are the most engaged audience for press hits.",
        ],
      },
      { type: "h2", text: "What to measure" },
      {
        type: "p",
        text: "Stop measuring PR by hype. Measure it by these four numbers across the rollout window:",
      },
      {
        type: "ul",
        items: [
          "Placements landed (target: 5–15 from a focused 30-contact list).",
          "Email signups attributed to press traffic (UTM your press page link).",
          "Streams added in the 7 days after major placements (compare week-over-week, not lifetime).",
          "Inbound DMs and inquiries from sync, booking, and label contacts.",
        ],
      },
      {
        type: "p",
        text: "If you're not capturing email or tracking UTMs, you can't actually tell whether PR is working — and you'll either re-up with a bad publicist or quit a good one too early.",
      },
      { type: "h2", text: "Where most independent rollouts leak" },
      {
        type: "p",
        text: "Across the rollouts we run at Mikewavs, the most common leak isn't bad pitches — it's the destination. A writer covers the artist, sends 800 readers to a Linktree, and 780 of them bounce because there's no clear next action. Before you spend on PR, make sure every press click hits a real artist site with one obvious next step: pre-save, email capture, or merch. That's what turns coverage into a fanbase instead of a screenshot for the grid.",
      },
    ],
    tags: ["music pr", "music marketing", "publicity", "independent artists"],
    relatedLinks: [
      { kind: "post", slug: "how-to-promote-your-music" },
      { kind: "post", slug: "electronic-press-kit-guide" },
      { kind: "service", slug: "artist-label-marketing" },
    ],
  },
  {
    slug: "how-to-build-an-artist-website",
    title: "How to Build a Professional Artist Website",
    metaTitle: "How to Build a Professional Artist Website in 2026",
    description:
      "A step-by-step guide to building a professional artist website: choosing a domain, picking the right platform, and structuring the essential pages musicians need.",
    category: "Web Design",
    published: "2026-06-19",
    readingTime: "9 min read",
    eyebrow: "Guide · Web Design",
    h1: "How to Build a Professional Artist Website in 2026",
    intro:
      "Inspiration is easy. Execution is what separates artists who own their audience from artists who rent it on social platforms. This guide walks you through building a professional artist website from scratch — domain, platform, pages, and the technical basics that make it work as a marketing tool.",
    sections: [
      { type: "h2", text: "What the site is actually for" },
      {
        type: "p",
        text: "Your website is not a digital business card. It is the one place online where you control the full experience, keep the data, and capture the relationship. Social platforms can change the rules tomorrow. Your website shouldn't.",
      },
      {
        type: "ul",
        items: [
          "Own your audience: email and SMS signups that you can export and use anywhere",
          "Sell directly: merch, tickets, and digital products without platform fees eating every margin",
          "Look credible to bookers, press, and sync supervisors in under 90 seconds",
          "Centralize your releases: one smart link, one press page, one store",
        ],
      },
      { type: "h2", text: "Step 1: Choose a domain you actually own" },
      {
        type: "p",
        text: "Your domain is your real estate. Buy it through a registrar you control — not bundled inside a website builder's 'free domain' upsell. If you ever leave the platform, you want to point that domain wherever you want.",
      },
      {
        type: "ul",
        items: [
          "Default to .com if it's available. Fans, bookers, and press expect it.",
          "If your artist name is taken, try add-ons like music, official, or the: yourname.com, yournameofficial.com, or theyourname.com.",
          "Avoid hyphens when possible. your-name.com is harder to say out loud and easier to misspell.",
          "Buy the matching handles on Instagram, TikTok, and YouTube before finalizing the name.",
        ],
      },
      { type: "h2", text: "Step 2: Pick a platform that fits your budget and skill" },
      {
        type: "p",
        text: "For most artists, the choice narrows to two platforms: Squarespace and Webflow. Both are production-quality, but they optimize for different users.",
      },
      {
        type: "h3",
        text: "Squarespace: best for artists who want to launch fast",
      },
      {
        type: "ul",
        items: [
          "Templates are polished out of the box and look good on mobile immediately",
          "Built-in blogging, store, email capture, and tour/event pages",
          "No code required; you can be live in a weekend",
          "Good for artists who want a clean, professional site without hiring help",
        ],
      },
      {
        type: "h3",
        text: "Webflow: best for artists who want custom design",
      },
      {
        type: "ul",
        items: [
          "Pixel-level control over layout, animation, and interactions",
          "Better for complex editorial designs or unconventional art direction",
          "Steeper learning curve, but the design ceiling is much higher",
          "Great if you have a designer or want to build something distinctive",
        ],
      },
      {
        type: "p",
        text: "Budget reality check: Squarespace is cheaper month-to-month and easier to maintain yourself. Webflow costs more and may need a designer or developer to unlock its value. If your site is mostly text, music, photos, and a store, start with Squarespace. If the visual identity is central to the brand, Webflow is worth the stretch.",
      },
      { type: "h2", text: "Step 3: Build the five essential pages" },
      {
        type: "p",
        text: "Most artist sites fail because they try to be everything. You need five pages that do specific jobs. Everything else is optional until these are perfect.",
      },
      {
        type: "ol",
        items: [
          "Home — one headline, one hero image, one primary action (subscribe, pre-save, or buy).",
          "Music — embedded players, release artwork, and a smart link for the latest drop.",
          "Tour / Shows — dates, ticket links, and a clear 'no shows' state when you're not touring.",
          "Store — merch, vinyl, and digital products with a simple checkout.",
          "Contact / EPK — separate emails for booking, press, and sync, plus a downloadable press kit.",
        ],
      },
      { type: "h2", text: "Step 4: Design for mobile first" },
      {
        type: "p",
        text: "More than half of artist site traffic comes from phones. If it looks broken or loads slowly on mobile, you lose the visitor before they hear anything.",
      },
      {
        type: "ul",
        items: [
          "Use a single-column layout on mobile. Side-by-side sections collapse badly.",
          "Compress images and videos. A hero video that autoplays in full quality will kill load time.",
          "Make buttons thumb-sized. Tiny links are frustrating to tap.",
          "Test the site on your actual phone, not just the browser preview.",
        ],
      },
      { type: "h2", text: "Step 5: Wire up email capture everywhere" },
      {
        type: "p",
        text: "Email is the only channel where you own the relationship. Every page should have a path to signup — not just a tiny footer link.",
      },
      {
        type: "ul",
        items: [
          "Put a signup form above the fold on the home page",
          "Offer something in return: a free download, early ticket access, or a behind-the-scenes track",
          "Tag subscribers by source (home page, store, tour page) so you can segment later",
          "Connect it to a real email tool: Beehiiv, Mailchimp, or Klaviyo",
        ],
      },
      { type: "h2", text: "Step 6: Add the technical basics" },
      {
        type: "p",
        text: "You don't need to be a developer, but you do need to check a few boxes so Google and social platforms can read your site properly.",
      },
      {
        type: "ul",
        items: [
          "Set a clear page title and meta description on every page",
          "Add Open Graph tags so links look good on Instagram, Twitter, and Messenger",
          "Submit your sitemap to Google Search Console once the site is live",
          "Connect Google Analytics or a privacy-friendly alternative to see what visitors actually do",
        ],
      },
      { type: "h2", text: "Launch checklist" },
      {
        type: "ol",
        items: [
          "Domain registered and pointed to the site",
          "SSL certificate active (https://, not http://)",
          "All five essential pages live and linked in the main navigation",
          "Email signup form tested on mobile and desktop",
          "Music players and smart links tested on iOS and Android",
          "Store checkout completed as a test order",
          "Contact form or email link working and monitored",
          "Google Search Console and analytics connected",
        ],
      },
      { type: "h2", text: "When to level up" },
      {
        type: "p",
        text: "A basic professional site will carry you from first release through your first headline run. Upgrade when you have real traffic and revenue to optimize: custom integrations, advanced analytics, a membership layer, or a full redesign around a new album era. Until then, the best site is the one that is live, fast, and collecting emails.",
      },
    ],
    tags: [
      "artist website",
      "web design",
      "musicians",
      "squarespace",
      "webflow",
      "direct to fan",
    ],
    relatedLinks: [
      { kind: "post", slug: "artist-website-examples" },
      { kind: "post", slug: "electronic-press-kit-guide" },
      { kind: "service", slug: "website-digital-setup" },
    ],
  },
];


export const postBySlug = (slug: string) => posts.find((p) => p.slug === slug);

const MONTHS_SHORT = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
const MONTHS_LONG = ["January","February","March","April","May","June","July","August","September","October","November","December"];

export function formatPostDate(iso: string, variant: "short" | "long" = "long") {
  const [y, m, d] = iso.split("-").map(Number);
  const months = variant === "short" ? MONTHS_SHORT : MONTHS_LONG;
  return `${months[m - 1]} ${d}, ${y}`;
}

export function wordCountFor(post: BlogPost): number {
  const chunks: string[] = [];
  if (post.intro) chunks.push(post.intro);
  for (const s of post.sections) {
    if (s.type === "p" || s.type === "h2" || s.type === "h3") chunks.push(s.text);
    else for (const it of s.items) chunks.push(it);
  }
  return chunks.join(" ").trim().split(/\s+/).filter(Boolean).length;
}