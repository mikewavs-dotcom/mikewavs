export type RolloutAnswers = {
  has_website: boolean;
  has_email_capture: boolean;
  has_sms_capture: boolean;
  has_crm: boolean;
  has_merch: boolean;
  has_content_plan: boolean;
  has_smart_link: boolean;
  has_tracking: boolean;
  has_post_release_plan: boolean;
};

type ItemKey = keyof RolloutAnswers;

export const ITEMS: { key: ItemKey; label: string; points: number; service?: string; whyItMatters: string; nextStep: string }[] = [
  { key: "has_website", label: "Website or landing page for this release", points: 15, service: "Website & Digital Setup", whyItMatters: "Without your own release page, you depend on platforms you don't control and have nowhere to send paid traffic, press, or fans who want more than a stream.", nextStep: "Build a release-specific landing page that captures fans and routes to streaming, merch, and follow-up." },
  { key: "has_email_capture", label: "Email capture set up", points: 15, service: "Fan Capture & CRM Systems", whyItMatters: "You are relying on social platforms without collecting owned fan data. Adding email capture helps you follow up with fans after release day.", nextStep: "Add an email capture flow tied to a real incentive (early access, unreleased music, merch discount)." },
  { key: "has_sms_capture", label: "SMS capture set up", points: 10, service: "Fan Capture & CRM Systems", whyItMatters: "SMS gets the highest open rates of any channel. Without it, you have no direct line to core fans on release day when algorithms decide who hears you.", nextStep: "Set up SMS opt-in to reach core fans on release day without depending on algorithms." },
  { key: "has_crm", label: "CRM or follow-up system", points: 15, service: "Fan Capture & CRM Systems", whyItMatters: "You may be getting attention, but there is no system to follow up with fans, buyers, or interested contacts after they engage.", nextStep: "Connect captured fans to a CRM with tagged segments and automated post-release follow-up." },
  { key: "has_merch", label: "Merch or offer ready", points: 10, service: "E-Commerce & Merch Support", whyItMatters: "Attention without an offer is wasted reach. If fans show up on release day and there's nothing to buy, you lose the highest-intent moment of the campaign.", nextStep: "Prepare at least one offer or merch drop so attention from the release converts into revenue." },
  { key: "has_content_plan", label: "Content plan for before and after the release", points: 15, service: "Social Media & Content Strategy", whyItMatters: "Releases die when content stops the day the song drops. Without a plan for the weeks before and after, momentum disappears in a few days.", nextStep: "Map a pre-release and post-release content calendar across short-form, long-form, and owned channels." },
  { key: "has_smart_link", label: "Pre-save, smart link, or music link hub", points: 10, whyItMatters: "Sending fans to one platform at a time costs you everyone using a different service. A smart link captures every destination in one place.", nextStep: "Create a single smart link / link hub that consolidates every destination tied to the release." },
  { key: "has_tracking", label: "Analytics, pixels, or tracking installed", points: 10, service: "Campaign Tracking & Analytics", whyItMatters: "You may not know which content, links, or campaigns are actually driving results, so you can't double down on what works or retarget warm fans.", nextStep: "Install Meta, TikTok, and Google pixels with event tracking so you can retarget warm fans and measure ROI." },
  { key: "has_post_release_plan", label: "Post-release follow-up plan", points: 10, service: "Creative Direction & Project Management", whyItMatters: "Most releases lose all momentum in the first two weeks because nothing is planned after launch day. The follow-up is where careers actually compound.", nextStep: "Plan the 30/60/90 days after release: email sequences, content cadence, retargeting, and the next offer." },
];

export const MAX_RAW = ITEMS.reduce((s, i) => s + i.points, 0);

export type Category = {
  range: string;
  headline: string;
  message: string;
};

export function getCategory(score: number): Category {
  if (score < 40) return {
    range: "0–39",
    headline: "Your rollout needs a system before you drop.",
    message: "You may have the music ready, but the digital setup around the release is missing key pieces. Without a capture system, follow-up, and clear landing page, you may lose fan attention after release day.",
  };
  if (score < 70) return {
    range: "40–69",
    headline: "You have momentum, but your system has gaps.",
    message: "You have some important pieces in place, but the rollout is not fully connected. Strengthening your website, fan capture, CRM, content plan, and tracking can help turn attention into owned audience growth.",
  };
  if (score < 90) return {
    range: "70–89",
    headline: "Your rollout is close, but it can be stronger.",
    message: "You have a solid foundation. A few improvements around follow-up, analytics, merch, or fan capture could help you get more value from the release.",
  };
  return {
    range: "90–100",
    headline: "Your rollout system is strong.",
    message: "You have most of the important pieces in place. The next step is tightening execution, tracking results, and making sure every fan touchpoint leads somewhere valuable.",
  };
}

export type ScoreResult = {
  score: number;
  raw: number;
  category: Category;
  have: { key: ItemKey; label: string }[];
  missing: { key: ItemKey; label: string; whyItMatters: string; nextStep: string }[];
  recommendedServices: string[];
};

export function computeScore(answers: RolloutAnswers): ScoreResult {
  let raw = 0;
  const have: ScoreResult["have"] = [];
  const missing: ScoreResult["missing"] = [];
  const services = new Set<string>();

  for (const item of ITEMS) {
    if (answers[item.key]) {
      raw += item.points;
      have.push({ key: item.key, label: item.label });
    } else {
      missing.push({ key: item.key, label: item.label, whyItMatters: item.whyItMatters, nextStep: item.nextStep });
      if (item.service) services.add(item.service);
    }
  }

  const score = Math.round((raw / MAX_RAW) * 100);
  return {
    score,
    raw,
    category: getCategory(score),
    have,
    missing,
    recommendedServices: Array.from(services),
  };
}