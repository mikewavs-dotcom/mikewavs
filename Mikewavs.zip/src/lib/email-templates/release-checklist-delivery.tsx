import * as React from 'react'
import {
  Body,
  Button,
  Container,
  Head,
  Heading,
  Hr,
  Html,
  Preview,
  Section,
  Text,
} from '@react-email/components'
import type { TemplateEntry } from './registry'

interface Props {
  downloadUrl?: string
}

const main = {
  backgroundColor: '#ffffff',
  fontFamily: 'Arial, Helvetica, sans-serif',
  color: '#111',
}
const container = { padding: '32px 24px', maxWidth: '560px', margin: '0 auto' }
const eyebrow = {
  fontSize: '11px',
  textTransform: 'uppercase' as const,
  letterSpacing: '0.18em',
  color: '#06b6d4',
  margin: '0 0 8px',
  fontWeight: 700,
}
const h1 = { fontSize: '24px', margin: '0 0 12px', lineHeight: '1.2', color: '#111' }
const p = { fontSize: '15px', lineHeight: '1.55', color: '#333', margin: '0 0 14px' }
const btn = {
  backgroundColor: '#06b6d4',
  color: '#ffffff',
  padding: '14px 24px',
  borderRadius: '999px',
  fontWeight: 700,
  fontSize: '14px',
  textDecoration: 'none',
  display: 'inline-block',
}
const small = { fontSize: '12px', color: '#888', margin: '16px 0 0', lineHeight: '1.5' }
const sig = { fontSize: '14px', color: '#111', margin: '20px 0 0' }

const Email = ({ downloadUrl = 'https://mikewavs.com/mikewavs-release-checklist.pdf' }: Props) => (
  <Html lang="en" dir="ltr">
    <Head />
    <Preview>Your Music Release Checklist (PDF) — 8 weeks out to drop day</Preview>
    <Body style={main}>
      <Container style={container}>
        <Text style={eyebrow}>Mikewavs · Field Notes</Text>
        <Heading style={h1}>Your Music Release Checklist</Heading>
        <Text style={p}>
          Here's the PDF — it's the same 8-week checklist we run with artist and label clients
          at Mikewavs. Print it, paste it in Notion, share it with your team.
        </Text>
        <Section style={{ margin: '20px 0 8px' }}>
          <Button href={downloadUrl} style={btn}>
            Download the PDF
          </Button>
        </Section>
        <Text style={small}>
          If the button doesn't work, copy and paste this link:<br />
          {downloadUrl}
        </Text>
        <Hr style={{ margin: '28px 0 20px', borderColor: '#e5e7eb' }} />
        <Text style={p}>
          You'll get the occasional field note from me when something's actually worth your inbox —
          rollout breakdowns, what's working in direct-to-fan, and the odd template. No spam.
        </Text>
        <Text style={sig}>— Mike</Text>
        <Text style={{ ...small, marginTop: '24px' }}>
          Mikewavs · Digital strategy for artists & labels · mikewavs.com
        </Text>
      </Container>
    </Body>
  </Html>
)

export const template = {
  component: Email,
  subject: 'Your Music Release Checklist (PDF)',
  displayName: 'Release Checklist — lead magnet delivery',
  previewData: {
    downloadUrl: 'https://mikewavs.com/mikewavs-release-checklist.pdf',
  },
} satisfies TemplateEntry