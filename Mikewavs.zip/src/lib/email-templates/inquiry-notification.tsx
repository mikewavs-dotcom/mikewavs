import * as React from 'react'
import {
  Body,
  Container,
  Head,
  Heading,
  Hr,
  Html,
  Preview,
  Section,
  Text,
} from '@react-email/components'
import type { TemplateEntry } from './registry'

interface Props {
  serviceName?: string
  name?: string
  email?: string
  company?: string | null
  role?: string | null
  phone?: string | null
  website?: string | null
  socials?: string | null
  budget?: string | null
  timeline?: string | null
  goals?: string
  currentSituation?: string | null
  additionalInfo?: string | null
}

const main = { backgroundColor: '#ffffff', fontFamily: 'Arial, Helvetica, sans-serif', color: '#111' }
const container = { padding: '24px', maxWidth: '640px', margin: '0 auto' }
const label = { fontSize: '12px', textTransform: 'uppercase' as const, letterSpacing: '0.08em', color: '#666', margin: '0 0 4px' }
const value = { fontSize: '14px', margin: '0 0 12px', color: '#111' }
const block = { padding: '12px 14px', border: '1px solid #e5e7eb', borderRadius: '8px', background: '#fafafa', whiteSpace: 'pre-wrap' as const, fontSize: '14px', lineHeight: '1.5' }
const h2 = { fontSize: '20px', margin: '0 0 4px' }
const sub = { fontSize: '13px', color: '#666', margin: '0 0 16px' }
const h3 = { fontSize: '14px', margin: '20px 0 6px', color: '#111' }

function Field({ k, v }: { k: string; v?: string | null }) {
  if (!v) return null
  return (
    <Section>
      <Text style={label}>{k}</Text>
      <Text style={value}>{v}</Text>
    </Section>
  )
}

const Email = (props: Props) => (
  <Html lang="en" dir="ltr">
    <Head />
    <Preview>New inquiry from {props.name || 'a visitor'}</Preview>
    <Body style={main}>
      <Container style={container}>
        <Heading style={h2}>New Mikewavs Inquiry</Heading>
        <Text style={sub}>{props.serviceName || 'General inquiry'}</Text>
        <Hr />
        <Field k="Name" v={props.name} />
        <Field k="Email" v={props.email} />
        <Field k="Company / Project" v={props.company} />
        <Field k="Role" v={props.role} />
        <Field k="Phone" v={props.phone} />
        <Field k="Website" v={props.website} />
        <Field k="Socials" v={props.socials} />
        <Field k="Budget" v={props.budget} />
        <Field k="Timeline" v={props.timeline} />
        {props.goals ? (
          <>
            <Text style={h3}>Goals</Text>
            <Text style={block}>{props.goals}</Text>
          </>
        ) : null}
        {props.currentSituation ? (
          <>
            <Text style={h3}>Current situation</Text>
            <Text style={block}>{props.currentSituation}</Text>
          </>
        ) : null}
        {props.additionalInfo ? (
          <>
            <Text style={h3}>Additional info</Text>
            <Text style={block}>{props.additionalInfo}</Text>
          </>
        ) : null}
        <Hr />
        <Text style={{ fontSize: '12px', color: '#888', marginTop: '12px' }}>
          Reply directly to {props.email || 'the sender'} to respond.
        </Text>
      </Container>
    </Body>
  </Html>
)

export const template = {
  component: Email,
  subject: (d: Record<string, any>) =>
    `New inquiry — ${d.serviceName || 'General'} — ${d.name || 'Unknown'}`,
  displayName: 'Inquiry Notification (admin)',
  to: 'mike@nocoolpoints.com',
  previewData: {
    serviceName: 'Direct-to-Fan Systems',
    name: 'Jane Artist',
    email: 'jane@example.com',
    company: 'Jane Music',
    role: 'Artist',
    budget: '$5k–$10k',
    timeline: '1–2 months',
    goals: 'Build out a fanbase CRM and launch first email campaign before my next release.',
    currentSituation: 'I have ~12k followers on IG and no email list.',
  },
} satisfies TemplateEntry