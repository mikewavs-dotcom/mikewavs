import * as React from 'react'
import {
  Body,
  Button,
  Container,
  Head,
  Heading,
  Hr,
  Html,
  Preview,
  Section,
  Text,
} from '@react-email/components'
import type { TemplateEntry } from './registry'

interface Props {
  name?: string
  score?: number
  categoryHeadline?: string
  categoryMessage?: string
  missing?: string[]
  recommendedServices?: string[]
  consultUrl?: string
  resultsUrl?: string
}

const main = {
  backgroundColor: '#ffffff',
  fontFamily: 'Arial, Helvetica, sans-serif',
  color: '#111',
}
const container = { padding: '32px 24px', maxWidth: '560px', margin: '0 auto' }
const eyebrow = {
  fontSize: '11px',
  textTransform: 'uppercase' as const,
  letterSpacing: '0.18em',
  color: '#D6A23A',
  margin: '0 0 8px',
  fontWeight: 700,
}
const h1 = { fontSize: '24px', margin: '0 0 12px', lineHeight: '1.2', color: '#111' }
const scoreBox = {
  border: '1px solid #e5e7eb',
  borderRadius: '12px',
  padding: '20px',
  margin: '16px 0 20px',
  textAlign: 'center' as const,
}
const scoreNum = { fontSize: '40px', fontWeight: 800, color: '#D6A23A', margin: '0', lineHeight: 1 }
const scoreLabel = {
  fontSize: '11px',
  textTransform: 'uppercase' as const,
  letterSpacing: '0.18em',
  color: '#666',
  margin: '8px 0 0',
  fontWeight: 700,
}
const p = { fontSize: '15px', lineHeight: '1.55', color: '#333', margin: '0 0 14px' }
const sectionLabel = {
  fontSize: '11px',
  textTransform: 'uppercase' as const,
  letterSpacing: '0.16em',
  color: '#111',
  margin: '20px 0 8px',
  fontWeight: 700,
}
const li = { fontSize: '14px', lineHeight: '1.5', color: '#333', margin: '0 0 6px' }
const btn = {
  backgroundColor: '#D6A23A',
  color: '#ffffff',
  padding: '14px 24px',
  borderRadius: '999px',
  fontWeight: 700,
  fontSize: '14px',
  textDecoration: 'none',
  display: 'inline-block',
}
const small = { fontSize: '12px', color: '#888', margin: '16px 0 0', lineHeight: '1.5' }
const sig = { fontSize: '14px', color: '#111', margin: '20px 0 0' }

const Email = ({
  name = 'there',
  score = 0,
  categoryHeadline = 'Your Rollout Score',
  categoryMessage = '',
  missing = [],
  recommendedServices = [],
  consultUrl = 'https://calendly.com/nocoolpoints/1-1-consultation',
  resultsUrl = 'https://mikewavs.com/tools/music-rollout-builder',
}: Props) => {
  const topMissing = missing.slice(0, 3)
  return (
    <Html lang="en" dir="ltr">
      <Head />
      <Preview>{`Your Music Rollout Score: ${score}/100 — ${categoryHeadline}`}</Preview>
      <Body style={main}>
        <Container style={container}>
          <Text style={eyebrow}>Mikewavs · Rollout Score</Text>
          <Heading style={h1}>Hey {name} — here's your score</Heading>

          <Section style={scoreBox}>
            <Text style={scoreNum}>{`${score}/100`}</Text>
            <Text style={scoreLabel}>{categoryHeadline}</Text>
          </Section>

          {categoryMessage ? <Text style={p}>{categoryMessage}</Text> : null}

          {topMissing.length > 0 && (
            <>
              <Text style={sectionLabel}>Top {topMissing.length} things to fix first</Text>
              {topMissing.map((m, i) => (
                <Text key={i} style={li}>• {m}</Text>
              ))}
            </>
          )}

          {recommendedServices.length > 0 && (
            <>
              <Text style={sectionLabel}>Where Mikewavs can help</Text>
              {recommendedServices.map((s, i) => (
                <Text key={i} style={li}>• {s}</Text>
              ))}
            </>
          )}

          <Section style={{ margin: '24px 0 8px' }}>
            <Button href={consultUrl} style={btn}>
              Book a free 15-min strategy call
            </Button>
          </Section>
          <Text style={small}>
            Or revisit your full breakdown here:<br />
            {resultsUrl}
          </Text>

          <Hr style={{ margin: '28px 0 20px', borderColor: '#e5e7eb' }} />
          <Text style={p}>
            I'll walk through your weakest area on the call and map out what to fix before
            your next release — no pitch, just useful.
          </Text>
          <Text style={sig}>— Mike</Text>
          <Text style={{ ...small, marginTop: '24px' }}>
            Mikewavs · Digital strategy for artists & labels · mikewavs.com
          </Text>
        </Container>
      </Body>
    </Html>
  )
}

export const template = {
  component: Email,
  subject: (d: Record<string, any>) =>
    `Your Music Rollout Score: ${d.score ?? 0}/100`,
  displayName: 'Rollout Score — results email',
  previewData: {
    name: 'Jordan',
    score: 62,
    categoryHeadline: 'You have a foundation — now tighten it',
    categoryMessage: "You're past the basics, but a few gaps are leaking fans before they convert.",
    missing: ['Email capture', 'CRM follow-up sequence', 'Post-release plan'],
    recommendedServices: ['Website + Digital Setup', 'Campaign Tracking & Analytics'],
    consultUrl: 'https://calendly.com/nocoolpoints/1-1-consultation',
    resultsUrl: 'https://mikewavs.com/tools/music-rollout-builder',
  },
} satisfies TemplateEntry