import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const subscribeSchema = z.object({
  email: z.string().trim().toLowerCase().email().max(200),
  source: z.string().trim().max(120).optional().nullable(),
  // honeypot — must be empty
  hp: z.string().max(200).optional().nullable(),
  formLoadedAt: z.number().int().nonnegative().optional().nullable(),
});

const LEAD_MAGNET = "music-release-checklist";
const PDF_PATH = "/mikewavs-release-checklist.pdf";
const SENDER_DOMAIN = "notify.mikewavs.com";
const FROM = "Mikewavs <noreply@mikewavs.com>";
const MIN_FILL_MS = 1500;

async function hashIp(ip: string | null): Promise<string | null> {
  if (!ip) return null;
  const salt = process.env.CONTACT_IP_SALT || "mikewavs-contact-v1";
  const buf = new TextEncoder().encode(`${salt}:${ip}`);
  const digest = await crypto.subtle.digest("SHA-256", buf);
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

function generateUnsubToken(): string {
  const bytes = new Uint8Array(32);
  crypto.getRandomValues(bytes);
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

export const subscribeToList = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => subscribeSchema.parse(data))
  .handler(async ({ data }) => {
    // Honeypot → silent success.
    if (data.hp && data.hp.trim().length > 0) {
      return { ok: true };
    }
    if (data.formLoadedAt) {
      const elapsed = Date.now() - data.formLoadedAt;
      if (elapsed >= 0 && elapsed < MIN_FILL_MS) {
        return { ok: true };
      }
    }

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { getRequestHeader } = await import("@tanstack/react-start/server");

    const rawIp =
      getRequestHeader("cf-connecting-ip") ||
      getRequestHeader("x-real-ip") ||
      (getRequestHeader("x-forwarded-for")?.split(",")[0].trim() ?? null);
    const ipHash = await hashIp(rawIp);

    // Rate limit (IP + email). Fail-closed: if the RPC errors, refuse the
    // submission so the limiter can't be bypassed by induced errors.
    const { data: limitReason, error: limitError } = await supabaseAdmin.rpc(
      "check_subscriber_rate_limit",
      { _ip_hash: ipHash ?? "", _email: data.email },
    );
    if (limitError) {
      console.error("[subscribeToList] rate-limit check failed", limitError);
      throw new Error("We couldn't process your signup right now. Please try again in a moment.");
    }
    if (limitReason) {
      throw new Error(
        "You've signed up a few times recently. Please wait a bit before trying again.",
      );
    }

    // Hardcoded origin — never derive from request headers (Host header injection
    // would let an attacker control the link embedded in subscriber emails).
    const downloadUrl = `https://mikewavs.com${PDF_PATH}`;

    // Upsert subscriber (case-insensitive unique on email). Tag with source on first sight.
    const { data: existing } = await supabaseAdmin
      .from("email_subscribers")
      .select("id, lead_magnet")
      .ilike("email", data.email)
      .maybeSingle();

    if (!existing) {
      const { error: insertError } = await supabaseAdmin
        .from("email_subscribers")
        .insert({
          email: data.email,
          source: data.source ?? null,
          lead_magnet: LEAD_MAGNET,
          ip_hash: ipHash,
        });
      if (insertError) {
        console.error("[subscribeToList] insert failed", insertError);
        // Don't surface DB error to user — still try to send the email.
      }
    }

    // Check suppression — if user previously unsubscribed, do not send.
    const { data: suppressed } = await supabaseAdmin
      .from("suppressed_emails")
      .select("id")
      .eq("email", data.email)
      .maybeSingle();

    if (suppressed) {
      return { ok: true, emailSent: false, reason: "suppressed" as const };
    }

    // Render the React Email template + enqueue via Lovable Emails.
    try {
      const React = await import("react");
      const { render } = await import("@react-email/components");
      const { template } = await import("@/lib/email-templates/release-checklist-delivery");

      const templateData = { downloadUrl };
      const element = React.createElement(template.component, templateData);
      const html = await render(element);
      const text = await render(element, { plainText: true });
      const rawSubject = template.subject as string | ((d: Record<string, any>) => string);
      const subject =
        typeof rawSubject === "function" ? rawSubject(templateData) : rawSubject;

      // Idempotency: one delivery per email per magnet. Repeat submits don't double-send.
      const idempotencyKey = `${LEAD_MAGNET}-${data.email}`;
      const messageId = crypto.randomUUID();

      // Get or create an unsubscribe token (required by the email API).
      const normalizedEmail = data.email.toLowerCase();
      let unsubscribeToken: string;
      const { data: existingToken } = await supabaseAdmin
        .from("email_unsubscribe_tokens")
        .select("token, used_at")
        .eq("email", normalizedEmail)
        .maybeSingle();
      if (existingToken && !existingToken.used_at) {
        unsubscribeToken = existingToken.token;
      } else {
        unsubscribeToken = generateUnsubToken();
        await supabaseAdmin
          .from("email_unsubscribe_tokens")
          .upsert(
            { token: unsubscribeToken, email: normalizedEmail },
            { onConflict: "email", ignoreDuplicates: true },
          );
        const { data: storedToken } = await supabaseAdmin
          .from("email_unsubscribe_tokens")
          .select("token")
          .eq("email", normalizedEmail)
          .maybeSingle();
        if (storedToken?.token) unsubscribeToken = storedToken.token;
      }

      await supabaseAdmin.from("email_send_log").insert({
        message_id: messageId,
        template_name: "release-checklist-delivery",
        recipient_email: data.email,
        status: "pending",
      });

      const { error: enqueueError } = await supabaseAdmin.rpc("enqueue_email", {
        queue_name: "transactional_emails",
        payload: {
          message_id: messageId,
          to: data.email,
          from: FROM,
          sender_domain: SENDER_DOMAIN,
          subject,
          html,
          text,
          purpose: "transactional",
          label: "release-checklist-delivery",
          idempotency_key: idempotencyKey,
          unsubscribe_token: unsubscribeToken,
          queued_at: new Date().toISOString(),
        } as any,
      });

      if (enqueueError) {
        console.error("[subscribeToList] enqueue failed", enqueueError);
        return { ok: true, emailSent: false };
      }

      return { ok: true, emailSent: true };
    } catch (err) {
      console.error("[subscribeToList] email error", err);
      return { ok: true, emailSent: false };
    }
  });