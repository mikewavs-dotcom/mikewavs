import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { computeScore, type RolloutAnswers, type ScoreResult } from "./rollout-scoring";

const CONSULT_URL = "https://calendly.com/nocoolpoints/1-1-consultation";
const RESULTS_URL = "https://mikewavs.com/tools/music-rollout-builder";
const SENDER_DOMAIN = "notify.mikewavs.com";
const FROM = "Mikewavs <noreply@mikewavs.com>";
const LEAD_MAGNET = "music-rollout-builder";
const MIN_FILL_MS = 3000;

async function hashIp(ip: string | null): Promise<string | null> {
  if (!ip) return null;
  const salt = process.env.CONTACT_IP_SALT || "mikewavs-contact-v1";
  const buf = new TextEncoder().encode(`${salt}:${ip}`);
  const digest = await crypto.subtle.digest("SHA-256", buf);
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

function generateUnsubToken(): string {
  const bytes = new Uint8Array(32);
  crypto.getRandomValues(bytes);
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

const submitSchema = z.object({
  name: z.string().trim().min(1, "Name is required").max(120),
  email: z.string().trim().email("Enter a valid email").max(255),
  artist_company_name: z.string().trim().min(1, "Artist or company name is required").max(160),
  role: z.string().trim().min(1, "Role is required").max(80),
  release_type: z.string().trim().min(1, "Release type is required").max(80),
  release_date: z.string().trim().max(20).optional().nullable(),
  main_goal: z.string().trim().min(1, "Main goal is required").max(80),
  has_website: z.boolean(),
  has_email_capture: z.boolean(),
  has_sms_capture: z.boolean(),
  has_crm: z.boolean(),
  has_merch: z.boolean(),
  has_content_plan: z.boolean(),
  has_smart_link: z.boolean(),
  has_tracking: z.boolean(),
  has_post_release_plan: z.boolean(),
  // Anti-spam: honeypot must be empty; formLoadedAt is client epoch ms used to
  // reject impossibly-fast submissions. Neither is persisted.
  hp: z.string().max(200).optional().nullable(),
  formLoadedAt: z.number().int().nonnegative().optional().nullable(),
});

export type SubmitRolloutInput = z.infer<typeof submitSchema>;

export const submitRolloutLead = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => submitSchema.parse(data))
  .handler(async ({ data }): Promise<ScoreResult> => {
    // 1. Honeypot — silently return a "success" with a zeroed score so bots
    //    can't tell they were blocked. They won't see the email either.
    if (data.hp && data.hp.trim().length > 0) {
      console.warn("[submitRolloutLead] honeypot tripped");
      return computeScore({
        has_website: data.has_website,
        has_email_capture: data.has_email_capture,
        has_sms_capture: data.has_sms_capture,
        has_crm: data.has_crm,
        has_merch: data.has_merch,
        has_content_plan: data.has_content_plan,
        has_smart_link: data.has_smart_link,
        has_tracking: data.has_tracking,
        has_post_release_plan: data.has_post_release_plan,
      });
    }

    // 2. Min time-to-submit — reject impossibly-fast submits.
    if (data.formLoadedAt) {
      const elapsed = Date.now() - data.formLoadedAt;
      if (elapsed >= 0 && elapsed < MIN_FILL_MS) {
        console.warn("[submitRolloutLead] sub-min-fill submit", { elapsed });
        throw new Error("Please take a moment to review your answers before submitting.");
      }
    }

    const answers: RolloutAnswers = {
      has_website: data.has_website,
      has_email_capture: data.has_email_capture,
      has_sms_capture: data.has_sms_capture,
      has_crm: data.has_crm,
      has_merch: data.has_merch,
      has_content_plan: data.has_content_plan,
      has_smart_link: data.has_smart_link,
      has_tracking: data.has_tracking,
      has_post_release_plan: data.has_post_release_plan,
    };

    const result = computeScore(answers);

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { getRequestHeader } = await import("@tanstack/react-start/server");

    // 3. Rate limit (IP + email). IPs are hashed with a server-side salt
    //    before being stored or queried. Fail-closed: if the RPC errors,
    //    refuse the submission so the limiter can't be bypassed by induced errors.
    const rawIp =
      getRequestHeader("cf-connecting-ip") ||
      getRequestHeader("x-real-ip") ||
      (getRequestHeader("x-forwarded-for")?.split(",")[0].trim() ?? null);
    const ipHash = await hashIp(rawIp);

    const { data: limitReason, error: limitError } = await supabaseAdmin.rpc(
      "check_rollout_rate_limit",
      { _ip_hash: ipHash ?? "", _email: data.email },
    );
    if (limitError) {
      console.error("[submitRolloutLead] rate-limit check failed", limitError);
      throw new Error("We couldn't process your submission right now. Please try again in a moment.");
    }
    if (limitReason) {
      throw new Error(
        "You've submitted the rollout builder a few times recently. Please wait a bit before trying again.",
      );
    }

    const { error } = await supabaseAdmin.from("music_rollout_leads").insert({
      name: data.name,
      email: data.email,
      artist_company_name: data.artist_company_name,
      role: data.role,
      release_type: data.release_type,
      release_date: data.release_date ? data.release_date : null,
      main_goal: data.main_goal,
      score: result.score,
      score_category: result.category.headline,
      ...answers,
      missing_items: result.missing.map((m) => m.label),
      recommended_services: result.recommendedServices,
      ip_hash: ipHash,
    });

    if (error) {
      console.error("[submitRolloutLead] insert failed", error);
      throw new Error("Could not save your submission. Please try again.");
    }

    // Fire-and-forget: store as subscriber + send results email.
    // Failures here must NOT break the user's score reveal.
    try {
      await deliverRolloutEmail({
        email: data.email,
        name: data.name,
        result,
      });
    } catch (err) {
      console.error("[submitRolloutLead] email delivery error", err);
    }

    return result;
  });

async function deliverRolloutEmail({
  email,
  name,
  result,
}: {
  email: string;
  name: string;
  result: ScoreResult;
}) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const normalizedEmail = email.toLowerCase();

  // Upsert subscriber so rollout leads also feed the newsletter list.
  const { data: existing } = await supabaseAdmin
    .from("email_subscribers")
    .select("id")
    .ilike("email", email)
    .maybeSingle();

  if (!existing) {
    await supabaseAdmin.from("email_subscribers").insert({
      email,
      source: "rollout-tool",
      lead_magnet: LEAD_MAGNET,
    });
  }

  // Honor suppression list.
  const { data: suppressed } = await supabaseAdmin
    .from("suppressed_emails")
    .select("id")
    .eq("email", email)
    .maybeSingle();

  if (suppressed) return;

  const React = await import("react");
  const { render } = await import("@react-email/components");
  const { template } = await import("@/lib/email-templates/rollout-score-delivery");

  const templateData = {
    name,
    score: result.score,
    categoryHeadline: result.category.headline,
    categoryMessage: result.category.message,
    missing: result.missing.map((m) => m.label),
    recommendedServices: result.recommendedServices,
    consultUrl: CONSULT_URL,
    resultsUrl: RESULTS_URL,
  };
  const element = React.createElement(template.component, templateData);
  const html = await render(element);
  const text = await render(element, { plainText: true });
  const rawSubject = template.subject as string | ((d: Record<string, any>) => string);
  const subject =
    typeof rawSubject === "function" ? rawSubject(templateData) : rawSubject;

  // Unsubscribe token.
  let unsubscribeToken: string;
  const { data: existingToken } = await supabaseAdmin
    .from("email_unsubscribe_tokens")
    .select("token, used_at")
    .eq("email", normalizedEmail)
    .maybeSingle();
  if (existingToken && !existingToken.used_at) {
    unsubscribeToken = existingToken.token;
  } else {
    unsubscribeToken = generateUnsubToken();
    await supabaseAdmin
      .from("email_unsubscribe_tokens")
      .upsert(
        { token: unsubscribeToken, email: normalizedEmail },
        { onConflict: "email", ignoreDuplicates: true },
      );
    const { data: storedToken } = await supabaseAdmin
      .from("email_unsubscribe_tokens")
      .select("token")
      .eq("email", normalizedEmail)
      .maybeSingle();
    if (storedToken?.token) unsubscribeToken = storedToken.token;
  }

  // Idempotency: one delivery per email per score-tier. Retakes resend a fresh
  // breakdown only when the score category actually changes.
  const idempotencyKey = `rollout-${normalizedEmail}-${result.score}`;
  const messageId = crypto.randomUUID();

  await supabaseAdmin.from("email_send_log").insert({
    message_id: messageId,
    template_name: "rollout-score-delivery",
    recipient_email: email,
    status: "pending",
  });

  const { error: enqueueError } = await supabaseAdmin.rpc("enqueue_email", {
    queue_name: "transactional_emails",
    payload: {
      message_id: messageId,
      to: email,
      from: FROM,
      sender_domain: SENDER_DOMAIN,
      subject,
      html,
      text,
      purpose: "transactional",
      label: "rollout-score-delivery",
      idempotency_key: idempotencyKey,
      unsubscribe_token: unsubscribeToken,
      queued_at: new Date().toISOString(),
    } as any,
  });

  if (enqueueError) {
    console.error("[deliverRolloutEmail] enqueue failed", enqueueError);
  }
}