import { Megaphone, Globe, Layers, Database, BarChart3, ShoppingBag, Sparkles, type LucideIcon } from "lucide-react";

export type Service = {
  n: string;
  slug: string;
  icon: LucideIcon;
  t: string;
  d: string;
  long: string;
  outcomes: string[];
  includes: string[];
  process: { step: string; detail: string }[];
  faq: { q: string; a: string }[];
};

export const CONSULT_URL = "https://calendly.com/nocoolpoints/1-1-consultation?month=2026-06";

export const services: Service[] = [
  {
    n: "01",
    slug: "artist-label-marketing",
    icon: Megaphone,
    t: "Artist & Label Marketing",
    d: "Stronger digital campaigns around releases, content, fan growth, audience development, and direct-to-fan engagement.",
    long: "End-to-end marketing direction for artists and labels who want releases to land with structure, not luck. We build the campaign system around the music — from pre-save and announce phase through release week and post-release momentum — so every asset, ad, and post is pointed at a real outcome.",
    outcomes: [
      "Clear release rollout from announce to post-drop",
      "Audience growth tied to owned channels, not just streams",
      "Stronger conversion from listener to engaged fan",
      "A repeatable marketing playbook across releases",
    ],
    includes: [
      "Release campaign strategy & calendar",
      "Content & creative direction per phase",
      "Paid media direction (Meta, TikTok, YouTube)",
      "Pre-save, links, and landing page setup",
      "Weekly check-ins and reporting",
    ],
    process: [
      { step: "Audit", detail: "Review current rollout, audience, assets, and channels." },
      { step: "Strategy", detail: "Map the campaign by phase with goals and KPIs." },
      { step: "Build", detail: "Stand up pages, links, capture flows, and creative briefs." },
      { step: "Run & Report", detail: "Execute weekly, track results, optimize through release week." },
    ],
    faq: [
      { q: "Do you work with independent artists?", a: "Yes — independent artists, managers, and labels of any size." },
      { q: "Do you handle ad spend?", a: "We direct strategy and creative. Spend can be managed by your team or a partner." },
      { q: "How much does music marketing cost for independent artists?", a: "Engagements typically start in the low four figures per month for ongoing work and scale with scope. Single-release campaigns are quoted per project after a short discovery call." },
      { q: "What's the difference between organic music promotion and paid ads?", a: "Organic is the content, posts, and community work that earn attention for free. Paid ads put budget behind the assets that already work organically. You need both, in that order — paid behind weak creative wastes money." },
      { q: "How do I know if my release campaign is working?", a: "We set 1–2 measurable KPIs per release (saves, email signups, ticket pre-sales, merch sold) before the rollout starts and report against them weekly. Streams alone aren't enough signal." },
      { q: "Do I need a marketing team for my first release?", a: "No. Most first releases just need a clear rollout, a working capture system, and someone driving execution. A full team only makes sense once the audience and budget justify it." },
    ],
  },
  {
    n: "02",
    slug: "website-digital-setup",
    icon: Globe,
    t: "Website & Digital Setup",
    d: "Websites for artists, labels, podcasts, and entertainment brands — EPKs, merch, landing pages, email capture, booking links, and campaign pages.",
    long: "Your website is the home base for everything you own — fans, releases, merch, press, bookings. We design and build fast, modern sites that double as marketing tools, not digital business cards.",
    outcomes: [
      "A premium site that reflects the brand",
      "Built-in fan capture and conversion tools",
      "One central hub for releases, merch, and press",
      "Easy to update as the project grows",
    ],
    includes: [
      "Custom design & responsive build",
      "EPK, bio, music, video, and press sections",
      "Email/SMS capture and CRM connection",
      "Merch, booking, and campaign landing pages",
      "Analytics, pixels, and SEO setup",
    ],
    process: [
      { step: "Discovery", detail: "Clarify goals, audience, brand voice, and required pages." },
      { step: "Design", detail: "Wireframes and a polished visual direction for approval." },
      { step: "Build", detail: "Develop, integrate tools, and stage for review." },
      { step: "Launch", detail: "Deploy, hand off training, and document the system." },
    ],
    faq: [
      { q: "What platforms do you build on?", a: "Wordpress, Framer, Shopify, or Webflow depending on needs." },
      { q: "Can you redesign my existing site?", a: "Yes — we can rebuild or evolve what you already have." },
      { q: "How long does an artist website take to build?", a: "Most builds land in 3–5 weeks from kickoff, depending on how many pages, integrations, and rounds of feedback are involved." },
      { q: "Do you set up email capture and the CRM too?", a: "Yes. Every site we build ships with email/SMS capture wired into a CRM (Klaviyo, Mailchimp, or similar) so fan data starts collecting on day one." },
    ],
  },
  {
    n: "03",
    slug: "social-media-content-strategy",
    icon: Layers,
    t: "Social Media & Content Strategy",
    d: "Content calendars, short-form strategy, posting systems, and platform direction for Instagram, TikTok, YouTube, X, and Snapchat.",
    long: "Stop posting reactively. We build a content system that ties every post back to growth, releases, and fan capture — with a calendar, formats, and a repeatable workflow your team can actually keep up with.",
    outcomes: [
      "A clear content calendar tied to goals",
      "Short-form formats designed to grow accounts",
      "Consistent posting without burnout",
      "Content that funnels back to owned channels",
    ],
    includes: [
      "Platform-by-platform strategy",
      "Content pillars and format library",
      "Monthly calendar and posting cadence",
      "Creative briefs for shoots and edits",
      "Performance review and iteration",
    ],
    process: [
      { step: "Audit", detail: "Review accounts, top content, and gaps." },
      { step: "Plan", detail: "Define pillars, formats, and calendar." },
      { step: "Produce", detail: "Brief, shoot, and edit on a repeatable cycle." },
      { step: "Optimize", detail: "Track what works monthly and adjust." },
    ],
    faq: [
      { q: "Do you produce content?", a: "We direct and brief. Production can be in-house or via partner creators." },
      { q: "Which platforms do you prioritize?", a: "Depends on the artist — usually IG, TikTok, and YouTube Shorts." },
      { q: "How often should an artist be posting?", a: "Short-form (Reels/TikTok/Shorts) 4–7 times a week during active rollouts, 2–3 times otherwise. Quality and hook matter more than raw volume." },
      { q: "How do I come up with content ideas without burning out?", a: "Work from a small set of repeatable formats — process clips, song breakdowns, fan-facing questions, performance moments — instead of inventing something new every post." },
    ],
  },
  {
    n: "04",
    slug: "fan-capture-crm",
    icon: Database,
    t: "Fan Capture & CRM Systems",
    d: "Systems that turn social media attention into owned fan data using email capture, SMS, forms, landing pages, and follow-up flows.",
    long: "Streams and follows are rented. Email, SMS, and fan data are owned. We build the capture layer and automation that turns spikes of attention into a permanent audience you can reach any time.",
    outcomes: [
      "An owned fan list that grows every release",
      "Automated welcome and release flows",
      "Higher conversion from social to email/SMS",
      "Cleaner data for targeting and merch",
    ],
    includes: [
      "CRM setup (Klaviyo, Mailchimp, Convert Kit, or similar)",
      "Landing pages and signup forms",
      "Welcome, release, and merch automations",
      "Segmentation and tagging strategy",
      "Compliance and deliverability setup",
    ],
    process: [
      { step: "Map", detail: "Define the fan journey and capture points." },
      { step: "Build", detail: "Stand up CRM, forms, and landing pages." },
      { step: "Automate", detail: "Launch welcome, release, and re-engagement flows." },
      { step: "Grow", detail: "Drive traffic from social and ads into capture." },
    ],
    faq: [
      { q: "Which CRM do you recommend?", a: "Depends on size and goals — usually Klaviyo or Convert Kit for music brands." },
      { q: "Will this work without ad spend?", a: "Yes, but paid traffic accelerates list growth significantly." },
      { q: "What's the difference between email and SMS for fans?", a: "Email is best for longer updates, story, and merch drops. SMS is best for time-sensitive moments (release day, ticket on-sales). Most artists need both, segmented." },
      { q: "How do I get fans to actually join my email list?", a: "Give a real reason — early access, unreleased music, ticket pre-sales, or a download. Generic 'join my newsletter' forms barely convert." },
    ],
  },
  {
    n: "05",
    slug: "campaign-tracking-analytics",
    icon: BarChart3,
    t: "Campaign Tracking & Analytics",
    d: "Pixels, UTMs, Google Analytics, and reporting dashboards so music teams can see what is working and make better marketing decisions.",
    long: "Most music teams fly blind. We install the tracking and reporting layer so every link, ad, and post is measurable — and decisions stop being guesses.",
    outcomes: [
      "Accurate tracking across paid and organic",
      "A reporting dashboard the whole team can read",
      "Better ROI on ads and content",
      "Data-backed decisions release after release",
    ],
    includes: [
      "Meta, TikTok, and Google pixel setup",
      "UTM strategy and link conventions",
      "GA4 and event configuration",
      "Looker/Sheets dashboards",
      "Weekly or campaign-level reporting",
    ],
    process: [
      { step: "Audit", detail: "Review current tracking and gaps." },
      { step: "Install", detail: "Set up pixels, UTMs, and events." },
      { step: "Dashboard", detail: "Build reports your team will actually use." },
      { step: "Report", detail: "Walk through results and next moves." },
    ],
    faq: [
      { q: "Do I need ads for this?", a: "No — tracking benefits organic and paid equally." },
      { q: "Can you train my team?", a: "Yes, every setup ends with a handoff and docs." },
      { q: "What's a UTM and why does it matter?", a: "A UTM is a tag added to a link that tells your analytics where the click came from. Without UTMs, traffic from Instagram, email, and ads all looks the same in reports." },
      { q: "Can you track streams and Spotify activity?", a: "Streaming platforms don't expose click-level data, but we track everything that drives to them — smart links, landing pages, ads, and email — so you can attribute what's working." },
    ],
  },
  {
    n: "06",
    slug: "ecommerce-merch-support",
    icon: ShoppingBag,
    t: "E-Commerce & Merch Support",
    d: "Shopify or website-based merch setups, payment systems, product pages, and cleaner buying experiences for fans.",
    long: "Merch should feel like part of the brand, not a bolted-on store. We build clean, fast shopping experiences that convert and connect to your CRM, ads, and releases.",
    outcomes: [
      "A merch store that matches the brand",
      "Higher conversion and average order value",
      "Connected to email/SMS for re-marketing",
      "Drop-ready setup for release moments",
    ],
    includes: [
      "Shopify store design & setup",
      "Product page templates and bundles",
      "Checkout, payments, and shipping config",
      "CRM and pixel integration",
      "Drop and release campaign playbooks",
    ],
    process: [
      { step: "Scope", detail: "Catalog, drops, and customer flow." },
      { step: "Design", detail: "Store look, product pages, and assets." },
      { step: "Build", detail: "Configure Shopify, payments, and apps." },
      { step: "Launch", detail: "Open the store and support the first drop." },
    ],
    faq: [
      { q: "Do you handle fulfillment?", a: "No — we connect to your fulfillment partner or POD service." },
      { q: "Can you migrate from another platform?", a: "Yes, including Big Cartel and custom setups." },
      { q: "Shopify or Big Cartel for an artist merch store?", a: "Big Cartel is fine for small, simple catalogs. Shopify scales better the moment you add bundles, variants, multiple drops, or want real marketing integrations." },
      { q: "How do I run a merch drop alongside a release?", a: "Time the store push to the same week as the single or album, gate first access to your email/SMS list, and run paid retargeting at site visitors who didn't buy. We build that playbook into every store setup." },
    ],
  },
  {
    n: "07",
    slug: "creative-direction-project-management",
    icon: Sparkles,
    t: "Creative Direction & Project Management",
    d: "Campaign organization, timelines, asset coordination, creative briefs, and rollout management so every launch feels clear and professional.",
    long: "The difference between a chaotic rollout and a clean one is project management. We organize the creative side — briefs, timelines, asset tracking, and approvals — so the team ships on time and on brand.",
    outcomes: [
      "Clear timelines every team member can follow",
      "Briefs that get the right creative the first time",
      "Fewer last-minute fire drills around releases",
      "A premium, consistent rollout experience",
    ],
    includes: [
      "Campaign timelines and milestones",
      "Creative briefs for design, video, and content",
      "Asset tracking and approvals",
      "Vendor and collaborator coordination",
      "Post-mortem and learnings doc",
    ],
    process: [
      { step: "Plan", detail: "Lock the rollout calendar and scope." },
      { step: "Brief", detail: "Write the briefs for every asset needed." },
      { step: "Coordinate", detail: "Run the team and vendors through delivery." },
      { step: "Review", detail: "Recap what worked and what to improve." },
    ],
    faq: [
      { q: "Do you replace my manager?", a: "No — we work alongside management and the existing team." },
      { q: "Is this per-project or ongoing?", a: "Both. Many clients start per-campaign and move to retainer." },
      { q: "How far out should I start planning a release?", a: "8 weeks minimum for a single, 12+ weeks for an EP or album. That gives time for assets, PR, pre-save, and a real paid plan instead of last-minute scrambles." },
      { q: "What tools do you use to manage rollouts?", a: "Usually Notion or Asana for the campaign timeline, plus shared drives for assets and Loom for async approvals. We adapt to whatever your team already uses." },
    ],
  },
];

export const getService = (slug: string) => services.find((s) => s.slug === slug);