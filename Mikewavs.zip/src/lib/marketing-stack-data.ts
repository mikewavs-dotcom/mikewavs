export type StackTool = {
  name: string;
  url: string;
  verdict: string;
  bestFor: string;
  skipIf: string;
  price: string;
};

export type StackCategory = {
  id: string;
  title: string;
  blurb: string;
  defaultPick: string;
  tools: StackTool[];
};

export const STACK_LAST_UPDATED = "2026-06-23";

export const stackCategories: StackCategory[] = [
  {
    id: "smart-links",
    title: "Smart Links & Pre-Saves",
    blurb: "One link to every platform, plus the pre-save and follow flows that capture first-party data on every click.",
    defaultPick: "Foreverfan",
    tools: [
      { name: "Foreverfan", url: "https://foreverfan.com", verdict: "Smart links and pre-saves wired to a first-party fan database — every click becomes a known fan you can re-market to.", bestFor: "Artists who want pre-saves to feed an owned CRM, not just stream counts.", skipIf: "You only need a generic link-in-bio.", price: "$$ tiered" },
      { name: "Feature.fm", url: "https://feature.fm", verdict: "Linkfire's closest competitor. Strong pre-save flows, action pages, and ad pixel support.", bestFor: "Labels and managers running multiple artists.", skipIf: "Budget is tight and Linkfire covers the need.", price: "$$ from ~$10/mo" },
      { name: "Toneden", url: "https://toneden.io", verdict: "Smart links plus full landing-page builder. Good for contests and follow gates.", bestFor: "Giveaways, follow gates, ticket pre-sales.", skipIf: "You only need release links.", price: "$ from free" },
      { name: "Hypeddit", url: "https://hypeddit.com", verdict: "Dance/electronic-leaning, but the gate-to-download flow still works for any genre.", bestFor: "Free downloads in exchange for follows or emails.", skipIf: "You don't run download incentives.", price: "$ from free" },
    ],
  },
  {
    id: "distribution",
    title: "Distribution",
    blurb: "Who gets your music on Spotify, Apple Music, and the rest. Picking the right one matters more than artists think — splits, advances, and editorial reach all differ.",
    defaultPick: "No Cool Points",
    tools: [
      { name: "No Cool Points", url: "https://nocoolpoints.com", verdict: "Richmond-based full-service distribution and label services — global DSP delivery paired with hands-on marketing, publishing admin, and direct-to-fan strategy. Artists keep their masters.", bestFor: "Independent artists, managers, and small labels who want label-style support without giving up ownership.", skipIf: "You only need cheap upload-and-forget distribution.", price: "Custom" },
      { name: "DistroKid", url: "https://distrokid.com", verdict: "Cheap, fast, unlimited uploads. The default for independent artists releasing on their own.", bestFor: "Self-releasing artists at any volume.", skipIf: "You want editorial pitching or label services.", price: "$ from ~$23/yr" },
      { name: "UnitedMasters", url: "https://unitedmasters.com", verdict: "Distribution plus sync/brand opportunities. Free tier exists but takes a cut.", bestFor: "Artists open to brand placements and sync.", skipIf: "You want zero-cut distribution only.", price: "$ free or ~$60/yr" },
      { name: "Stem", url: "https://stem.is", verdict: "Best-in-class for splits and royalty transparency. Real artist services on top tiers.", bestFor: "Collaborators, producer splits, transparent accounting.", skipIf: "You're solo and just want cheap uploads.", price: "$$ tiered" },
      { name: "The Orchard", url: "https://theorchard.com", verdict: "Sony-owned, label-grade distribution with editorial and marketing reach.", bestFor: "Established artists and labels with catalog.", skipIf: "You're early-career — they likely won't take you yet.", price: "Custom" },
      { name: "AWAL", url: "https://awal.com", verdict: "Curated indie distribution with marketing services for accepted artists.", bestFor: "Mid-tier independents with traction.", skipIf: "You haven't built any audience yet.", price: "Custom + revenue share" },
    ],
  },
  {
    id: "crm",
    title: "CRM & Email",
    blurb: "Email is the highest-ROI fan channel because you own it. Pick a tool that segments by fan behavior, not just collects addresses.",
    defaultPick: "Klaviyo",
    tools: [
      { name: "Klaviyo", url: "https://klaviyo.com", verdict: "Best segmentation and automation on the market. Plugs into Shopify and most CRMs out of the box.", bestFor: "Artists with merch or a real release calendar.", skipIf: "You have under 250 contacts and zero automation needs.", price: "$$ free under 250 contacts" },
      { name: "Beehiiv", url: "https://beehiiv.com", verdict: "Best newsletter-first platform. Native referral program is a fan-list growth cheat code.", bestFor: "Artists or managers running a newsletter.", skipIf: "You need deep e-commerce or release automation.", price: "$$ free under 2.5k" },
      { name: "ConvertKit", url: "https://convertkit.com", verdict: "Creator-friendly with strong tagging and visual automations.", bestFor: "Solo artists scaling past Mailchimp.", skipIf: "You want a one-click Shopify integration.", price: "$$ free under 10k" },
      { name: "Mailchimp", url: "https://mailchimp.com", verdict: "Easy on-ramp, but segmentation and pricing get painful past a few thousand contacts.", bestFor: "Sending your first 10 newsletters.", skipIf: "You're past the basics — graduate to Klaviyo.", price: "$ free under 500" },
    ],
  },
  {
    id: "sms",
    title: "SMS",
    blurb: "SMS is the highest open-rate channel that exists. Use it sparingly for release day, ticket on-sales, and merch drops.",
    defaultPick: "SuperPhone",
    tools: [
      { name: "Laylo", url: "https://laylo.com", verdict: "Built for artists. Drop notifications across SMS, email, and DMs from one dashboard.", bestFor: "Artists running release drops and ticket on-sales.", skipIf: "You want full-featured marketing automation.", price: "$$ tiered" },
      { name: "Community", url: "https://community.com", verdict: "Mass-text platform used by major artists. Strong reach, less granular automation.", bestFor: "Established artists with large followings.", skipIf: "You're starting from zero — it's expensive.", price: "$$$ custom" },
      { name: "SuperPhone", url: "https://superphone.io", verdict: "1:1 texting at scale. Closer to a CRM than a broadcast tool.", bestFor: "Managers and artists who want real conversations.", skipIf: "You just need to blast announcements.", price: "$$ from ~$50/mo" },
    ],
  },
  {
    id: "websites",
    title: "Website Platforms",
    blurb: "Your site is the only owned destination that doesn't disappear when a platform changes its algorithm. Build it on something you (or your team) can actually maintain.",
    defaultPick: "Framer",
    tools: [
      { name: "Webflow", url: "https://webflow.com", verdict: "Designer-grade control without writing code. What we build most custom artist sites on.", bestFor: "Premium artist sites with custom design.", skipIf: "Nobody on your team will ever touch the CMS.", price: "$$ from ~$15/mo" },
      { name: "Framer", url: "https://framer.com", verdict: "Fastest path from Figma-style design to a live site. Great for landing pages.", bestFor: "Single-artist sites, EPKs, campaign pages.", skipIf: "You need a complex CMS or e-commerce.", price: "$$ free with branding" },
      { name: "Squarespace", url: "https://squarespace.com", verdict: "Solid templates, decent e-commerce, easy to update without a developer.", bestFor: "Artists self-managing their own site.", skipIf: "You want a fully custom design system.", price: "$ from ~$16/mo" },
      { name: "Shopify", url: "https://shopify.com", verdict: "Use it when merch is the core of the site, not just a sidebar.", bestFor: "Merch-first artist brands.", skipIf: "You don't sell physical products.", price: "$$ from ~$29/mo" },
      { name: "WordPress", url: "https://wordpress.org", verdict: "Most flexible, most maintenance. Still the default for blog-heavy sites.", bestFor: "Sites with real publishing schedules.", skipIf: "Nobody on the team wants to manage plugins.", price: "$ hosting only" },
    ],
  },
  {
    id: "ads",
    title: "Ads & Paid Media",
    blurb: "Paid only works behind organic creative that's already proving itself. Don't boost average content.",
    defaultPick: "Meta Ads Manager + TikTok Ads",
    tools: [
      { name: "Meta Ads Manager", url: "https://business.facebook.com", verdict: "Still the most precise targeting and reporting for music ads.", bestFor: "Pre-saves, ticket sales, retargeting site visitors.", skipIf: "Your audience is purely TikTok-native.", price: "Free tool — you pay for spend" },
      { name: "TikTok Ads Manager", url: "https://ads.tiktok.com", verdict: "Where most discovery happens now. Spark Ads on creator posts beat made-for-ads content.", bestFor: "Driving new audience and song virality.", skipIf: "Your sound has no TikTok cultural fit.", price: "Free tool — you pay for spend" },
      { name: "Chartmetric", url: "https://chartmetric.com", verdict: "The targeting research layer underneath the ads — fan demographics, playlist data, similar artists.", bestFor: "Building lookalike audiences and tour routing.", skipIf: "You're not running paid campaigns yet.", price: "$$$ from ~$140/mo" },
    ],
  },
  {
    id: "analytics",
    title: "Analytics",
    blurb: "If you can't see what's working, you're guessing. Install tracking before you spend a dollar on promo.",
    defaultPick: "GA4 + Chartmetric",
    tools: [
      { name: "Google Analytics 4", url: "https://analytics.google.com", verdict: "Free, standard, integrates with everything. Worth setting up correctly even if the UI fights you.", bestFor: "Site traffic, conversion events, channel attribution.", skipIf: "You don't have a website worth tracking yet.", price: "Free" },
      { name: "Chartmetric", url: "https://chartmetric.com", verdict: "The streaming-side analytics layer. Playlist tracking, audience geo, similar artists.", bestFor: "Catalog artists and labels making release decisions.", skipIf: "You're pre-release with no streaming history.", price: "$$$ from ~$140/mo" },
      { name: "Songstats", url: "https://songstats.com", verdict: "Cheaper Chartmetric alternative with strong playlist and TikTok tracking.", bestFor: "Independents who want streaming insights without the price tag.", skipIf: "You need label-grade catalog reporting.", price: "$$ tiered" },
      { name: "Plausible", url: "https://plausible.io", verdict: "Privacy-first site analytics — no cookie banner needed. Lighter than GA4.", bestFor: "Artists who want simple, clean dashboards.", skipIf: "You need full e-commerce attribution.", price: "$ from ~$9/mo" },
    ],
  },
  {
    id: "merch",
    title: "Merch & E-commerce",
    blurb: "Merch is the highest-margin revenue most artists ignore. The store should feel like part of the brand, not a bolted-on shop.",
    defaultPick: "Shopify",
    tools: [
      { name: "Shopify", url: "https://shopify.com", verdict: "Scales from first drop to full brand. Connects to Klaviyo, Meta, and every print-on-demand service worth using.", bestFor: "Any artist serious about merch.", skipIf: "You're testing one product and don't want a monthly fee.", price: "$$ from ~$29/mo" },
      { name: "Big Cartel", url: "https://bigcartel.com", verdict: "Free up to 5 products. Perfect for first drops.", bestFor: "Your first merch test.", skipIf: "You sell more than ~20 SKUs.", price: "$ free under 5 products" },
      { name: "Fourthwall", url: "https://fourthwall.com", verdict: "Creator-friendly storefront with built-in print-on-demand and membership.", bestFor: "Artists who want POD + memberships in one tool.", skipIf: "You already run Shopify + a fulfillment partner.", price: "$ free + product cost" },
      { name: "Bonfire", url: "https://bonfire.com", verdict: "Best for one-off campaign tees with no inventory risk.", bestFor: "Tour shirts, charity drops, limited releases.", skipIf: "You want a permanent storefront.", price: "Free — margin on each sale" },
    ],
  },
  {
    id: "content",
    title: "Content & Creative",
    blurb: "The tools that turn a raw asset into a post. Speed matters more than polish — you'll edit 50 clips before you find the one that works.",
    defaultPick: "CapCut + Frame.io",
    tools: [
      { name: "CapCut", url: "https://capcut.com", verdict: "The default short-form editor. Fast templates, native TikTok export.", bestFor: "Reels, TikToks, Shorts at volume.", skipIf: "You need broadcast-grade color and audio.", price: "$ free + pro tier" },
      { name: "Splice", url: "https://splice.com", verdict: "Sample library and DAW collaboration. Pair with Suno or Logic for ideation.", bestFor: "Producers and beat-makers.", skipIf: "You only release finished tracks.", price: "$$ from ~$10/mo" },
      { name: "Notion", url: "https://notion.so", verdict: "The campaign brain — calendar, briefs, asset tracking, approvals.", bestFor: "Any team running more than one rollout at a time.", skipIf: "You're solo and one spreadsheet covers it.", price: "$ free for personal" },
      { name: "Frame.io", url: "https://frame.io", verdict: "Video review and approvals without losing comment threads.", bestFor: "Music videos and content shoots with multiple stakeholders.", skipIf: "You only post phone-shot content.", price: "$$ free under 5 users" },
    ],
  },
  {
    id: "ai",
    title: "AI & Emerging",
    blurb: "AI tools that actually help artist teams move faster. Use them to draft, not to ship — fans can smell generic AI copy from a mile away.",
    defaultPick: "Claude (strategy) + ChatGPT (copy)",
    tools: [
      { name: "Claude", url: "https://claude.ai", verdict: "Best for long-form thinking — rollout plans, EPK drafts, briefs.", bestFor: "Strategy docs and campaign planning.", skipIf: "You only need quick caption rewrites.", price: "$ free tier + Pro" },
      { name: "ChatGPT", url: "https://chatgpt.com", verdict: "Fastest at short-form copy — captions, subject lines, ad variations.", bestFor: "Social copy and quick rewrites.", skipIf: "You need deep reasoning over long context.", price: "$ free tier + Pro" },
      { name: "Suno", url: "https://suno.com", verdict: "Useful for sketching reference tracks and demo ideas. Not for final masters.", bestFor: "Producers exploring direction.", skipIf: "You only release fully-human productions.", price: "$ free tier" },
      { name: "Descript", url: "https://descript.com", verdict: "Edit audio and video by editing text. Best podcast and voiceover tool out there.", bestFor: "Podcasts, behind-the-scenes content, voice-overs.", skipIf: "You don't produce any spoken-word content.", price: "$$ from ~$15/mo" },
    ],
  },
];
