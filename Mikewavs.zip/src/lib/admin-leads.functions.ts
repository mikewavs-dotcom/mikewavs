import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const LEAD_STATUSES = ["New", "Reviewed", "Hot Lead", "Contacted", "Booked", "Not a Fit"] as const;
export type LeadStatus = (typeof LEAD_STATUSES)[number];

export type AdminLead = {
  id: string;
  created_at: string;
  name: string;
  email: string;
  artist_company_name: string | null;
  role: string | null;
  release_type: string | null;
  release_date: string | null;
  main_goal: string | null;
  score: number | null;
  score_category: string | null;
  lead_status: LeadStatus;
  notes: string | null;
  missing_items: string[] | null;
  recommended_services: string[] | null;
  has_website: boolean;
  has_email_capture: boolean;
  has_sms_capture: boolean;
  has_crm: boolean;
  has_merch: boolean;
  has_content_plan: boolean;
  has_smart_link: boolean;
  has_tracking: boolean;
  has_post_release_plan: boolean;
};

export type AdminLeadsResult =
  | { ok: true; leads: AdminLead[]; stats: { total: number; newCount: number; avgScore: number; highest: number; lowest: number } }
  | { ok: false; reason: "forbidden" };

async function isAdmin(supabase: { rpc: (n: string, a: Record<string, unknown>) => Promise<{ data: boolean | null; error: unknown }> }, userId: string) {
  const { data, error } = await supabase.rpc("has_role", { _user_id: userId, _role: "admin" });
  if (error) return false;
  return data === true;
}

export const listRolloutLeads = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<AdminLeadsResult> => {
    const { supabase, userId } = context;
    if (!(await isAdmin(supabase as never, userId))) return { ok: false, reason: "forbidden" };

    const { data, error } = await supabase
      .from("music_rollout_leads")
      .select("*")
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);

    const leads = (data ?? []) as AdminLead[];
    const scores = leads.map((l) => l.score ?? 0);
    const total = leads.length;
    const newCount = leads.filter((l) => l.lead_status === "New").length;
    const avgScore = total ? Math.round(scores.reduce((a, b) => a + b, 0) / total) : 0;
    const highest = total ? Math.max(...scores) : 0;
    const lowest = total ? Math.min(...scores) : 0;

    return { ok: true, leads, stats: { total, newCount, avgScore, highest, lowest } };
  });

const updateSchema = z.object({
  id: z.string().uuid(),
  lead_status: z.enum(LEAD_STATUSES).optional(),
  notes: z.string().max(5000).nullable().optional(),
});

export const updateRolloutLead = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => updateSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    if (!(await isAdmin(supabase as never, userId))) {
      throw new Error("Forbidden");
    }
    const patch: { lead_status?: LeadStatus; notes?: string | null } = {};
    if (data.lead_status !== undefined) patch.lead_status = data.lead_status;
    if (data.notes !== undefined) patch.notes = data.notes;
    if (Object.keys(patch).length === 0) return { ok: true };

    const { error } = await supabase.from("music_rollout_leads").update(patch).eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export { LEAD_STATUSES };