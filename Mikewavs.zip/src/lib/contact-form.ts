/**
 * Pure data, types, and copy for the contact inquiry form.
 * No React, no DOM — safe to import from anywhere.
 */
export type FormState = {
  serviceSlug: string;
  name: string;
  email: string;
  company: string;
  role: string;
  phone: string;
  website: string;
  socials: string;
  budget: string;
  timeline: string;
  goals: string;
  currentSituation: string;
  additionalInfo: string;
};

export const BUDGETS = [
  "Under $2k",
  "$2k – $5k",
  "$5k – $10k",
  "$10k – $25k",
  "$25k+",
  "Not sure yet",
];

export const TIMELINES = [
  "ASAP / urgent",
  "Within 1 month",
  "1 – 3 months",
  "3+ months",
  "Just exploring",
];

export type ServicePrompts = {
  goalsLabel: string;
  goalsPlaceholder: string;
  currentLabel: string;
  currentPlaceholder: string;
};

const PROMPTS_BY_SERVICE: Record<string, ServicePrompts> = {
  "artist-label-marketing": {
    goalsLabel: "What release or campaign do you need help with?",
    goalsPlaceholder:
      "Release date, single vs project, target audience, what success looks like…",
    currentLabel: "What does your current rollout look like?",
    currentPlaceholder:
      "Team size, current channels, what's worked or fallen flat in past releases…",
  },
  "website-digital-setup": {
    goalsLabel: "What kind of site do you need?",
    goalsPlaceholder:
      "Pages needed (EPK, merch, tour, press), brand vibe, must-have integrations…",
    currentLabel: "Do you have an existing site or assets?",
    currentPlaceholder:
      "Current URL, platform (Squarespace, WP, Webflow…), logos, photography, copy…",
  },
  "social-media-content-strategy": {
    goalsLabel: "What platforms and goals matter most?",
    goalsPlaceholder:
      "Platforms (IG, TikTok, YT), follower goals, content you can produce, cadence…",
    currentLabel: "What's your current content workflow?",
    currentPlaceholder:
      "Who shoots/edits, posting frequency, what's worked or stalled out…",
  },
  "fan-capture-crm": {
    goalsLabel: "What do you want your fan list to do for you?",
    goalsPlaceholder:
      "List size goals, email vs SMS, release alerts, merch, paid traffic plans…",
    currentLabel: "What's already in place?",
    currentPlaceholder:
      "Existing CRM (Mailchimp, Klaviyo, none), list size, capture points today…",
  },
  "campaign-tracking-analytics": {
    goalsLabel: "What do you wish you could measure?",
    goalsPlaceholder:
      "Ad performance, content ROI, fan funnel, attribution gaps you keep hitting…",
    currentLabel: "What tracking do you have today?",
    currentPlaceholder: "GA4? Pixels? UTMs? Any current dashboards or reports…",
  },
  "ecommerce-merch-support": {
    goalsLabel: "Tell me about your merch plans",
    goalsPlaceholder:
      "Catalog size, drop strategy, fulfillment partner, target launch date…",
    currentLabel: "Where are you selling today?",
    currentPlaceholder:
      "Current store/platform, what's selling, what's broken, fulfillment setup…",
  },
  "creative-direction-project-management": {
    goalsLabel: "What campaign or rollout do you need run?",
    goalsPlaceholder:
      "Project scope, deliverables, deadlines, team and vendors involved…",
    currentLabel: "How is the project organized today?",
    currentPlaceholder:
      "Tools you use (Notion, Asana, none), team size, current bottlenecks…",
  },
};

export function getPromptsForService(slug: string): ServicePrompts {
  return (
    PROMPTS_BY_SERVICE[slug] ?? {
      goalsLabel: "What are you trying to accomplish?",
      goalsPlaceholder: "Share the project, the goal, and what success looks like…",
      currentLabel: "Where are you right now?",
      currentPlaceholder:
        "Current setup, team, what's working, what's broken or missing…",
    }
  );
}