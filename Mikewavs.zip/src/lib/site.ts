/**
 * Client-safe site constants. Server-only config lives in src/lib/config.server.ts.
 */
export const SITE_URL = "https://mikewavs.com";
export const SITE_NAME = "Mikewavs";
export const SITE_INSTAGRAM = "https://www.instagram.com/mikewavs";

/** Join SITE_URL with a path that begins with "/". */
export function siteUrl(path: string = "/"): string {
  return path === "/" ? `${SITE_URL}/` : `${SITE_URL}${path.startsWith("/") ? path : `/${path}`}`;
}