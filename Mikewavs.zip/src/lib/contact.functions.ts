import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const inquirySchema = z.object({
  serviceSlug: z.string().max(100).optional().nullable(),
  serviceName: z.string().max(200).optional().nullable(),
  name: z.string().trim().min(1).max(120),
  email: z.string().trim().email().max(200),
  company: z.string().trim().max(200).optional().nullable(),
  role: z.string().trim().max(120).optional().nullable(),
  phone: z.string().trim().max(60).optional().nullable(),
  website: z.string().trim().max(300).optional().nullable(),
  socials: z.string().trim().max(500).optional().nullable(),
  budget: z.string().trim().max(120).optional().nullable(),
  timeline: z.string().trim().max(120).optional().nullable(),
  goals: z.string().trim().min(10).max(4000),
  currentSituation: z.string().trim().max(4000).optional().nullable(),
  additionalInfo: z.string().trim().max(4000).optional().nullable(),
  // Anti-spam fields (not stored, validated server-side):
  // - hp: honeypot, must be empty
  // - formLoadedAt: client epoch ms when the form mounted; we reject sub-3s submits
  hp: z.string().max(200).optional().nullable(),
  formLoadedAt: z.number().int().nonnegative().optional().nullable(),
});

export type InquiryInput = z.infer<typeof inquirySchema>;

const ADMIN_EMAIL = "mike@nocoolpoints.com";
const MIN_FILL_MS = 3000;

async function hashIp(ip: string | null): Promise<string | null> {
  if (!ip) return null;
  const salt = process.env.CONTACT_IP_SALT || "mikewavs-contact-v1";
  const buf = new TextEncoder().encode(`${salt}:${ip}`);
  const digest = await crypto.subtle.digest("SHA-256", buf);
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

function esc(s: string | null | undefined): string {
  if (!s) return "";
  return String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function buildEmailHtml(d: InquiryInput): string {
  const rows: [string, string | null | undefined][] = [
    ["Service", d.serviceName || d.serviceSlug || "General inquiry"],
    ["Name", d.name],
    ["Email", d.email],
    ["Company / Project", d.company],
    ["Role", d.role],
    ["Phone", d.phone],
    ["Website", d.website],
    ["Socials", d.socials],
    ["Budget", d.budget],
    ["Timeline", d.timeline],
  ];
  const rowHtml = rows
    .filter(([, v]) => v)
    .map(
      ([k, v]) =>
        `<tr><td style="padding:8px 12px;background:#f6f7fb;border:1px solid #e5e7eb;font-weight:600;width:180px;">${esc(k)}</td><td style="padding:8px 12px;border:1px solid #e5e7eb;">${esc(v)}</td></tr>`,
    )
    .join("");

  const block = (title: string, body?: string | null) =>
    body
      ? `<h3 style="margin:24px 0 8px;font-size:14px;color:#111;">${esc(title)}</h3><div style="white-space:pre-wrap;padding:12px;border:1px solid #e5e7eb;border-radius:8px;background:#fafafa;">${esc(body)}</div>`
      : "";

  return `<!doctype html><html><body style="font-family:Arial,sans-serif;color:#111;max-width:640px;margin:0 auto;padding:24px;">
    <h2 style="margin:0 0 4px;">New Mikewavs Inquiry</h2>
    <p style="margin:0 0 16px;color:#666;font-size:13px;">${esc(d.serviceName || "General inquiry")}</p>
    <table style="border-collapse:collapse;width:100%;font-size:13px;">${rowHtml}</table>
    ${block("Goals", d.goals)}
    ${block("Current situation", d.currentSituation)}
    ${block("Additional info", d.additionalInfo)}
    <p style="margin-top:24px;font-size:12px;color:#888;">Reply directly to ${esc(d.email)} to respond.</p>
  </body></html>`;
}

function buildEmailText(d: InquiryInput): string {
  const lines = [
    `New Mikewavs Inquiry`,
    `Service: ${d.serviceName || d.serviceSlug || "General"}`,
    ``,
    `Name: ${d.name}`,
    `Email: ${d.email}`,
    d.company ? `Company: ${d.company}` : "",
    d.role ? `Role: ${d.role}` : "",
    d.phone ? `Phone: ${d.phone}` : "",
    d.website ? `Website: ${d.website}` : "",
    d.socials ? `Socials: ${d.socials}` : "",
    d.budget ? `Budget: ${d.budget}` : "",
    d.timeline ? `Timeline: ${d.timeline}` : "",
    ``,
    `Goals:`,
    d.goals,
  ];
  if (d.currentSituation) lines.push("", "Current situation:", d.currentSituation);
  if (d.additionalInfo) lines.push("", "Additional info:", d.additionalInfo);
  return lines.filter(Boolean).join("\n");
}

export const submitInquiry = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => inquirySchema.parse(data))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { getRequestHeader } = await import("@tanstack/react-start/server");

    // 1. Honeypot — silently succeed so bots don't learn they were blocked.
    if (data.hp && data.hp.trim().length > 0) {
      console.warn("[submitInquiry] honeypot tripped");
      return { ok: true, emailSent: false };
    }

    // 2. Min time-to-submit — reject if the form was submitted impossibly fast.
    if (data.formLoadedAt) {
      const elapsed = Date.now() - data.formLoadedAt;
      if (elapsed >= 0 && elapsed < MIN_FILL_MS) {
        console.warn("[submitInquiry] sub-min-fill submit", { elapsed });
        throw new Error("Please take a moment to review your inquiry before submitting.");
      }
    }

    // 3. Rate limit (IP + email). IPs are hashed with a server-side salt before storage.
    const rawIp =
      getRequestHeader("cf-connecting-ip") ||
      getRequestHeader("x-real-ip") ||
      (getRequestHeader("x-forwarded-for")?.split(",")[0].trim() ?? null);
    const ipHash = await hashIp(rawIp);

    const { data: limitReason, error: limitError } = await supabaseAdmin.rpc(
      "check_contact_rate_limit",
      { _ip_hash: ipHash ?? "", _email: data.email },
    );
    if (limitError) {
      console.error("[submitInquiry] rate-limit check failed", limitError);
      throw new Error(
        "We couldn't process your inquiry right now. Please try again in a moment, or email mike@nocoolpoints.com directly.",
      );
    }
    if (limitReason) {
      throw new Error(
        "You've sent a lot of inquiries recently. Please wait a bit before trying again, or email mike@nocoolpoints.com directly.",
      );
    }

    let emailSent = false;
    let emailError: string | null = null;

    // Render + enqueue the admin notification via Lovable Emails.
    try {
      const React = await import("react");
      const { render } = await import("@react-email/components");
      const { template } = await import("@/lib/email-templates/inquiry-notification");

      const templateData = {
        serviceName: data.serviceName || data.serviceSlug || "General inquiry",
        name: data.name,
        email: data.email,
        company: data.company,
        role: data.role,
        phone: data.phone,
        website: data.website,
        socials: data.socials,
        budget: data.budget,
        timeline: data.timeline,
        goals: data.goals,
        currentSituation: data.currentSituation,
        additionalInfo: data.additionalInfo,
      };
      const element = React.createElement(template.component, templateData);
      const html = await render(element);
      const text = await render(element, { plainText: true });
      const subject =
        typeof template.subject === "function"
          ? template.subject(templateData)
          : template.subject;

      const messageId = crypto.randomUUID();
      const SENDER_DOMAIN = "notify.mikewavs.com";
      const FROM = `Mikewavs <noreply@mikewavs.com>`;

      await supabaseAdmin.from("email_send_log").insert({
        message_id: messageId,
        template_name: "inquiry-notification",
        recipient_email: ADMIN_EMAIL,
        status: "pending",
      });

      const { error: enqueueError } = await supabaseAdmin.rpc("enqueue_email", {
        queue_name: "transactional_emails",
        payload: {
          message_id: messageId,
          to: ADMIN_EMAIL,
          from: FROM,
          sender_domain: SENDER_DOMAIN,
          subject,
          html,
          text,
          purpose: "transactional",
          label: "inquiry-notification",
          idempotency_key: messageId,
          queued_at: new Date().toISOString(),
        } as any,
      });

      if (enqueueError) {
        emailError = `enqueue failed: ${enqueueError.message}`;
        console.error("[submitInquiry] enqueue failed", enqueueError);
      } else {
        emailSent = true;
      }
    } catch (err) {
      emailError = err instanceof Error ? err.message : String(err);
      console.error("[submitInquiry] email error", err);
    }

    const { error: insertError } = await supabaseAdmin.from("contact_inquiries").insert({
      service_slug: data.serviceSlug ?? null,
      service_name: data.serviceName ?? null,
      name: data.name,
      email: data.email,
      company: data.company ?? null,
      role: data.role ?? null,
      phone: data.phone ?? null,
      website: data.website ?? null,
      socials: data.socials ?? null,
      budget: data.budget ?? null,
      timeline: data.timeline ?? null,
      goals: data.goals,
      current_situation: data.currentSituation ?? null,
      additional_info: data.additionalInfo ?? null,
      email_sent: emailSent,
      email_error: emailError,
      ip_hash: ipHash,
    });

    if (insertError) {
      console.error("[submitInquiry] insert failed", insertError);
      throw new Error("Could not save your inquiry. Please try again or email mike@nocoolpoints.com directly.");
    }

    return { ok: true, emailSent };
  });