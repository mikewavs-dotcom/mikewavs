import { createFileRoute } from "@tanstack/react-router";
import { BlogPostLayout, blogPostHead } from "@/components/blog/BlogPostLayout";
import { postBySlug } from "@/lib/blog-posts";

const post = postBySlug("electronic-press-kit-guide")!;

export const Route = createFileRoute("/blog/electronic-press-kit-guide")({
  head: () => blogPostHead(post),
  component: () => <BlogPostLayout post={post} />,
});