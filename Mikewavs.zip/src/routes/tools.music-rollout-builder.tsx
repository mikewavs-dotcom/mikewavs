import { createFileRoute, useRouter } from "@tanstack/react-router";
import { siteUrl } from "@/lib/site";
import { RolloutBuilderPage } from "@/components/rollout/RolloutBuilderPage";

export const Route = createFileRoute("/tools/music-rollout-builder")({
  head: () => ({
    meta: [
      { title: "Music Rollout System Builder — Free Tool | Mikewavs" },
      { name: "description", content: "Free tool for independent artists, labels, managers, and music teams. Score your release readiness across website, fan capture, CRM, content, merch, and tracking." },
      { property: "og:title", content: "Check If Your Music Rollout Is Actually Ready — Mikewavs" },
      { property: "og:description", content: "See exactly what your music rollout is missing before you drop. Free readiness score for artists, labels, managers, and distribution teams." },
      { property: "og:url", content: siteUrl("/tools/music-rollout-builder") },
      { property: "og:type", content: "website" },
    ],
    links: [{ rel: "canonical", href: siteUrl("/tools/music-rollout-builder") }],
  }),
  errorComponent: ({ error, reset }) => {
    const router = useRouter();
    return (
      <div className="min-h-screen bg-background text-foreground flex items-center justify-center p-6">
        <div className="max-w-md text-center">
          <h1 className="font-display text-2xl font-extrabold uppercase">Something broke</h1>
          <p className="mt-3 text-sm text-muted-foreground">{error.message}</p>
          <button onClick={() => { reset(); router.invalidate(); }} className="mt-6 rounded-full bg-gradient-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground">Retry</button>
        </div>
      </div>
    );
  },
  notFoundComponent: () => (
    <div className="min-h-screen flex items-center justify-center bg-background text-foreground">Not found.</div>
  ),
  component: RolloutBuilderPage,
});
