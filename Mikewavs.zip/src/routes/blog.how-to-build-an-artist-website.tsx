import { createFileRoute } from "@tanstack/react-router";
import { BlogPostLayout, blogPostHead } from "@/components/blog/BlogPostLayout";
import { postBySlug } from "@/lib/blog-posts";

const post = postBySlug("how-to-build-an-artist-website")!;

export const Route = createFileRoute("/blog/how-to-build-an-artist-website")({
  head: () => blogPostHead(post),
  component: () => <BlogPostLayout post={post} />,
});
