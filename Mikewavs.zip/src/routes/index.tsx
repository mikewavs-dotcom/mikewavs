import { createFileRoute } from "@tanstack/react-router";
import { useSiteAnimations } from "@/hooks/use-site-animations";
import { SITE_URL, SITE_NAME, SITE_INSTAGRAM, siteUrl } from "@/lib/site";
import { Nav } from "@/components/home/Nav";
import { Hero } from "@/components/home/Hero";
import { Marquee } from "@/components/home/Marquee";
import { About } from "@/components/home/About";
import { Services } from "@/components/home/Services";
import { Clients } from "@/components/home/Clients";
import { Partners } from "@/components/home/Partners";
import { FreeDownload } from "@/components/home/FreeDownload";
import { FinalCTA } from "@/components/home/FinalCTA";
import { Footer } from "@/components/home/Footer";
import { BackgroundFX } from "@/components/home/BackgroundFX";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Mikewavs — Digital Strategy & Direct-To-Fan Growth" },
      { name: "description", content: "Mikewavs helps artists, labels, and music teams build direct-to-fan systems: websites, CRM, fan capture, merch, analytics, and release campaigns." },
      { property: "og:title", content: "Mikewavs — Digital Strategy & Direct-To-Fan Growth" },
      { property: "og:description", content: "Digital infrastructure for music brands. Build your system. Grow your fanbase." },
      { property: "og:url", content: siteUrl("/") },
      { property: "og:type", content: "website" },
    ],
    links: [{ rel: "canonical", href: siteUrl("/") }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Organization",
          name: SITE_NAME,
          url: SITE_URL,
          sameAs: [SITE_INSTAGRAM],
          description:
            "Digital strategy, web design, and direct-to-fan systems for independent artists, labels, and music teams.",
          foundingDate: "2014",
          areaServed: "United States",
          serviceType: [
            "Artist Websites",
            "Fan Capture Systems",
            "CRM Setup",
            "Release Campaign Strategy",
            "Email Marketing",
          ],
        }),
      },
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "WebSite",
          name: SITE_NAME,
          url: SITE_URL,
          description:
            "Digital strategy and direct-to-fan growth for artists, labels, and music teams.",
        }),
      },
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Person",
          name: "Mike Wavs",
          jobTitle: "Music Digital Strategist",
          url: SITE_URL,
          sameAs: [SITE_INSTAGRAM],
          worksFor: { "@type": "Organization", name: SITE_NAME, url: SITE_URL },
        }),
      },
    ],
  }),
  component: Index,
});

function Index() {
  useSiteAnimations();
  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      <BackgroundFX />
      <Nav />
      <main className="relative">
        <Hero />
        <Marquee />
        <About />
        <Services />
        <Clients />
        <Partners />
        <FreeDownload />
        <FinalCTA />
      </main>
      <Footer />
    </div>
  );
}
