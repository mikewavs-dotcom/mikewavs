import { createFileRoute } from "@tanstack/react-router";
import { BlogPostLayout, blogPostHead } from "@/components/blog/BlogPostLayout";
import { postBySlug } from "@/lib/blog-posts";

const post = postBySlug("how-to-promote-your-music")!;

export const Route = createFileRoute("/blog/how-to-promote-your-music")({
  head: () => blogPostHead(post),
  component: () => <BlogPostLayout post={post} />,
});