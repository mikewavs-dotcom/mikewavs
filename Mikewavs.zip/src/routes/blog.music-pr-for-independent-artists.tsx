import { createFileRoute } from "@tanstack/react-router";
import { BlogPostLayout, blogPostHead } from "@/components/blog/BlogPostLayout";
import { postBySlug } from "@/lib/blog-posts";

const post = postBySlug("music-pr-for-independent-artists")!;

export const Route = createFileRoute("/blog/music-pr-for-independent-artists")({
  head: () => blogPostHead(post),
  component: () => <BlogPostLayout post={post} />,
});