import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, Calendar, Check } from "lucide-react";
import { InstagramLink } from "@/components/InstagramLink";
import { StickyRolloutCTA } from "@/components/StickyRolloutCTA";
import logo from "@/assets/mikewavs-logo.png.asset.json";
import { services, getService, CONSULT_URL, type Service } from "@/lib/services-data";
import { SITE_URL, siteUrl } from "@/lib/site";

export const Route = createFileRoute("/services/$slug")({
  head: ({ params }) => {
    const s = getService(params.slug);
    const title = s ? `${s.t} — Mikewavs` : "Service — Mikewavs";
    const desc = s?.d ?? "Digital strategy services for artists, labels, and music brands.";
    const url = siteUrl(`/services/${params.slug}`);
    return {
      meta: [
        { title },
        { name: "description", content: desc },
        { property: "og:title", content: title },
        { property: "og:description", content: desc },
        { property: "og:url", content: url },
        { property: "og:type", content: "website" },
      ],
      links: s ? [{ rel: "canonical", href: url }] : [],
      scripts: s
        ? [
            {
              type: "application/ld+json",
              children: JSON.stringify({
                "@context": "https://schema.org",
                "@type": "Service",
                name: s.t,
                description: s.d,
                url,
                provider: { "@type": "Organization", name: "Mikewavs", url: SITE_URL },
              }),
            },
            {
              type: "application/ld+json",
              children: JSON.stringify({
                "@context": "https://schema.org",
                "@type": "FAQPage",
                mainEntity: s.faq.map((f) => ({
                  "@type": "Question",
                  name: f.q,
                  acceptedAnswer: { "@type": "Answer", text: f.a },
                })),
              }),
            },
            {
              type: "application/ld+json",
              children: JSON.stringify({
                "@context": "https://schema.org",
                "@type": "BreadcrumbList",
                itemListElement: [
                  { "@type": "ListItem", position: 1, name: "Home", item: SITE_URL },
                  { "@type": "ListItem", position: 2, name: "Services", item: `${SITE_URL}/#services` },
                  { "@type": "ListItem", position: 3, name: s.t, item: url },
                ],
              }),
            },
          ]
        : [],
    };
  },
  loader: ({ params }) => {
    const service = getService(params.slug);
    if (!service) throw notFound();
    return { slug: params.slug };
  },
  component: ServicePage,
  notFoundComponent: () => (
    <div className="min-h-screen bg-background text-foreground grid place-items-center px-6">
      <div className="text-center max-w-md">
        <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">404</p>
        <h1 className="mt-3 text-3xl font-display font-extrabold uppercase">Service not found</h1>
        <p className="mt-3 text-sm text-muted-foreground">That service doesn't exist or has moved.</p>
        <Link to="/" className="mt-6 inline-flex items-center gap-2 rounded-full bg-gradient-primary px-5 py-3 text-sm font-semibold text-primary-foreground">
          <ArrowLeft className="h-4 w-4" /> Back home
        </Link>
      </div>
    </div>
  ),
  errorComponent: ({ error, reset }) => (
    <div className="min-h-screen bg-background text-foreground grid place-items-center px-6">
      <div className="text-center">
        <h1 className="text-2xl font-display font-extrabold uppercase">Something went wrong</h1>
        <p className="mt-2 text-sm text-muted-foreground">{error.message}</p>
        <button onClick={reset} className="mt-5 rounded-full border border-border px-5 py-2.5 text-sm">Try again</button>
      </div>
    </div>
  ),
});

function ServicePage() {
  const { slug } = Route.useLoaderData() as { slug: string };
  const service = getService(slug) as Service;
  const others = services.filter((s) => s.slug !== service.slug).slice(0, 3);

  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      <div aria-hidden className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
        <div className="absolute -top-40 left-1/2 h-[600px] w-[1200px] -translate-x-1/2 opacity-60" style={{ background: "var(--gradient-glow)" }} />
        <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, white 1px, transparent 0)", backgroundSize: "32px 32px" }} />
      </div>

      <header className="sticky top-0 z-50 border-b border-border/40 backdrop-blur-xl bg-background/70">
        <div className="mx-auto grid grid-cols-[auto_1fr_auto] items-center gap-3 max-w-7xl px-4 py-3 md:px-8 md:py-4">
          <Link to="/" className="flex items-center gap-2">
            <img src={logo.url} alt="Mikewavs" className="h-7 w-auto md:h-8 object-contain" />
          </Link>
          <nav className="hidden md:flex justify-center items-center gap-6 text-xs font-mono uppercase tracking-widest text-muted-foreground">
            <Link to="/" className="hover:text-foreground transition-colors">Home</Link>
            <Link to="/blog" className="hover:text-foreground transition-colors">Artist Resources</Link>
            <Link to="/contact" className="hover:text-foreground transition-colors">Contact</Link>
          </nav>
          <div className="flex items-center gap-2 md:gap-3">
            <InstagramLink />
            <a href={CONSULT_URL} className="inline-flex items-center gap-2 rounded-full bg-gradient-primary px-4 py-2 md:px-5 md:py-2.5 text-xs md:text-sm font-semibold text-primary-foreground glow-primary">
              <Calendar className="h-4 w-4" /> Book
            </a>
          </div>
        </div>
      </header>

      <main className="relative z-10">
        <section className="mx-auto max-w-5xl px-4 pt-10 pb-12 sm:px-6 md:px-8 md:pt-16 md:pb-20">
          <Link to="/" hash="services" className="inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-widest text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft className="h-3.5 w-3.5" /> All services
          </Link>

          <h1 className="mt-6 text-4xl sm:text-5xl md:text-6xl font-display font-extrabold uppercase leading-[1.02] tracking-tight">
            {service.t}
          </h1>
          <p className="mt-5 max-w-3xl text-base md:text-lg text-muted-foreground leading-relaxed">{service.long}</p>

          <div className="mt-7 flex flex-wrap gap-3">
            <Link
              to="/contact"
              search={{ service: service.slug }}
              className="inline-flex items-center gap-2 rounded-full bg-gradient-primary px-6 py-3.5 text-sm font-semibold text-primary-foreground transition-all hover:scale-[1.02] glow-primary"
            >
              Start Inquiry <ArrowRight className="h-4 w-4" />
            </Link>
            <a href={CONSULT_URL} className="inline-flex items-center gap-2 rounded-full border border-border bg-card/50 px-6 py-3.5 text-sm font-semibold transition-all hover:bg-card hover:border-primary/40">
              <Calendar className="h-4 w-4" /> Book Consultation
            </a>
          </div>
        </section>

        <section className="mx-auto max-w-5xl px-4 sm:px-6 md:px-8 pb-12 md:pb-16">
          <div className="grid gap-4 md:gap-5 md:grid-cols-2">
            <div className="glass-card p-6 md:p-8">
              <h2 className="font-mono text-[10px] uppercase tracking-[0.3em] text-accent-muted">Outcomes</h2>
              <ul className="mt-4 space-y-3">
                {service.outcomes.map((o) => (
                  <li key={o} className="flex gap-3 text-sm md:text-[15px] text-foreground/90">
                    <Check className="h-4 w-4 mt-0.5 shrink-0 text-primary" />
                    <span>{o}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="glass-card p-6 md:p-8">
              <h2 className="font-mono text-[10px] uppercase tracking-[0.3em] text-accent-muted">What's included</h2>
              <ul className="mt-4 space-y-3">
                {service.includes.map((o) => (
                  <li key={o} className="flex gap-3 text-sm md:text-[15px] text-foreground/90">
                    <Check className="h-4 w-4 mt-0.5 shrink-0 text-primary" />
                    <span>{o}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-5xl px-4 sm:px-6 md:px-8 pb-12 md:pb-16">
          <h2 className="text-2xl md:text-3xl font-display font-extrabold uppercase tracking-tight">Process</h2>
          <div className="mt-6 grid gap-3 md:gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {service.process.map((p, i) => (
              <div key={p.step} className="glass-card p-5 md:p-6">
                <span className="font-mono text-[10px] tracking-[0.3em] text-muted-foreground">0{i + 1}</span>
                <h3 className="mt-2 text-lg font-bold">{p.step}</h3>
                <p className="mt-2 text-[13px] md:text-sm text-muted-foreground leading-relaxed">{p.detail}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="mx-auto max-w-5xl px-4 sm:px-6 md:px-8 pb-12 md:pb-16">
          <h2 className="text-2xl md:text-3xl font-display font-extrabold uppercase tracking-tight">FAQ</h2>
          <div className="mt-6 grid gap-3 md:gap-4 md:grid-cols-2">
            {service.faq.map((f) => (
              <div key={f.q} className="glass-card p-5 md:p-6">
                <h3 className="text-sm md:text-base font-bold">{f.q}</h3>
                <p className="mt-2 text-[13px] md:text-sm text-muted-foreground leading-relaxed">{f.a}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="mx-auto max-w-5xl px-4 sm:px-6 md:px-8 pb-16 md:pb-24">
          <div className="glass-card shadow-card-elevated relative overflow-hidden p-6 sm:p-10 md:p-14 text-center">
            <div className="absolute inset-0 opacity-50" style={{ background: "var(--gradient-glow)" }} />
            <div className="relative">
              <h2 className="text-2xl sm:text-3xl md:text-5xl font-display font-extrabold uppercase leading-[1.05] tracking-tight">
                Ready to start <span className="text-gradient-primary">{service.t.toLowerCase()}?</span>
              </h2>
              <p className="mt-4 mx-auto max-w-2xl text-sm md:text-base text-muted-foreground leading-relaxed">
                Book a free consultation and we'll map out exactly what this looks like for your project.
              </p>
              <div className="mt-6 flex flex-wrap justify-center gap-3">
                <Link
                  to="/contact"
                  search={{ service: service.slug }}
                  className="inline-flex items-center gap-2 rounded-full bg-gradient-primary px-6 py-3.5 md:px-7 md:py-4 text-sm md:text-base font-semibold text-primary-foreground transition-all hover:scale-[1.02] glow-primary"
                >
                  Start Inquiry <ArrowRight className="h-4 w-4" />
                </Link>
                <a href={CONSULT_URL} className="inline-flex items-center gap-2 rounded-full border border-border bg-card/50 px-6 py-3.5 md:px-7 md:py-4 text-sm md:text-base font-semibold transition-all hover:bg-card hover:border-primary/40">
                  <Calendar className="h-4 w-4" /> Book Consultation
                </a>
              </div>
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-5xl px-4 sm:px-6 md:px-8 pb-16 md:pb-24">
          <div className="flex items-end justify-between gap-4">
            <h2 className="text-xl md:text-2xl font-display font-extrabold uppercase tracking-tight">Other services</h2>
            <Link to="/" hash="services" className="text-xs font-semibold uppercase tracking-widest text-muted-foreground hover:text-foreground">View all</Link>
          </div>
          <div className="mt-5 grid gap-3 md:gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {others.map((s) => {
              const OIcon = s.icon;
              return (
                <Link key={s.slug} to="/services/$slug" params={{ slug: s.slug }} className="glass-card p-5 md:p-6 group block transition-all hover:border-primary/40 hover:-translate-y-1">
                  <div className="flex items-center justify-between">
                    <div className="grid h-10 w-10 place-items-center rounded-xl bg-secondary border border-border text-primary group-hover:bg-gradient-primary group-hover:text-primary-foreground group-hover:border-transparent transition-all">
                      <OIcon className="h-5 w-5" />
                    </div>
                    <span className="font-mono text-[10px] tracking-[0.3em] text-muted-foreground">{s.n}</span>
                  </div>
                  <h3 className="mt-4 text-base font-bold leading-tight">{s.t}</h3>
                  <span className="mt-3 inline-flex items-center gap-1.5 text-xs font-semibold text-primary">
                    Learn about {s.t} <ArrowRight className="h-3.5 w-3.5" />
                  </span>
                </Link>
              );
            })}
          </div>
        </section>
      </main>

      <footer className="relative z-10 border-t border-border">
        <div className="mx-auto flex max-w-7xl flex-col gap-3 px-4 py-8 sm:px-5 md:px-8 md:py-10 md:flex-row md:items-center md:justify-between">
          <div className="flex items-center gap-2.5">
            <img src={logo.url} alt="Mikewavs" className="h-7 w-auto object-contain" />
            <span className="text-sm font-bold text-muted-foreground">© 2026 | Mikewavs All Rights Reserved</span>
          </div>
          <p className="text-[11px] md:text-sm text-muted-foreground tracking-wide">
            Digital Strategy • Web Design • Direct-To-Fan Systems
          </p>
        </div>
      </footer>
      <StickyRolloutCTA />
    </div>
  );
}