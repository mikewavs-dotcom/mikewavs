import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useMemo, useState } from "react";
import { ChevronDown, ChevronUp, Search, ShieldAlert, Loader2 } from "lucide-react";
import {
  listRolloutLeads,
  updateRolloutLead,
  LEAD_STATUSES,
  type AdminLead,
  type AdminLeadsResult,
  type LeadStatus,
} from "@/lib/admin-leads.functions";

export const Route = createFileRoute("/_authenticated/admin/music-rollout-leads")({
  head: () => ({
    meta: [
      { title: "Rollout Leads — Admin | Mikewavs" },
      { name: "robots", content: "noindex,nofollow" },
    ],
  }),
  errorComponent: ({ error, reset }) => {
    const router = useRouter();
    return (
      <div className="min-h-screen bg-background text-foreground flex items-center justify-center p-6">
        <div className="max-w-md text-center">
          <h1 className="font-display text-2xl font-extrabold uppercase">Something broke</h1>
          <p className="mt-3 text-sm text-muted-foreground">{error.message}</p>
          <button onClick={() => { reset(); router.invalidate(); }} className="mt-6 rounded-full bg-gradient-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground">Retry</button>
        </div>
      </div>
    );
  },
  notFoundComponent: () => (
    <div className="min-h-screen flex items-center justify-center bg-background text-foreground">Not found.</div>
  ),
  component: AdminLeadsPage,
});

type SortKey = "newest" | "highest" | "lowest";

function categoryFromScore(score: number): string {
  if (score < 40) return "0–39";
  if (score < 70) return "40–69";
  if (score < 90) return "70–89";
  return "90–100";
}

function AdminLeadsPage() {
  const list = useServerFn(listRolloutLeads);
  const [data, setData] = useState<AdminLeadsResult | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [search, setSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<string>("all");
  const [roleFilter, setRoleFilter] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [sort, setSort] = useState<SortKey>("newest");

  async function refresh() {
    setLoading(true);
    setLoadError(null);
    try {
      const r = await list();
      setData(r);
    } catch (e) {
      setLoadError(e instanceof Error ? e.message : "Failed to load leads.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { void refresh(); }, []);

  const roles = useMemo(() => {
    if (!data || !data.ok) return [];
    return Array.from(new Set(data.leads.map((l) => l.role).filter(Boolean))) as string[];
  }, [data]);

  const filtered = useMemo(() => {
    if (!data || !data.ok) return [];
    const q = search.trim().toLowerCase();
    let rows = data.leads.filter((l) => {
      if (q) {
        const hay = `${l.name} ${l.email} ${l.artist_company_name ?? ""}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      if (categoryFilter !== "all" && categoryFromScore(l.score ?? 0) !== categoryFilter) return false;
      if (roleFilter !== "all" && l.role !== roleFilter) return false;
      if (statusFilter !== "all" && l.lead_status !== statusFilter) return false;
      return true;
    });
    if (sort === "highest") rows = [...rows].sort((a, b) => (b.score ?? 0) - (a.score ?? 0));
    else if (sort === "lowest") rows = [...rows].sort((a, b) => (a.score ?? 0) - (b.score ?? 0));
    else rows = [...rows].sort((a, b) => +new Date(b.created_at) - +new Date(a.created_at));
    return rows;
  }, [data, search, categoryFilter, roleFilter, statusFilter, sort]);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="border-b border-border">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-5 sm:px-5 md:px-8">
          <Link to="/" className="font-display text-base font-extrabold uppercase tracking-tight">Mikewavs</Link>
          <div className="flex items-center gap-3 text-xs sm:text-sm">
            <Link to="/account" className="text-muted-foreground hover:text-foreground transition-colors">Account</Link>
            <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-primary">Admin</span>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 py-10 sm:px-5 md:px-8">
        <div className="flex flex-col gap-2">
          <div className="font-mono text-[10px] uppercase tracking-[0.35em] text-primary">Rollout Leads</div>
          <h1 className="font-display text-2xl sm:text-3xl md:text-4xl font-extrabold uppercase leading-[1.05] tracking-tight">
            Music Rollout Builder — Leads
          </h1>
        </div>

        {loading ? (
          <div className="mt-12 flex items-center gap-3 text-sm text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" /> Loading leads…</div>
        ) : loadError ? (
          <div className="mt-10 rounded-2xl border border-secondary/40 bg-secondary/10 p-6 text-sm">
            <div className="flex items-start gap-3"><ShieldAlert className="h-5 w-5 text-secondary shrink-0" /><div>{loadError}</div></div>
          </div>
        ) : data && !data.ok ? (
          <div className="mt-10 rounded-2xl border border-secondary/40 bg-secondary/10 p-6">
            <div className="flex items-start gap-3">
              <ShieldAlert className="h-5 w-5 text-secondary shrink-0" />
              <div>
                <div className="font-semibold">Access denied</div>
                <p className="mt-1 text-sm text-muted-foreground">Your account doesn't have admin access. Contact the site owner to be granted the admin role.</p>
              </div>
            </div>
          </div>
        ) : data && data.ok ? (
          <>
            <StatsRow stats={data.stats} />
            <Controls
              search={search} setSearch={setSearch}
              categoryFilter={categoryFilter} setCategoryFilter={setCategoryFilter}
              roleFilter={roleFilter} setRoleFilter={setRoleFilter}
              statusFilter={statusFilter} setStatusFilter={setStatusFilter}
              sort={sort} setSort={setSort}
              roles={roles}
            />
            <LeadsTable leads={filtered} onUpdated={refresh} />
          </>
        ) : null}
      </main>
    </div>
  );
}

function StatCard({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="rounded-2xl border border-border bg-card/40 p-4">
      <div className="font-mono text-[10px] uppercase tracking-[0.3em] text-muted-foreground">{label}</div>
      <div className="mt-2 font-display text-2xl font-extrabold">{value}</div>
    </div>
  );
}

function StatsRow({ stats }: { stats: { total: number; newCount: number; avgScore: number; highest: number; lowest: number } }) {
  return (
    <div className="mt-8 grid gap-3 grid-cols-2 sm:grid-cols-3 lg:grid-cols-5">
      <StatCard label="Total leads" value={stats.total} />
      <StatCard label="New" value={stats.newCount} />
      <StatCard label="Avg score" value={stats.total ? stats.avgScore : "—"} />
      <StatCard label="Highest" value={stats.total ? stats.highest : "—"} />
      <StatCard label="Lowest" value={stats.total ? stats.lowest : "—"} />
    </div>
  );
}

function Controls(props: {
  search: string; setSearch: (v: string) => void;
  categoryFilter: string; setCategoryFilter: (v: string) => void;
  roleFilter: string; setRoleFilter: (v: string) => void;
  statusFilter: string; setStatusFilter: (v: string) => void;
  sort: SortKey; setSort: (v: SortKey) => void;
  roles: string[];
}) {
  const sel = "rounded-xl border border-border bg-card/40 px-3 py-2 text-sm text-foreground focus:outline-none focus:border-primary/60";
  return (
    <div className="mt-6 grid gap-3 md:grid-cols-[1fr_auto_auto_auto_auto]">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <input
          value={props.search} onChange={(e) => props.setSearch(e.target.value)}
          placeholder="Search name, email, artist/company…"
          className="w-full rounded-xl border border-border bg-card/40 pl-9 pr-3 py-2 text-sm focus:outline-none focus:border-primary/60"
        />
      </div>
      <select className={sel} value={props.categoryFilter} onChange={(e) => props.setCategoryFilter(e.target.value)}>
        <option value="all">All categories</option>
        <option value="0–39">0–39</option>
        <option value="40–69">40–69</option>
        <option value="70–89">70–89</option>
        <option value="90–100">90–100</option>
      </select>
      <select className={sel} value={props.roleFilter} onChange={(e) => props.setRoleFilter(e.target.value)}>
        <option value="all">All roles</option>
        {props.roles.map((r) => <option key={r} value={r}>{r}</option>)}
      </select>
      <select className={sel} value={props.statusFilter} onChange={(e) => props.setStatusFilter(e.target.value)}>
        <option value="all">All statuses</option>
        {LEAD_STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
      </select>
      <select className={sel} value={props.sort} onChange={(e) => props.setSort(e.target.value as SortKey)}>
        <option value="newest">Newest first</option>
        <option value="highest">Highest score</option>
        <option value="lowest">Lowest score</option>
      </select>
    </div>
  );
}

function LeadsTable({ leads, onUpdated }: { leads: AdminLead[]; onUpdated: () => void }) {
  if (leads.length === 0) {
    return <div className="mt-8 rounded-2xl border border-border bg-card/30 p-8 text-sm text-muted-foreground text-center">No leads match the current filters.</div>;
  }
  return (
    <div className="mt-6 overflow-hidden rounded-2xl border border-border">
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-card/60">
            <tr className="text-left font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
              <th className="px-3 py-3"></th>
              <th className="px-3 py-3">Date</th>
              <th className="px-3 py-3">Name</th>
              <th className="px-3 py-3">Email</th>
              <th className="px-3 py-3">Artist / Company</th>
              <th className="px-3 py-3">Role</th>
              <th className="px-3 py-3">Release</th>
              <th className="px-3 py-3">Goal</th>
              <th className="px-3 py-3 text-right">Score</th>
              <th className="px-3 py-3">Status</th>
            </tr>
          </thead>
          <tbody>
            {leads.map((l) => <LeadRow key={l.id} lead={l} onUpdated={onUpdated} />)}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function statusBadgeCls(status: LeadStatus) {
  switch (status) {
    case "New": return "bg-primary/15 text-primary border-primary/30";
    case "Reviewed": return "bg-muted/30 text-foreground border-border";
    case "Hot Lead": return "bg-secondary/20 text-secondary border-secondary/40";
    case "Contacted": return "bg-card text-foreground border-border";
    case "Booked": return "bg-emerald-500/15 text-emerald-300 border-emerald-500/30";
    case "Not a Fit": return "bg-muted/20 text-muted-foreground border-border";
  }
}

function LeadRow({ lead, onUpdated }: { lead: AdminLead; onUpdated: () => void }) {
  const update = useServerFn(updateRolloutLead);
  const [open, setOpen] = useState(false);
  const [status, setStatus] = useState<LeadStatus>(lead.lead_status);
  const [notes, setNotes] = useState(lead.notes ?? "");
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState<string | null>(null);

  async function save() {
    setSaving(true);
    setSaved(null);
    try {
      await update({ data: { id: lead.id, lead_status: status, notes: notes || null } });
      setSaved("Saved.");
      onUpdated();
    } catch (e) {
      setSaved(e instanceof Error ? e.message : "Save failed.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <>
      <tr className="border-t border-border hover:bg-card/30">
        <td className="px-3 py-3">
          <button onClick={() => setOpen((o) => !o)} className="rounded-md border border-border p-1.5 text-muted-foreground hover:text-foreground">
            {open ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
          </button>
        </td>
        <td className="px-3 py-3 whitespace-nowrap text-muted-foreground">{new Date(lead.created_at).toLocaleDateString()}</td>
        <td className="px-3 py-3 font-medium">{lead.name}</td>
        <td className="px-3 py-3 text-muted-foreground"><a href={`mailto:${lead.email}`} className="hover:text-foreground">{lead.email}</a></td>
        <td className="px-3 py-3">{lead.artist_company_name ?? "—"}</td>
        <td className="px-3 py-3 text-muted-foreground">{lead.role ?? "—"}</td>
        <td className="px-3 py-3 text-muted-foreground whitespace-nowrap">{lead.release_type ?? "—"}{lead.release_date ? ` · ${lead.release_date}` : ""}</td>
        <td className="px-3 py-3 text-muted-foreground">{lead.main_goal ?? "—"}</td>
        <td className="px-3 py-3 text-right font-mono">{lead.score ?? "—"}</td>
        <td className="px-3 py-3">
          <span className={`inline-flex rounded-full border px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wider ${statusBadgeCls(lead.lead_status)}`}>{lead.lead_status}</span>
        </td>
      </tr>
      {open ? (
        <tr className="border-t border-border bg-card/20">
          <td colSpan={10} className="px-3 py-5">
            <div className="grid gap-5 md:grid-cols-3">
              <div>
                <div className="font-mono text-[10px] uppercase tracking-[0.3em] text-primary">Has</div>
                <ul className="mt-2 space-y-1 text-sm">
                  {Object.entries({
                    Website: lead.has_website,
                    "Email capture": lead.has_email_capture,
                    "SMS capture": lead.has_sms_capture,
                    CRM: lead.has_crm,
                    Merch: lead.has_merch,
                    "Content plan": lead.has_content_plan,
                    "Smart link": lead.has_smart_link,
                    Tracking: lead.has_tracking,
                    "Post-release plan": lead.has_post_release_plan,
                  }).filter(([, v]) => v).map(([k]) => <li key={k}>✓ {k}</li>)}
                </ul>
              </div>
              <div>
                <div className="font-mono text-[10px] uppercase tracking-[0.3em] text-secondary">Missing</div>
                <ul className="mt-2 space-y-1 text-sm">
                  {(lead.missing_items ?? []).map((m) => <li key={m}>✗ {m}</li>)}
                </ul>
                <div className="mt-4 font-mono text-[10px] uppercase tracking-[0.3em] text-primary">Recommended services</div>
                <ul className="mt-2 space-y-1 text-sm">
                  {(lead.recommended_services ?? []).map((s) => <li key={s}>• {s}</li>)}
                </ul>
              </div>
              <div>
                <label className="block">
                  <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-muted-foreground">Lead status</span>
                  <select value={status} onChange={(e) => setStatus(e.target.value as LeadStatus)} className="mt-2 w-full rounded-xl border border-border bg-card/40 px-3 py-2 text-sm">
                    {LEAD_STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                  </select>
                </label>
                <label className="mt-4 block">
                  <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-muted-foreground">Notes</span>
                  <textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={4} className="mt-2 w-full rounded-xl border border-border bg-card/40 px-3 py-2 text-sm" />
                </label>
                <div className="mt-3 flex items-center gap-3">
                  <button onClick={save} disabled={saving} className="rounded-full bg-gradient-primary px-4 py-2 text-xs font-semibold text-primary-foreground disabled:opacity-60">
                    {saving ? "Saving…" : "Save changes"}
                  </button>
                  {saved ? <span className="text-xs text-muted-foreground">{saved}</span> : null}
                </div>
              </div>
            </div>
          </td>
        </tr>
      ) : null}
    </>
  );
}