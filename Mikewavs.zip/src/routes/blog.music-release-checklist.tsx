import { createFileRoute } from "@tanstack/react-router";
import { BlogPostLayout, blogPostHead } from "@/components/blog/BlogPostLayout";
import { postBySlug } from "@/lib/blog-posts";

const post = postBySlug("music-release-checklist")!;

export const Route = createFileRoute("/blog/music-release-checklist")({
  head: () => blogPostHead(post),
  component: () => <BlogPostLayout post={post} />,
});