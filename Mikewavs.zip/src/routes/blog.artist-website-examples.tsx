import { createFileRoute } from "@tanstack/react-router";
import { BlogPostLayout, blogPostHead } from "@/components/blog/BlogPostLayout";
import { postBySlug } from "@/lib/blog-posts";

const post = postBySlug("artist-website-examples")!;

export const Route = createFileRoute("/blog/artist-website-examples")({
  head: () => blogPostHead(post),
  component: () => <BlogPostLayout post={post} />,
});