import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import { getService } from "@/lib/services-data";
import { siteUrl } from "@/lib/site";
import { ContactPageInner } from "@/components/contact/ContactPageInner";

const searchSchema = z.object({
  service: z.string().optional(),
});

export const Route = createFileRoute("/contact")({
  validateSearch: (s) => searchSchema.parse(s),
  head: () => ({
    meta: [
      { title: "Contact Mikewavs — Start your inquiry" },
      {
        name: "description",
        content:
          "Tell Mikewavs about your project and get a tailored response. In-depth inquiry form for artist marketing, websites, CRM, content, merch, analytics, and more.",
      },
      { property: "og:title", content: "Contact Mikewavs — Start your inquiry" },
      {
        property: "og:description",
        content:
          "Share your goals, timeline, and what you need. Mike will reply directly from mike@nocoolpoints.com.",
      },
      { property: "og:url", content: siteUrl("/contact") },
      { property: "og:type", content: "website" },
    ],
    links: [{ rel: "canonical", href: siteUrl("/contact") }],
  }),
  component: ContactPage,
  errorComponent: ({ error, reset }) => (
    <div className="min-h-screen bg-background text-foreground grid place-items-center px-6">
      <div className="text-center">
        <h1 className="text-2xl font-display font-extrabold uppercase">Something went wrong</h1>
        <p className="mt-2 text-sm text-muted-foreground">{error.message}</p>
        <button onClick={reset} className="mt-5 rounded-full border border-border px-5 py-2.5 text-sm">
          Try again
        </button>
      </div>
    </div>
  ),
});

function ContactPage() {
  const search = Route.useSearch();
  const preselected = search.service && getService(search.service) ? search.service : "";
  return <ContactPageInner preselected={preselected} />;
}
