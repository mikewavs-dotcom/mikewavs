import { createFileRoute } from '@tanstack/react-router'
import { useEffect, useState } from 'react'

type State =
  | { kind: 'loading' }
  | { kind: 'invalid' }
  | { kind: 'already' }
  | { kind: 'confirm' }
  | { kind: 'submitting' }
  | { kind: 'success' }
  | { kind: 'error'; message: string }

function UnsubscribePage() {
  const [state, setState] = useState<State>({ kind: 'loading' })
  const [token, setToken] = useState<string | null>(null)

  useEffect(() => {
    const t = new URLSearchParams(window.location.search).get('token')
    if (!t) {
      setState({ kind: 'invalid' })
      return
    }
    setToken(t)
    fetch(`/email/unsubscribe?token=${encodeURIComponent(t)}`)
      .then(async (r) => {
        const json = await r.json().catch(() => ({}))
        if (!r.ok) return setState({ kind: 'invalid' })
        if (json.valid === false && json.reason === 'already_unsubscribed') {
          return setState({ kind: 'already' })
        }
        if (json.valid) return setState({ kind: 'confirm' })
        setState({ kind: 'invalid' })
      })
      .catch(() => setState({ kind: 'invalid' }))
  }, [])

  async function confirm() {
    if (!token) return
    setState({ kind: 'submitting' })
    try {
      const r = await fetch('/email/unsubscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token }),
      })
      const json = await r.json().catch(() => ({}))
      if (!r.ok) return setState({ kind: 'error', message: json.error || 'Failed to unsubscribe' })
      if (json.success) return setState({ kind: 'success' })
      if (json.reason === 'already_unsubscribed') return setState({ kind: 'already' })
      setState({ kind: 'error', message: 'Could not complete unsubscribe' })
    } catch (err) {
      setState({ kind: 'error', message: err instanceof Error ? err.message : 'Network error' })
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md w-full text-center space-y-4">
        <h1 className="text-2xl font-semibold text-foreground">Unsubscribe</h1>
        {state.kind === 'loading' && (
          <p className="text-sm text-muted-foreground">Checking your link…</p>
        )}
        {state.kind === 'invalid' && (
          <p className="text-sm text-muted-foreground">
            This unsubscribe link is invalid or expired.
          </p>
        )}
        {state.kind === 'already' && (
          <p className="text-sm text-muted-foreground">
            You're already unsubscribed. You won't receive further emails.
          </p>
        )}
        {(state.kind === 'confirm' || state.kind === 'submitting') && (
          <>
            <p className="text-sm text-muted-foreground">
              Click below to unsubscribe from Mikewavs emails.
            </p>
            <button
              onClick={confirm}
              disabled={state.kind === 'submitting'}
              className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90 disabled:opacity-60"
            >
              {state.kind === 'submitting' ? 'Unsubscribing…' : 'Confirm unsubscribe'}
            </button>
          </>
        )}
        {state.kind === 'success' && (
          <p className="text-sm text-foreground">You've been unsubscribed. Sorry to see you go.</p>
        )}
        {state.kind === 'error' && (
          <p className="text-sm text-destructive">{state.message}</p>
        )}
      </div>
    </div>
  )
}

export const Route = createFileRoute('/unsubscribe')({
  head: () => ({
    meta: [
      { title: "Unsubscribe — Mikewavs" },
      { name: "description", content: "Unsubscribe from Mikewavs emails." },
      { name: "robots", content: "noindex,nofollow" },
      { property: "og:title", content: "Unsubscribe — Mikewavs" },
      { property: "og:description", content: "Unsubscribe from Mikewavs emails." },
      { property: "og:type", content: "website" },
    ],
  }),
  component: UnsubscribePage,
})