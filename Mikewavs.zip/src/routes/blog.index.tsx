import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Calendar } from "lucide-react";
import { InstagramLink } from "@/components/InstagramLink";
import logo from "@/assets/mikewavs-logo.png.asset.json";
import { CONSULT_URL } from "@/lib/services-data";
import { posts, formatPostDate } from "@/lib/blog-posts";
import { EmailCaptureCard } from "@/components/blog/EmailCaptureCard";
import { siteUrl } from "@/lib/site";

const URL_ = siteUrl("/blog");
const TITLE = "Artist Resources — Digital Strategy | Mikewavs";
const DESC =
  "Field notes from a music digital strategist: release rollouts, artist websites, fan capture, and direct-to-fan systems that compound.";

export const Route = createFileRoute("/blog/")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:url", content: URL_ },
      { property: "og:type", content: "website" },
    ],
    links: [{ rel: "canonical", href: URL_ }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Blog",
          name: "Mikewavs Artist Resources",
          url: URL_,
          description: DESC,
          blogPost: posts.map((p) => ({
            "@type": "BlogPosting",
            headline: p.metaTitle,
            url: `${URL_}/${p.slug}`,
            datePublished: p.published,
          })),
        }),
      },
    ],
  }),
  component: BlogIndex,
});

function BlogIndex() {
  const sorted = [...posts].sort((a, b) => (a.published < b.published ? 1 : -1));
  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      <div aria-hidden className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
        <div className="absolute -top-40 left-1/2 h-[600px] w-[1200px] -translate-x-1/2 opacity-60" style={{ background: "var(--gradient-glow)" }} />
      </div>

      <header className="sticky top-0 z-50 border-b border-border/40 backdrop-blur-xl bg-background/70">
        <div className="mx-auto grid grid-cols-[auto_1fr_auto] items-center gap-3 max-w-7xl px-4 py-3 md:px-8 md:py-4">
          <Link to="/" className="flex items-center gap-2">
            <img src={logo.url} alt="Mikewavs" className="h-7 w-auto md:h-8 object-contain" />
          </Link>
          <nav className="hidden md:flex justify-center items-center gap-6 text-xs font-mono uppercase tracking-widest text-muted-foreground">
            <Link to="/" className="hover:text-foreground transition-colors">Home</Link>
            <Link to="/blog" className="text-foreground">Artist Resources</Link>
          </nav>
          <div className="flex items-center gap-2 md:gap-3">
            <InstagramLink />
            <a href={CONSULT_URL} className="inline-flex items-center gap-2 rounded-full bg-gradient-primary px-4 py-2 md:px-5 md:py-2.5 text-xs md:text-sm font-semibold text-primary-foreground glow-primary">
              <Calendar className="h-4 w-4" /> Book
            </a>
          </div>
        </div>
      </header>

      <main className="relative z-10">
        <section className="mx-auto max-w-5xl px-4 pt-10 pb-8 sm:px-6 sm:pt-14 md:px-8 md:pt-20 md:pb-14">
          <p className="text-[10px] sm:text-xs font-mono uppercase tracking-widest text-accent-muted">[ 00 // FIELD NOTES ]</p>
          <h1 className="mt-4 text-[2.25rem] sm:text-5xl md:text-6xl lg:text-[5.5rem] font-display font-black uppercase leading-[0.95] tracking-tight [overflow-wrap:anywhere]">
            Artist<br className="sm:hidden" /> Resources.
          </h1>
          <p className="mt-5 max-w-2xl text-[15px] sm:text-base md:text-lg text-muted-foreground leading-relaxed">
            Working notes from inside artist and label rollouts — what's working in release marketing, direct-to-fan, and digital
            strategy for music. Practical, not theoretical.
          </p>
          <div className="mt-8 max-w-2xl">
            <EmailCaptureCard variant="inline" source="blog-index-hero" />
          </div>
        </section>

        <section className="mx-auto max-w-5xl px-4 pb-16 sm:px-6 md:px-8 md:pb-28">
          <ul className="divide-y divide-border/60 border-y border-border/60">
            {sorted.map((p, i) => (
              <li key={p.slug}>
                <a
                  href={`/blog/${p.slug}`}
                  className="group grid grid-cols-[auto_minmax(0,1fr)] md:grid-cols-[auto_minmax(0,1fr)_auto] items-start gap-x-4 md:gap-x-8 py-5 sm:py-6 md:py-8 hover:bg-card/30 transition-colors px-1 md:px-2"
                >
                  <span className="font-mono text-[11px] sm:text-xs md:text-sm text-muted-foreground tabular-nums pt-[2px] md:pt-1 shrink-0">
                    {String(sorted.length - i).padStart(2, "0")}
                  </span>
                  <div className="min-w-0">
                    <p className="text-[10px] md:text-xs font-mono uppercase tracking-widest text-accent-muted [overflow-wrap:anywhere]">
                      {p.category} · {formatPostDate(p.published, "short")} · {p.readingTime}
                    </p>
                    <h2 className="mt-2 text-[1.125rem] sm:text-2xl md:text-3xl font-display font-bold uppercase leading-[1.15] tracking-tight group-hover:text-primary transition-colors [overflow-wrap:anywhere] hyphens-auto">
                      {p.metaTitle}
                    </h2>
                    <p className="mt-2 text-[13px] sm:text-sm md:text-base text-muted-foreground leading-relaxed line-clamp-2 sm:line-clamp-3">
                      {p.description}
                    </p>
                  </div>
                  <ArrowRight className="hidden md:block h-5 w-5 mt-2 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all shrink-0" />
                </a>
              </li>
            ))}
          </ul>

          <div className="glass-card shadow-card-elevated relative overflow-hidden mt-12 sm:mt-14 p-6 sm:p-10 md:p-12 text-center">
            <div className="absolute inset-0 opacity-50" style={{ background: "var(--gradient-glow)" }} />
            <div className="relative">
              <p className="text-[10px] sm:text-xs font-mono uppercase tracking-widest text-accent-muted">[ Work with Mikewavs ]</p>
              <h2 className="mt-3 text-[1.5rem] sm:text-3xl md:text-4xl font-display font-black uppercase leading-[1.05] tracking-tight [overflow-wrap:anywhere]">
                Need a strategist on your next <span className="text-gradient-primary">release?</span>
              </h2>
              <a href={CONSULT_URL} className="mt-6 inline-flex items-center gap-2 rounded-full bg-gradient-primary px-6 py-3.5 text-sm md:text-base font-semibold text-primary-foreground transition-all hover:scale-[1.02] glow-primary">
                <Calendar className="h-4 w-4" /> Book Consultation
              </a>
            </div>
          </div>
        </section>
      </main>

      <footer className="relative z-10 border-t border-border">
        <div className="mx-auto flex max-w-7xl flex-col gap-3 px-4 py-8 sm:px-5 md:px-8 md:py-10 md:flex-row md:items-center md:justify-between">
          <div className="flex items-center gap-2.5">
            <img src={logo.url} alt="Mikewavs" className="h-7 w-auto object-contain" />
            <span className="text-sm font-bold text-muted-foreground">© 2026 | Mikewavs All Rights Reserved</span>
          </div>
          <p className="text-[11px] md:text-sm font-mono uppercase tracking-widest text-muted-foreground">
            Digital Strategy · Web Design · Direct-To-Fan Systems
          </p>
        </div>
      </footer>
    </div>
  );
}