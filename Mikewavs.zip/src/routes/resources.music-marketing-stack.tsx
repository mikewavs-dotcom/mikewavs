import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, Calendar, ExternalLink, Star } from "lucide-react";
import { InstagramLink } from "@/components/InstagramLink";
import { StickyRolloutCTA } from "@/components/StickyRolloutCTA";
import logo from "@/assets/mikewavs-logo.png.asset.json";
import { CONSULT_URL } from "@/lib/services-data";
import { SITE_URL, siteUrl } from "@/lib/site";
import { stackCategories, STACK_LAST_UPDATED } from "@/lib/marketing-stack-data";

const PAGE_URL = siteUrl("/resources/music-marketing-stack");
const TITLE = "The Independent Music Marketing Stack (2026) — Mikewavs";
const DESCRIPTION =
  "An opinionated, regularly updated directory of the tools artists, managers, and labels actually use to release music, capture fans, and run direct-to-fan campaigns in 2026.";

function formatUpdated(iso: string) {
  return new Date(iso + "T00:00:00Z").toLocaleDateString("en-US", {
    month: "long",
    day: "numeric",
    year: "numeric",
    timeZone: "UTC",
  });
}

export const Route = createFileRoute("/resources/music-marketing-stack")({
  head: () => {
    const itemListElements = stackCategories.flatMap((cat, ci) =>
      cat.tools.map((tool, ti) => ({
        "@type": "ListItem",
        position: ci * 100 + ti + 1,
        item: {
          "@type": "SoftwareApplication",
          name: tool.name,
          url: tool.url,
          applicationCategory: cat.title,
          description: tool.verdict,
        },
      })),
    );
    return {
      meta: [
        { title: TITLE },
        { name: "description", content: DESCRIPTION },
        { name: "author", content: "Mike Wavs" },
        { property: "og:title", content: TITLE },
        { property: "og:description", content: DESCRIPTION },
        { property: "og:url", content: PAGE_URL },
        { property: "og:type", content: "article" },
        { name: "twitter:card", content: "summary_large_image" },
        { name: "twitter:title", content: TITLE },
        { name: "twitter:description", content: DESCRIPTION },
      ],
      links: [{ rel: "canonical", href: PAGE_URL }],
      scripts: [
        {
          type: "application/ld+json",
          children: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Article",
            headline: TITLE,
            description: DESCRIPTION,
            datePublished: STACK_LAST_UPDATED,
            dateModified: STACK_LAST_UPDATED,
            inLanguage: "en-US",
            url: PAGE_URL,
            mainEntityOfPage: { "@type": "WebPage", "@id": PAGE_URL },
            author: {
              "@type": "Person",
              name: "Mike Wavs",
              jobTitle: "Music Digital Strategist",
              url: SITE_URL,
            },
            publisher: { "@type": "Organization", name: "Mikewavs", url: SITE_URL },
          }),
        },
        {
          type: "application/ld+json",
          children: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "ItemList",
            name: "The Independent Music Marketing Stack 2026",
            itemListElement: itemListElements,
          }),
        },
        {
          type: "application/ld+json",
          children: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            itemListElement: [
              { "@type": "ListItem", position: 1, name: "Home", item: SITE_URL },
              { "@type": "ListItem", position: 2, name: "Resources", item: siteUrl("/resources") },
              { "@type": "ListItem", position: 3, name: "Music Marketing Stack", item: PAGE_URL },
            ],
          }),
        },
      ],
    };
  },
  component: StackPage,
});

function StackPage() {
  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      <div aria-hidden className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
        <div className="absolute -top-40 left-1/2 h-[600px] w-[1200px] -translate-x-1/2 opacity-60" style={{ background: "var(--gradient-glow)" }} />
        <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, white 1px, transparent 0)", backgroundSize: "32px 32px" }} />
      </div>

      <header className="sticky top-0 z-50 border-b border-border/40 backdrop-blur-xl bg-background/70">
        <div className="mx-auto grid grid-cols-[auto_1fr_auto] items-center gap-3 max-w-7xl px-4 py-3 md:px-8 md:py-4">
          <Link to="/" className="flex items-center gap-2">
            <img src={logo.url} alt="Mikewavs" className="h-7 w-auto md:h-8 object-contain" />
          </Link>
          <nav className="hidden md:flex justify-center items-center gap-6 text-xs font-mono uppercase tracking-widest text-muted-foreground">
            <Link to="/" className="hover:text-foreground transition-colors">Home</Link>
            <Link to="/blog" className="hover:text-foreground transition-colors">Artist Resources</Link>
            <Link to="/contact" className="hover:text-foreground transition-colors">Contact</Link>
          </nav>
          <div className="flex items-center gap-2 md:gap-3">
            <InstagramLink />
            <a href={CONSULT_URL} className="inline-flex items-center gap-2 rounded-full bg-gradient-primary px-4 py-2 md:px-5 md:py-2.5 text-xs md:text-sm font-semibold text-primary-foreground glow-primary">
              <Calendar className="h-4 w-4" /> Book
            </a>
          </div>
        </div>
      </header>

      <main className="relative z-10">
        <section className="mx-auto max-w-5xl px-4 pt-10 pb-10 sm:px-6 md:px-8 md:pt-16 md:pb-14">
          <Link to="/" className="inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-widest text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft className="h-3.5 w-3.5" /> Back home
          </Link>

          <p className="mt-6 text-[10px] sm:text-xs font-mono uppercase tracking-widest text-primary">
            Resource · Updated {formatUpdated(STACK_LAST_UPDATED)}
          </p>
          <h1 className="mt-3 text-4xl sm:text-5xl md:text-6xl font-display font-extrabold uppercase leading-[1.02] tracking-tight">
            The Independent Music Marketing Stack 2026
          </h1>
          <p className="mt-5 max-w-3xl text-base md:text-lg text-muted-foreground leading-relaxed">
            An opinionated, regularly updated directory of the tools artists, managers, and labels actually use to release music, capture fans, and run direct-to-fan campaigns in 2026. Curated by Mike Wavs from active client work — not affiliate links, not paid placements.
          </p>

          <div className="mt-7 flex flex-wrap gap-3">
            <a href="#categories" className="inline-flex items-center gap-2 rounded-full bg-gradient-primary px-6 py-3.5 text-sm font-semibold text-primary-foreground transition-all hover:scale-[1.02] glow-primary">
              Jump to the stack <ArrowRight className="h-4 w-4" />
            </a>
            <Link to="/tools/music-rollout-builder" className="inline-flex items-center gap-2 rounded-full border border-border bg-card/50 px-6 py-3.5 text-sm font-semibold transition-all hover:bg-card hover:border-primary/40">
              Score your rollout
            </Link>
          </div>
        </section>

        <section className="mx-auto max-w-5xl px-4 sm:px-6 md:px-8 pb-10 md:pb-14">
          <div className="glass-card p-6 md:p-8">
            <h2 className="font-mono text-[10px] uppercase tracking-[0.3em] text-accent-muted">How Mike picks tools</h2>
            <ul className="mt-4 grid gap-3 sm:grid-cols-3 text-[14px] sm:text-[15px] text-foreground/90 leading-relaxed">
              <li><span className="block font-bold text-foreground">Owns the data</span>Email, SMS, and pixels you control beat anything a platform rents you.</li>
              <li><span className="block font-bold text-foreground">Scales with the team</span>Should still work at 10× the audience without a full rebuild.</li>
              <li><span className="block font-bold text-foreground">Built for or proven in music</span>Generic SaaS misses release flows, splits, and fan behavior.</li>
            </ul>
          </div>
        </section>

        <section id="categories" className="mx-auto max-w-5xl px-4 sm:px-6 md:px-8 pb-10 md:pb-16">
          <h2 className="text-2xl md:text-3xl font-display font-extrabold uppercase tracking-tight">Categories</h2>
          <div className="mt-5 grid gap-2 sm:grid-cols-2 md:grid-cols-3">
            {stackCategories.map((cat) => (
              <a key={cat.id} href={`#${cat.id}`} className="rounded-xl border border-border bg-card/30 px-4 py-3 text-sm font-semibold transition-all hover:border-primary/40 hover:bg-card">
                {cat.title}
              </a>
            ))}
          </div>
        </section>

        {stackCategories.map((cat) => (
          <section key={cat.id} id={cat.id} className="mx-auto max-w-5xl px-4 sm:px-6 md:px-8 pb-12 md:pb-16 scroll-mt-24">
            <p className="font-mono text-[10px] uppercase tracking-[0.3em] text-accent-muted">Category</p>
            <h2 className="mt-2 text-2xl md:text-4xl font-display font-extrabold uppercase tracking-tight">{cat.title}</h2>
            <p className="mt-3 max-w-3xl text-sm md:text-base text-muted-foreground leading-relaxed">{cat.blurb}</p>

            <div className="mt-5 inline-flex items-center gap-2 rounded-full border border-primary/40 bg-primary/10 px-4 py-2 text-xs font-semibold text-primary">
              <Star className="h-3.5 w-3.5" /> Mikewavs default: {cat.defaultPick}
            </div>

            <div className="mt-6 grid gap-3 md:gap-4 md:grid-cols-2">
              {cat.tools.map((tool) => (
                <div key={tool.name} className="glass-card p-5 md:p-6 flex flex-col">
                  <div className="flex items-center justify-between gap-3">
                    <h3 className="text-lg font-bold">{tool.name}</h3>
                    <span className="font-mono text-[10px] uppercase tracking-[0.25em] text-muted-foreground">{tool.price}</span>
                  </div>
                  <p className="mt-2 text-[13px] md:text-sm text-foreground/90 leading-relaxed">{tool.verdict}</p>
                  <dl className="mt-4 space-y-2 text-[12.5px] md:text-[13px] text-muted-foreground leading-relaxed">
                    <div><dt className="inline font-semibold text-foreground/90">Best for: </dt><dd className="inline">{tool.bestFor}</dd></div>
                    <div><dt className="inline font-semibold text-foreground/90">Skip if: </dt><dd className="inline">{tool.skipIf}</dd></div>
                  </dl>
                  <a href={tool.url} target="_blank" rel="noopener noreferrer nofollow" className="mt-4 inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-widest text-primary hover:underline">
                    Visit {tool.name} <ExternalLink className="h-3 w-3" />
                  </a>
                </div>
              ))}
            </div>
          </section>
        ))}

        <section className="mx-auto max-w-5xl px-4 sm:px-6 md:px-8 pb-16 md:pb-24">
          <div className="glass-card shadow-card-elevated relative overflow-hidden p-6 sm:p-10 md:p-14 text-center">
            <div className="absolute inset-0 opacity-50" style={{ background: "var(--gradient-glow)" }} />
            <div className="relative">
              <p className="text-[10px] sm:text-xs font-mono uppercase tracking-widest text-primary">[ Work with Mikewavs ]</p>
              <h2 className="mt-3 text-2xl sm:text-3xl md:text-5xl font-display font-extrabold uppercase leading-[1.05] tracking-tight">
                The tools are easy. <span className="text-gradient-primary">The system is the hard part.</span>
              </h2>
              <p className="mt-4 mx-auto max-w-2xl text-sm md:text-base text-muted-foreground leading-relaxed">
                Knowing what to pick is 10% of the work. Wiring it together so every release compounds is the other 90%. That's what Mikewavs builds for artists and labels.
              </p>
              <div className="mt-6 flex flex-wrap justify-center gap-3">
                <Link to="/contact" className="inline-flex items-center gap-2 rounded-full bg-gradient-primary px-6 py-3.5 text-sm md:text-base font-semibold text-primary-foreground transition-all hover:scale-[1.02] glow-primary">
                  Start Inquiry <ArrowRight className="h-4 w-4" />
                </Link>
                <a href={CONSULT_URL} className="inline-flex items-center gap-2 rounded-full border border-border bg-card/50 px-6 py-3.5 text-sm md:text-base font-semibold transition-all hover:bg-card hover:border-primary/40">
                  <Calendar className="h-4 w-4" /> Book Consultation
                </a>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="relative z-10 border-t border-border">
        <div className="mx-auto flex max-w-7xl flex-col gap-3 px-4 py-8 sm:px-5 md:px-8 md:py-10 md:flex-row md:items-center md:justify-between">
          <div className="flex items-center gap-2.5">
            <img src={logo.url} alt="Mikewavs" className="h-7 w-auto object-contain" />
            <span className="text-sm font-bold text-muted-foreground">© 2026 | Mikewavs All Rights Reserved</span>
          </div>
          <p className="text-[11px] md:text-sm text-muted-foreground tracking-wide">
            Updated quarterly · Curated by Mike Wavs
          </p>
        </div>
      </footer>
      <StickyRolloutCTA />
    </div>
  );
}
