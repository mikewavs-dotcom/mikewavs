import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, Calendar, ExternalLink } from "lucide-react";
import logo from "@/assets/mikewavs-logo.png.asset.json";
import { CONSULT_URL } from "@/lib/services-data";
import { SITE_URL, siteUrl } from "@/lib/site";

const URL = siteUrl("/blog/music-industry-newsletters");
const TITLE = "Best Music Industry Newsletters for Artists & Managers (2026)";
const DESC =
  "A curated guide to the music industry newsletters artists, managers, and labels actually read — for digital strategy, release marketing, and fan growth.";
const PUBLISHED = "2026-06-10";

type Item = {
  name: string;
  url: string;
  bestFor: string;
  cadence: string;
  blurb: string;
};

const NEWSLETTERS: Item[] = [
  {
    name: "Trapital",
    url: "https://trapital.co",
    bestFor: "Hip-hop business strategy",
    cadence: "Weekly",
    blurb:
      "Dan Runcie's deep dives on the business of hip-hop — label economics, catalog deals, streaming, and artist-as-CEO breakdowns. Essential if you work with rap or R&B artists and want context behind the headlines.",
  },
  {
    name: "Water & Music",
    url: "https://www.waterandmusic.com",
    bestFor: "Music + tech research",
    cadence: "Weekly / research drops",
    blurb:
      "Research-driven coverage of where music meets technology — AI, web3, direct-to-fan tools, and platform shifts. The reports are paywalled but the free issues alone are a strong primer on what's coming next.",
  },
  {
    name: "Your Morning Coffee",
    url: "https://yourmorning.coffee",
    bestFor: "Daily industry digest",
    cadence: "Daily",
    blurb:
      "Jay Gilbert and Mike Etchart's daily roundup of the most important music-business stories. The fastest way to keep a pulse on labels, publishing, live, and tech without reading ten outlets.",
  },
  {
    name: "Music Business Worldwide",
    url: "https://www.musicbusinessworldwide.com",
    bestFor: "Deals, M&A, executive moves",
    cadence: "Daily",
    blurb:
      "The trade publication of record for global music business news. Strong on label deals, catalog acquisitions, and the major-label power map — useful when you're pitching or negotiating.",
  },
  {
    name: "Hypebot",
    url: "https://www.hypebot.com",
    bestFor: "Indie artists & DIY marketing",
    cadence: "Daily",
    blurb:
      "Practical news and how-tos aimed at independent artists, managers, and small labels. Heavier on tactics than think pieces — playlisting, distribution, social, and tooling.",
  },
  {
    name: "Penny Fractions",
    url: "https://pennyfractions.ghost.io",
    bestFor: "Streaming economics critique",
    cadence: "Weekly",
    blurb:
      "David Turner's running critique of streaming, playlisting, and the platform economy. Read it to sharpen how you talk about payouts and platform power with clients.",
  },
  {
    name: "The Lefsetz Letter",
    url: "https://lefsetz.com/wordpress/",
    bestFor: "Industry commentary",
    cadence: "Multiple per week",
    blurb:
      "Bob Lefsetz's long-running, opinionated take on the music business and culture. Polarizing on purpose — useful for the room-temperature read of how legacy industry feels about a story.",
  },
  {
    name: "RIP/PIT (CMU)",
    url: "https://www.completemusicupdate.com",
    bestFor: "Music law & policy",
    cadence: "Daily / weekly digests",
    blurb:
      "Complete Music Update's coverage of music law, rights, and policy — copyright, AI, streaming regulation. Niche but invaluable when contracts, sync, or rights are on the table.",
  },
];

export const Route = createFileRoute("/blog/music-industry-newsletters")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:url", content: URL },
      { property: "og:type", content: "article" },
    ],
    links: [{ rel: "canonical", href: URL }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Article",
          headline: TITLE,
          description: DESC,
          datePublished: PUBLISHED,
          dateModified: PUBLISHED,
          mainEntityOfPage: URL,
          author: { "@type": "Organization", name: "Mikewavs", url: SITE_URL },
          publisher: { "@type": "Organization", name: "Mikewavs", url: SITE_URL },
        }),
      },
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "ItemList",
          itemListElement: NEWSLETTERS.map((n, i) => ({
            "@type": "ListItem",
            position: i + 1,
            name: n.name,
            url: n.url,
          })),
        }),
      },
    ],
  }),
  component: NewslettersGuide,
});

function NewslettersGuide() {
  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      <div aria-hidden className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
        <div className="absolute -top-40 left-1/2 h-[600px] w-[1200px] -translate-x-1/2 opacity-60" style={{ background: "var(--gradient-glow)" }} />
      </div>

      <header className="sticky top-0 z-50 border-b border-border/40 backdrop-blur-xl bg-background/70">
        <div className="mx-auto grid grid-cols-[auto_1fr_auto] items-center gap-3 max-w-7xl px-4 py-3 md:px-8 md:py-4">
          <Link to="/" className="flex items-center gap-2">
            <img src={logo.url} alt="Mikewavs" className="h-7 w-auto md:h-8 object-contain" />
          </Link>
          <nav className="hidden md:flex justify-center items-center gap-6 text-xs font-mono uppercase tracking-widest text-muted-foreground">
            <Link to="/" className="hover:text-foreground transition-colors">Home</Link>
            <Link to="/blog" className="hover:text-foreground transition-colors">Artist Resources</Link>
          </nav>
          <a href={CONSULT_URL} className="inline-flex items-center gap-2 rounded-full bg-gradient-primary px-4 py-2 md:px-5 md:py-2.5 text-xs md:text-sm font-semibold text-primary-foreground glow-primary">
            <Calendar className="h-4 w-4" /> Book
          </a>
        </div>
      </header>

      <main className="relative z-10">
        <article className="mx-auto max-w-3xl px-4 pt-10 pb-16 sm:px-6 md:px-8 md:pt-16 md:pb-24">
          <Link to="/" className="inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-widest text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft className="h-3.5 w-3.5" /> Back to home
          </Link>

          <p className="mt-6 text-xs font-semibold uppercase tracking-widest text-primary">Guide · Digital Strategy</p>
          <h1 className="mt-3 text-3xl sm:text-4xl md:text-5xl font-black uppercase leading-[1.05] tracking-tight">
            The Best Music Industry Newsletters for Artists & Managers
          </h1>
          <p className="mt-5 text-base md:text-lg text-muted-foreground leading-relaxed">
            If you work in music — as an artist, a manager, at a label, or on the marketing side — staying informed isn't optional.
            The publications below are the ones we actually read at Mikewavs to track what's happening in releases, streaming, fan
            growth, and the business decisions shaping the industry. Pick two or three; don't try to subscribe to everything.
          </p>

          <h2 className="mt-12 text-2xl md:text-3xl font-black uppercase tracking-tight">How we picked these</h2>
          <p className="mt-4 text-sm md:text-base text-muted-foreground leading-relaxed">
            We weighted three things: signal-to-noise ratio (does each issue tell you something you didn't know?), relevance to
            day-to-day work in artist marketing and direct-to-fan strategy, and how often the writer is actually right about
            where the industry is heading. The list mixes daily news, weekly analysis, and slower research drops so you can build
            a reading rhythm that fits your schedule.
          </p>

          <h2 className="mt-12 text-2xl md:text-3xl font-black uppercase tracking-tight">The list</h2>
          <div className="mt-6 grid gap-4 md:gap-5">
            {NEWSLETTERS.map((n, i) => (
              <section key={n.name} className="glass-card p-6 md:p-7">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <span className="text-[11px] font-bold tracking-widest text-muted-foreground">0{i + 1}</span>
                    <h3 className="mt-1 text-xl md:text-2xl font-bold">{n.name}</h3>
                    <p className="mt-1 text-xs font-semibold uppercase tracking-wider text-primary">
                      {n.bestFor} · {n.cadence}
                    </p>
                  </div>
                  <a
                    href={n.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={`Visit ${n.name}`}
                    className="shrink-0 inline-flex items-center gap-1.5 rounded-full border border-border bg-card/50 px-3 py-2 text-xs font-semibold hover:bg-card hover:border-primary/40 transition-all"
                  >
                    Visit <ExternalLink className="h-3.5 w-3.5" />
                  </a>
                </div>
                <p className="mt-4 text-sm md:text-[15px] text-foreground/90 leading-relaxed">{n.blurb}</p>
              </section>
            ))}
          </div>

          <h2 className="mt-12 text-2xl md:text-3xl font-black uppercase tracking-tight">How to actually use them</h2>
          <ul className="mt-4 space-y-3 text-sm md:text-base text-foreground/90 leading-relaxed">
            <li>
              <strong>Pick a daily and a weekly.</strong> One short daily (Your Morning Coffee or Hypebot) keeps you current.
              One weekly (Trapital or Water & Music) gives you the angle behind the news.
            </li>
            <li>
              <strong>Save quotes and data points.</strong> The number Trapital cites today is the slide you put in next month's
              client deck. Keep a swipe file.
            </li>
            <li>
              <strong>Don't confuse reading with doing.</strong> Block thirty minutes, twice a week. Inbox-zero on industry
              newsletters is not a marketing strategy.
            </li>
          </ul>

          <div className="glass-card shadow-card-elevated relative overflow-hidden mt-14 p-6 sm:p-10 md:p-12 text-center">
            <div className="absolute inset-0 opacity-50" style={{ background: "var(--gradient-glow)" }} />
            <div className="relative">
              <h2 className="text-2xl md:text-4xl font-black uppercase leading-[1.05] tracking-tight">
                Want help turning strategy into <span className="text-gradient-primary">a release rollout?</span>
              </h2>
              <p className="mt-4 mx-auto max-w-2xl text-sm md:text-base text-muted-foreground leading-relaxed">
                Mikewavs builds direct-to-fan systems, websites, CRM, and release campaigns for artists and labels. Book a free
                consultation and we'll map it out for your project.
              </p>
              <a href={CONSULT_URL} className="mt-6 inline-flex items-center gap-2 rounded-full bg-gradient-primary px-6 py-3.5 text-sm md:text-base font-semibold text-primary-foreground transition-all hover:scale-[1.02] glow-primary">
                <Calendar className="h-4 w-4" /> Book Consultation
              </a>
            </div>
          </div>
        </article>
      </main>

      <footer className="relative z-10 border-t border-border">
        <div className="mx-auto flex max-w-7xl flex-col gap-3 px-4 py-8 sm:px-5 md:px-8 md:py-10 md:flex-row md:items-center md:justify-between">
          <div className="flex items-center gap-2.5">
            <img src={logo.url} alt="Mikewavs" className="h-7 w-auto object-contain" />
            <span className="text-sm font-bold text-muted-foreground">© 2026 | Mikewavs All Rights Reserved</span>
          </div>
          <p className="text-[11px] md:text-sm text-muted-foreground tracking-wide">
            Digital Strategy • Web Design • Direct-To-Fan Systems
          </p>
        </div>
      </footer>
    </div>
  );
}