import { useEffect, useRef } from "react";

/**
 * Animated TV/radio static hero background.
 * - Gold noise grain flickers across the hero at low opacity.
 * - Pointer / touch clears static within a radius with smooth falloff.
 * - Clearing eases back to full static over ~400ms after pointer leaves.
 * - Single rAF loop, refs only, paused when offscreen / tab hidden.
 */
export default function HeroStaticBackground() {
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const wrap = wrapRef.current;
    const canvas = canvasRef.current;
    if (!wrap || !canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const reduced =
      typeof window !== "undefined" &&
      window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;

    // Resolve gold from --primary token, fallback to brand gold.
    let r = 0xd6,
      g = 0xa2,
      b = 0x3a;
    try {
      const v = getComputedStyle(document.documentElement)
        .getPropertyValue("--primary")
        .trim();
      const m = v.match(/^#?([0-9a-fA-F]{6})$/);
      if (m) {
        const hex = parseInt(m[1], 16);
        r = (hex >> 16) & 0xff;
        g = (hex >> 8) & 0xff;
        b = hex & 0xff;
      }
    } catch {
      /* noop */
    }

    const CELL = 3; // px per static cell
    const RADIUS = 140;
    const BASELINE = 0.08; // peak per-cell alpha at rest (0–1)
    const CLEAR_EASE_OUT = 0.18; // how fast clearing follows pointer
    const CLEAR_EASE_IN = 0.06; // how fast static returns (~400ms)

    let width = 0;
    let height = 0;
    let cols = 0;
    let rows = 0;
    let dpr = Math.max(1, Math.min(2, window.devicePixelRatio || 1));
    let imageData: ImageData | null = null;
    let buf: Uint8ClampedArray | null = null;

    const pointer = {
      x: -9999,
      y: -9999,
      tx: -9999,
      ty: -9999,
      strength: 0, // 0 = no clearing, 1 = full clearing
      target: 0,
    };

    const resize = () => {
      const rect = wrap.getBoundingClientRect();
      width = Math.max(1, Math.floor(rect.width));
      height = Math.max(1, Math.floor(rect.height));
      dpr = Math.max(1, Math.min(2, window.devicePixelRatio || 1));
      cols = Math.max(1, Math.ceil(width / CELL));
      rows = Math.max(1, Math.ceil(height / CELL));
      // Render at cell resolution then scale up via CSS for crisp grain + perf.
      canvas.width = cols;
      canvas.height = rows;
      canvas.style.width = width + "px";
      canvas.style.height = height + "px";
      imageData = ctx.createImageData(cols, rows);
      buf = imageData.data;
      // Pre-fill RGB; only alpha changes per frame.
      for (let i = 0; i < cols * rows; i++) {
        const o = i * 4;
        buf[o] = r;
        buf[o + 1] = g;
        buf[o + 2] = b;
        buf[o + 3] = 0;
      }
    };
    resize();

    const ro = new ResizeObserver(resize);
    ro.observe(wrap);

    let visible = true;
    const io = new IntersectionObserver(
      (entries) => {
        visible = entries[0]?.isIntersecting ?? true;
      },
      { threshold: 0 },
    );
    io.observe(wrap);

    const TOUCH_RADIUS_MULT = 1.35; // fingers are larger than cursors
    let radius = RADIUS;

    const setPointer = (clientX: number, clientY: number) => {
      const rect = wrap.getBoundingClientRect();
      pointer.tx = clientX - rect.left;
      pointer.ty = clientY - rect.top;
      pointer.target = 1;
    };

    const onPointerMove = (e: PointerEvent) => {
      if (e.pointerType === "touch") radius = RADIUS * TOUCH_RADIUS_MULT;
      else radius = RADIUS;
      setPointer(e.clientX, e.clientY);
    };
    const onPointerDown = (e: PointerEvent) => {
      if (e.pointerType === "touch") radius = RADIUS * TOUCH_RADIUS_MULT;
      else radius = RADIUS;
      setPointer(e.clientX, e.clientY);
    };
    const onPointerUp = (e: PointerEvent) => {
      // For touch: only clear when the last finger lifts (coalesced by browser).
      // For mouse: always clear.
      if (e.pointerType !== "touch" || !e.isPrimary) {
        pointer.target = 0;
      }
    };
    const onPointerLeave = () => {
      pointer.target = 0;
    };

    wrap.addEventListener("pointermove", onPointerMove, { passive: true });
    wrap.addEventListener("pointerdown", onPointerDown, { passive: true });
    wrap.addEventListener("pointerup", onPointerUp);
    wrap.addEventListener("pointercancel", onPointerLeave);
    wrap.addEventListener("pointerleave", onPointerLeave);

    let raf = 0;
    const draw = () => {
      raf = requestAnimationFrame(draw);
      if (document.hidden || !visible || !buf || !imageData) return;

      // Pointer position tracks the cursor instantly (no lag).
      // Only the clearing strength eases — fast in, slow out.
      if (pointer.target > 0) {
        pointer.x = pointer.tx;
        pointer.y = pointer.ty;
      }
      const easeP = pointer.target > 0 ? CLEAR_EASE_OUT : CLEAR_EASE_IN;
      pointer.strength += (pointer.target - pointer.strength) * easeP;

      const pcx = pointer.x / CELL;
      const pcy = pointer.y / CELL;
      const rCells = radius / CELL;
      const r2 = rCells * rCells;
      const active = pointer.strength > 0.01;

      // Static headline-safe zone: top-center is naturally darker; rely on
      // BASELINE being low. No spatial dampening needed.
      const peak = BASELINE * 255;

      if (reduced) {
        // Static, non-animated grain — write once-ish (still cheap).
        for (let i = 0; i < cols * rows; i++) {
          buf[i * 4 + 3] = peak * 0.5;
        }
      } else {
        for (let y = 0; y < rows; y++) {
          const dy = y - pcy;
          for (let x = 0; x < cols; x++) {
            // Per-cell random alpha (flicker).
            let a = Math.random() * peak;
            if (active) {
              const dx = x - pcx;
              const d2 = dx * dx + dy * dy;
              if (d2 < r2) {
                // Smooth cosine falloff: 1 at center → 0 at radius edge.
                const t = Math.sqrt(d2) / rCells;
                const k = Math.cos(t * (Math.PI / 2));
                const clear = k * k * pointer.strength;
                a *= 1 - clear;
              }
            }
            buf[(y * cols + x) * 4 + 3] = a;
          }
        }
      }

      ctx.putImageData(imageData, 0, 0);
    };
    raf = requestAnimationFrame(draw);

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      io.disconnect();
      wrap.removeEventListener("pointermove", onPointerMove);
      wrap.removeEventListener("pointerdown", onPointerDown);
      wrap.removeEventListener("pointerup", onPointerUp);
      wrap.removeEventListener("pointercancel", onPointerLeave);
      wrap.removeEventListener("pointerleave", onPointerLeave);
    };
  }, []);

  return (
    <div
      ref={wrapRef}
      aria-hidden="true"
      className="absolute inset-0 z-0 overflow-hidden"
      style={{ touchAction: "pan-y" }}
    >
      <canvas
        ref={canvasRef}
        className="block h-full w-full"
        style={{ imageRendering: "pixelated" }}
      />
    </div>
  );
}