import { useEffect, useRef } from "react";

/**
 * Ambient EQ-bar canvas background for the hero section.
 * - Idle: subtle per-bar sine pulse with randomized phase.
 * - Pointer: bars within radius rise with smooth cosine falloff.
 * - Opacity clamped 0.05–0.10 at all times.
 * - Single rAF loop, refs only (no React state in hot path).
 */
export default function HeroEqBackground() {
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const wrap = wrapRef.current;
    const canvas = canvasRef.current;
    if (!wrap || !canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const reduced =
      typeof window !== "undefined" &&
      window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;

    // Read --primary token; fall back to brand gold.
    let color = "#D6A23A";
    try {
      const v = getComputedStyle(document.documentElement)
        .getPropertyValue("--primary")
        .trim();
      if (v) color = v;
    } catch {
      /* noop */
    }

    type Bar = { phase: number; freq: number; current: number };
    let bars: Bar[] = [];
    let width = 0;
    let height = 0;
    let dpr = Math.max(1, Math.min(2, window.devicePixelRatio || 1));

    const pointer = { x: -9999, active: false };
    const RADIUS = 150;

    const buildBars = (count: number) => {
      bars = new Array(count).fill(0).map(() => ({
        phase: Math.random() * Math.PI * 2,
        freq: 0.4 + Math.random() * 0.5,
        current: 0,
      }));
    };

    const resize = () => {
      const rect = wrap.getBoundingClientRect();
      width = Math.max(1, Math.floor(rect.width));
      height = Math.max(1, Math.floor(rect.height));
      dpr = Math.max(1, Math.min(2, window.devicePixelRatio || 1));
      canvas.width = Math.floor(width * dpr);
      canvas.height = Math.floor(height * dpr);
      canvas.style.width = width + "px";
      canvas.style.height = height + "px";
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const count = Math.min(80, Math.max(40, Math.floor(width / 18)));
      if (bars.length !== count) buildBars(count);
    };
    resize();

    const ro = new ResizeObserver(resize);
    ro.observe(wrap);

    let visible = true;
    const io = new IntersectionObserver(
      (entries) => {
        visible = entries[0]?.isIntersecting ?? true;
      },
      { threshold: 0 },
    );
    io.observe(wrap);

    const onVis = () => {
      // restart loop timestamp when returning
      lastT = performance.now();
    };
    document.addEventListener("visibilitychange", onVis);

    const onMove = (e: PointerEvent) => {
      const rect = wrap.getBoundingClientRect();
      pointer.x = e.clientX - rect.left;
      pointer.active = true;
    };
    const onLeave = () => {
      pointer.active = false;
      pointer.x = -9999;
    };
    wrap.addEventListener("pointermove", onMove, { passive: true });
    wrap.addEventListener("pointerleave", onLeave);
    wrap.addEventListener("pointercancel", onLeave);

    const BASE_RATIO = 0.18;
    const IDLE_AMP = 0.06;
    const PEAK_AMP = 0.45;
    const BAR_W = 3;
    const RISE = 0.25;
    const FALL = 0.06;

    let raf = 0;
    let lastT = performance.now();

    const draw = (now: number) => {
      raf = requestAnimationFrame(draw);
      if (document.hidden || !visible) {
        lastT = now;
        return;
      }
      const t = now / 1000;
      ctx.clearRect(0, 0, width, height);
      ctx.globalAlpha = 0.085; // within 0.05–0.10
      ctx.fillStyle = color;

      const n = bars.length;
      if (n === 0) return;
      const slot = width / n;
      const base = height * BASE_RATIO;
      const idleAmp = height * IDLE_AMP;
      const peakAmp = height * PEAK_AMP;

      for (let i = 0; i < n; i++) {
        const b = bars[i];
        const cx = slot * (i + 0.5);
        const idle = reduced
          ? base
          : base + Math.sin(t * b.freq * Math.PI * 2 + b.phase) * idleAmp;

        let target = idle;
        if (!reduced && pointer.active) {
          const d = Math.abs(cx - pointer.x);
          if (d < RADIUS) {
            const k = Math.cos((d / RADIUS) * (Math.PI / 2));
            target = idle + k * k * peakAmp;
          }
        }

        const lerp = target > b.current ? RISE : FALL;
        b.current += (target - b.current) * lerp;

        const h = Math.max(2, b.current);
        ctx.fillRect(Math.round(cx - BAR_W / 2), height - h, BAR_W, h);
      }
    };
    raf = requestAnimationFrame(draw);

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      io.disconnect();
      document.removeEventListener("visibilitychange", onVis);
      wrap.removeEventListener("pointermove", onMove);
      wrap.removeEventListener("pointerleave", onLeave);
      wrap.removeEventListener("pointercancel", onLeave);
    };
  }, []);

  return (
    <div
      ref={wrapRef}
      aria-hidden="true"
      className="absolute inset-0 z-0 overflow-hidden"
      style={{ touchAction: "pan-y" }}
    >
      <canvas ref={canvasRef} className="block h-full w-full" />
    </div>
  );
}