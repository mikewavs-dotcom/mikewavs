import { Fragment } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowLeft, Calendar } from "lucide-react";
import { InstagramLink } from "@/components/InstagramLink";
import logo from "@/assets/mikewavs-logo.png.asset.json";
import { CONSULT_URL } from "@/lib/services-data";
import { formatPostDate, wordCountFor, type BlogPost, type Section } from "@/lib/blog-posts";
import { EmailCaptureCard } from "@/components/blog/EmailCaptureCard";
import { AuthorBio } from "@/components/blog/AuthorBio";
import { RelatedReading } from "@/components/blog/RelatedReading";
import { StickyRolloutCTA } from "@/components/StickyRolloutCTA";
import { SITE_URL, siteUrl } from "@/lib/site";

function renderSection(s: Section, i: number) {
  switch (s.type) {
    case "h2":
      return (
        <h2 key={i} className="mt-10 sm:mt-12 text-[1.4rem] sm:text-2xl md:text-3xl font-display font-black uppercase tracking-tight leading-[1.15] [overflow-wrap:anywhere]">
          {s.text}
        </h2>
      );
    case "h3":
      return (
        <h3 key={i} className="mt-7 sm:mt-8 text-base sm:text-lg md:text-xl font-display font-bold uppercase tracking-tight leading-snug [overflow-wrap:anywhere]">
          {s.text}
        </h3>
      );
    case "p":
      return (
        <p key={i} className="mt-4 text-[14px] sm:text-[15px] md:text-base text-foreground/90 leading-relaxed">
          {s.text}
        </p>
      );
    case "ul":
      return (
        <ul key={i} className="mt-4 space-y-2.5 text-[14px] sm:text-[15px] md:text-base text-foreground/90 leading-relaxed list-disc pl-5 marker:text-primary">
          {s.items.map((it, j) => <li key={j}>{it}</li>)}
        </ul>
      );
    case "ol":
      return (
        <ol key={i} className="mt-4 space-y-2.5 text-[14px] sm:text-[15px] md:text-base text-foreground/90 leading-relaxed list-decimal pl-5 marker:text-primary marker:font-mono">
          {s.items.map((it, j) => <li key={j}>{it}</li>)}
        </ol>
      );
  }
}

export function BlogPostLayout({ post }: { post: BlogPost }) {
  const sections = post.sections;
  // Drop the inline capture card roughly a third of the way through (after a heading).
  let inlineAt = -1;
  if (sections.length >= 6) {
    for (let i = 2; i < Math.min(sections.length, Math.floor(sections.length / 2)); i++) {
      if (sections[i].type === "h2") {
        inlineAt = i;
        break;
      }
    }
  }
  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      <div aria-hidden className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
        <div className="absolute -top-40 left-1/2 h-[600px] w-[1200px] -translate-x-1/2 opacity-60" style={{ background: "var(--gradient-glow)" }} />
      </div>

      <header className="sticky top-0 z-50 border-b border-border/40 backdrop-blur-xl bg-background/70">
        <div className="mx-auto grid grid-cols-[auto_1fr_auto] items-center gap-3 max-w-7xl px-4 py-3 md:px-8 md:py-4">
          <Link to="/" className="flex items-center gap-2">
            <img src={logo.url} alt="Mikewavs" className="h-7 w-auto md:h-8 object-contain" />
          </Link>
          <nav className="hidden md:flex justify-center items-center gap-6 text-xs font-mono uppercase tracking-widest text-muted-foreground">
            <Link to="/" className="hover:text-foreground transition-colors">Home</Link>
            <Link to="/blog" className="hover:text-foreground transition-colors">Artist Resources</Link>
          </nav>
          <div className="flex items-center gap-2 md:gap-3">
            <InstagramLink />
            <a href={CONSULT_URL} className="inline-flex items-center gap-2 rounded-full bg-gradient-primary px-4 py-2 md:px-5 md:py-2.5 text-xs md:text-sm font-semibold text-primary-foreground glow-primary">
              <Calendar className="h-4 w-4" /> Book
            </a>
          </div>
        </div>
      </header>

      <main className="relative z-10">
        <article className="mx-auto max-w-3xl px-4 pt-8 pb-14 sm:px-6 sm:pt-12 md:px-8 md:pt-16 md:pb-24">
          <Link to="/blog" className="inline-flex items-center gap-1.5 text-[11px] sm:text-xs font-mono uppercase tracking-widest text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft className="h-3.5 w-3.5" /> Back to resources
          </Link>

          <p className="mt-6 text-[10px] sm:text-xs font-mono uppercase tracking-widest text-primary">{post.eyebrow}</p>
          <h1 className="mt-3 text-[1.75rem] sm:text-4xl md:text-5xl font-display font-black uppercase leading-[1.08] tracking-tight [overflow-wrap:anywhere] hyphens-auto">
            {post.h1}
          </h1>
          <p className="mt-4 text-[10px] sm:text-[11px] font-mono uppercase tracking-widest text-muted-foreground">
            {formatPostDate(post.published)} · {post.readingTime}
          </p>
          {post.intro && (
            <p className="mt-6 text-[15px] sm:text-base md:text-lg text-muted-foreground leading-relaxed">{post.intro}</p>
          )}

          {sections.map((s, i) => (
            <Fragment key={i}>
              {renderSection(s, i)}
              {i === inlineAt && (
                <EmailCaptureCard
                  variant="inline"
                  source={`blog-${post.slug}-inline`}
                />
              )}
            </Fragment>
          ))}

          <AuthorBio />

          {post.relatedLinks && post.relatedLinks.length > 0 && (
            <RelatedReading links={post.relatedLinks} />
          )}

          <EmailCaptureCard variant="primary" source={`blog-${post.slug}-primary`} />

          <div className="glass-card shadow-card-elevated relative overflow-hidden mt-12 sm:mt-14 p-6 sm:p-10 md:p-12 text-center">
            <div className="absolute inset-0 opacity-50" style={{ background: "var(--gradient-glow)" }} />
            <div className="relative">
              <p className="text-[10px] sm:text-xs font-mono uppercase tracking-widest text-primary">[ Work with Mikewavs ]</p>
              <h2 className="mt-3 text-[1.5rem] sm:text-3xl md:text-4xl font-display font-black uppercase leading-[1.05] tracking-tight [overflow-wrap:anywhere]">
                Turn the strategy into <span className="text-gradient-primary">a real rollout.</span>
              </h2>
              <p className="mt-4 mx-auto max-w-2xl text-[13px] sm:text-sm md:text-base text-muted-foreground leading-relaxed">
                Mikewavs builds direct-to-fan systems, websites, CRM, and release campaigns for artists and labels. Book a free
                consultation and we'll map it out for your project.
              </p>
              <a href={CONSULT_URL} className="mt-6 inline-flex items-center gap-2 rounded-full bg-gradient-primary px-6 py-3.5 text-sm md:text-base font-semibold text-primary-foreground transition-all hover:scale-[1.02] glow-primary">
                <Calendar className="h-4 w-4" /> Book Consultation
              </a>
            </div>
          </div>
        </article>
      </main>

      <footer className="relative z-10 border-t border-border">
        <div className="mx-auto flex max-w-7xl flex-col gap-3 px-4 py-8 sm:px-5 md:px-8 md:py-10 md:flex-row md:items-center md:justify-between">
          <div className="flex items-center gap-2.5">
            <img src={logo.url} alt="Mikewavs" className="h-7 w-auto object-contain" />
            <span className="text-sm font-bold text-muted-foreground">© 2026 | Mikewavs All Rights Reserved</span>
          </div>
          <p className="text-[11px] md:text-sm font-mono uppercase tracking-widest text-muted-foreground">
            Digital Strategy · Web Design · Direct-To-Fan Systems
          </p>
        </div>
      </footer>
      <StickyRolloutCTA />
    </div>
  );
}

export function blogPostHead(post: BlogPost) {
  const url = siteUrl(`/blog/${post.slug}`);
  const wordCount = wordCountFor(post);
  const keywords = [post.category, ...(post.tags ?? [])].join(", ");
  return {
    meta: [
      { title: post.metaTitle },
      { name: "description", content: post.description },
      { name: "keywords", content: keywords },
      { name: "author", content: "Mike Wavs" },
      { name: "article:author", content: "Mike Wavs" },
      { property: "article:published_time", content: post.published },
      { property: "article:section", content: post.category },
      { property: "og:title", content: post.metaTitle },
      { property: "og:description", content: post.description },
      { property: "og:url", content: url },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: post.metaTitle },
      { name: "twitter:description", content: post.description },
    ],
    links: [{ rel: "canonical", href: url }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "BlogPosting",
          headline: post.metaTitle,
          description: post.description,
          datePublished: post.published,
          dateModified: post.published,
          articleSection: post.category,
          keywords,
          wordCount,
          inLanguage: "en-US",
          url,
          mainEntityOfPage: { "@type": "WebPage", "@id": url },
          author: {
            "@type": "Person",
            name: "Mike Wavs",
            url: SITE_URL,
            jobTitle: "Music Digital Strategist",
            sameAs: ["https://instagram.com/mikewavs"],
          },
          publisher: { "@type": "Organization", name: "Mikewavs", url: SITE_URL },
        }),
      },
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "BreadcrumbList",
          itemListElement: [
            { "@type": "ListItem", position: 1, name: "Home", item: siteUrl("/") },
            { "@type": "ListItem", position: 2, name: "Artist Resources", item: siteUrl("/blog") },
            { "@type": "ListItem", position: 3, name: post.title, item: url },
          ],
        }),
      },
    ],
  };
}