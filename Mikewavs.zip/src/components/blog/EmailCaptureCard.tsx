import { useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { ArrowRight, CheckCircle2, Download } from "lucide-react";
import { subscribeToList } from "@/lib/subscribers.functions";

type Variant = "inline" | "primary";

interface Props {
  variant?: Variant;
  source?: string;
  eyebrow?: string;
  heading?: string;
  blurb?: string;
}

const COPY = {
  inline: {
    eyebrow: "[ FREE PDF ]",
    heading: "Get the release checklist PDF",
    blurb: "The 8-week artist release checklist Mikewavs runs with clients.",
  },
  primary: {
    eyebrow: "[ Free download ]",
    heading: "The Music Release Checklist (PDF)",
    blurb:
      "The same 8-week checklist we run with artist and label clients. Drop your email — we'll send it to your inbox.",
  },
};

export function EmailCaptureCard({
  variant = "primary",
  source,
  eyebrow,
  heading,
  blurb,
}: Props) {
  const copy = COPY[variant];
  const subscribe = useServerFn(subscribeToList);
  const loadedAtRef = useRef<number>(0);
  const [email, setEmail] = useState("");
  const [hp, setHp] = useState("");
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">(
    "idle",
  );
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadedAtRef.current = Date.now();
  }, []);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (status === "loading") return;
    setStatus("loading");
    setError(null);
    try {
      await subscribe({
        data: {
          email,
          source: source ?? "blog",
          hp,
          formLoadedAt: loadedAtRef.current,
        },
      });
      setStatus("success");
    } catch (err) {
      setStatus("error");
      setError(
        err instanceof Error
          ? err.message
          : "Something went wrong. Try again or email mike@nocoolpoints.com.",
      );
    }
  }

  const isPrimary = variant === "primary";
  const wrapperClass = isPrimary
    ? "glass-card shadow-card-elevated relative overflow-hidden mt-12 sm:mt-14 p-6 sm:p-9 md:p-10"
    : "glass-card relative overflow-hidden my-8 sm:my-10 p-5 sm:p-6 md:p-7";

  return (
    <aside className={wrapperClass} aria-label="Subscribe to get the PDF lead magnet">
      {isPrimary && (
        <div
          aria-hidden
          className="absolute inset-0 opacity-50"
          style={{ background: "var(--gradient-glow)" }}
        />
      )}
      <div className="relative">
        <div className="flex items-center gap-2">
          <Download className="h-3.5 w-3.5 text-primary" />
          <p className="text-[10px] sm:text-xs font-mono uppercase tracking-widest text-primary">
            {eyebrow ?? copy.eyebrow}
          </p>
        </div>
        <h3
          className={
            isPrimary
              ? "mt-3 text-[1.4rem] sm:text-2xl md:text-3xl font-display font-black uppercase leading-[1.1] tracking-tight [overflow-wrap:anywhere]"
              : "mt-2 text-lg sm:text-xl font-display font-black uppercase leading-[1.15] tracking-tight [overflow-wrap:anywhere]"
          }
        >
          {heading ?? copy.heading}
        </h3>
        <p
          className={
            isPrimary
              ? "mt-3 max-w-2xl text-[13px] sm:text-sm md:text-base text-muted-foreground leading-relaxed"
              : "mt-2 text-[13px] sm:text-sm text-muted-foreground leading-relaxed"
          }
        >
          {blurb ?? copy.blurb}
        </p>

        {status === "success" ? (
          <div className="mt-5 flex items-start gap-3 rounded-2xl border border-primary/30 bg-primary/5 p-4">
            <CheckCircle2 className="h-5 w-5 mt-0.5 shrink-0 text-primary" />
            <div>
              <p className="text-sm font-semibold text-foreground">
                Check your inbox.
              </p>
              <p className="mt-1 text-[13px] text-muted-foreground leading-relaxed">
                The PDF is on its way. If you don't see it in a minute, check spam or
                promotions.
              </p>
            </div>
          </div>
        ) : (
          <form
            onSubmit={onSubmit}
            className="mt-5 flex flex-col sm:flex-row gap-2"
            noValidate
          >
            {/* honeypot */}
            <input
              type="text"
              name="company"
              tabIndex={-1}
              autoComplete="off"
              value={hp}
              onChange={(e) => setHp(e.target.value)}
              className="hidden"
              aria-hidden="true"
            />
            <label htmlFor={`email-${variant}-${source ?? "blog"}`} className="sr-only">
              Email address
            </label>
            <input
              id={`email-${variant}-${source ?? "blog"}`}
              type="email"
              required
              autoComplete="email"
              placeholder="you@artist.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              disabled={status === "loading"}
              className="flex-1 rounded-full border border-border bg-background/60 px-5 py-3 text-sm text-foreground placeholder:text-muted-foreground/70 outline-none focus:border-primary/60 focus:ring-2 focus:ring-primary/20 disabled:opacity-60"
            />
            <button
              type="submit"
              disabled={status === "loading"}
              className="inline-flex items-center justify-center gap-2 rounded-full bg-gradient-primary px-5 py-3 text-sm font-semibold text-primary-foreground transition-all hover:scale-[1.02] disabled:opacity-60 disabled:hover:scale-100 glow-primary"
            >
              {status === "loading" ? "Sending…" : (<>Send me the PDF <ArrowRight className="h-4 w-4" /></>)}
            </button>
          </form>
        )}

        {status === "error" && error && (
          <p className="mt-3 text-xs text-red-400">{error}</p>
        )}

        {status !== "success" && (
          <p className="mt-3 text-[11px] text-muted-foreground/80">
            No spam. Unsubscribe in one click.
          </p>
        )}
      </div>
    </aside>
  );
}