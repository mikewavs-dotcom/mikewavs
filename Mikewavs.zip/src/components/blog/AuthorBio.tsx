import { Link } from "@tanstack/react-router";
import portrait from "@/assets/mikewavs-portrait.jpg.asset.json";

export function AuthorBio() {
  return (
    <section
      className="mt-12 sm:mt-14 flex flex-col sm:flex-row gap-5 sm:gap-6 items-start rounded-2xl border border-border/60 bg-card/30 p-5 sm:p-6"
      aria-label="About the author"
    >
      <img
        src={portrait.url}
        alt="Mike Wavs, music digital strategist"
        className="h-16 w-16 sm:h-20 sm:w-20 rounded-full object-cover border border-border shrink-0"
        loading="lazy"
        width={80}
        height={80}
      />
      <div className="min-w-0">
        <p className="text-[10px] font-mono uppercase tracking-widest text-primary">
          [ Written by ]
        </p>
        <p className="mt-1 text-base font-display font-extrabold uppercase tracking-tight">
          Mike Wavs
        </p>
        <p className="mt-2 text-[13px] sm:text-sm text-muted-foreground leading-relaxed">
          Digital strategist for artists, labels, and music teams. Builds direct-to-fan
          systems, websites, CRM, and release campaigns at{" "}
          <Link to="/" className="text-foreground underline underline-offset-2 decoration-primary/50 hover:decoration-primary">
            Mikewavs
          </Link>
          . Writes about what's actually working in release marketing.
        </p>
        <p className="mt-2 text-[11px] font-mono uppercase tracking-widest">
          <a
            href="https://instagram.com/mikewavs"
            target="_blank"
            rel="noopener noreferrer"
            className="text-muted-foreground hover:text-primary transition-colors"
          >
            @mikewavs ↗
          </a>
        </p>
      </div>
    </section>
  );
}