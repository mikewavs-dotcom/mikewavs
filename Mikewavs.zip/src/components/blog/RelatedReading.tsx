import { Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { postBySlug, type RelatedLink } from "@/lib/blog-posts";
import { services } from "@/lib/services-data";

const RESOURCES: Record<string, { href: string; eyebrow: string; title: string; blurb: string }> = {
  "music-marketing-stack": {
    href: "/resources/music-marketing-stack",
    eyebrow: "Resource",
    title: "The Independent Music Marketing Stack 2026",
    blurb:
      "Opinionated, regularly updated directory of the tools artists, managers, and labels actually use.",
  },
};

function resolve(link: RelatedLink): { href: string; eyebrow: string; title: string; blurb: string } | null {
  if (link.kind === "post") {
    const p = postBySlug(link.slug);
    if (!p) return null;
    return {
      href: `/blog/${p.slug}`,
      eyebrow: `Post · ${p.category}`,
      title: p.metaTitle,
      blurb: p.description,
    };
  }
  if (link.kind === "resource") {
    return RESOURCES[link.slug] ?? null;
  }
  const s = services.find((x) => x.slug === link.slug);
  if (!s) return null;
  return {
    href: `/services/${s.slug}`,
    eyebrow: "Service",
    title: s.t,
    blurb: s.d,
  };
}

export function RelatedReading({ links }: { links: RelatedLink[] }) {
  const resolved = links
    .map(resolve)
    .filter((x): x is NonNullable<ReturnType<typeof resolve>> => x !== null);
  if (resolved.length === 0) return null;

  return (
    <section className="mt-12 sm:mt-14" aria-label="Related reading">
      <p className="text-[10px] sm:text-xs font-mono uppercase tracking-widest text-primary">
        [ Related reading ]
      </p>
      <h2 className="mt-2 text-xl sm:text-2xl font-display font-black uppercase tracking-tight">
        Keep going
      </h2>
      <ul className="mt-5 grid gap-3 sm:grid-cols-2">
        {resolved.map((r) => (
          <li key={r.href}>
            <a
              href={r.href}
              className="group flex h-full flex-col rounded-2xl border border-border/60 bg-card/30 p-5 transition-all hover:border-primary/40 hover:-translate-y-0.5"
            >
              <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">
                {r.eyebrow}
              </p>
              <p className="mt-2 text-sm sm:text-base font-display font-bold uppercase leading-tight tracking-tight group-hover:text-primary transition-colors [overflow-wrap:anywhere]">
                {r.title}
              </p>
              <p className="mt-2 text-[12.5px] text-muted-foreground leading-relaxed line-clamp-2">
                {r.blurb}
              </p>
              <span className="mt-3 inline-flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-widest text-primary">
                Read <ArrowRight className="h-3 w-3" />
              </span>
            </a>
          </li>
        ))}
      </ul>
    </section>
  );
}