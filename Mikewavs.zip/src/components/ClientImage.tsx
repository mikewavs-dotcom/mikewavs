import { useState } from "react";

interface ClientImageProps {
  src: string;
  alt: string;
  className?: string;
}

export function ClientImage({ src, alt, className = "" }: ClientImageProps) {
  const [loaded, setLoaded] = useState(false);
  const [error, setError] = useState(false);

  return (
    <div className={`relative overflow-hidden ${className}`}>
      {/* Skeleton / blur placeholder — always reserve space */}
      <div
        className={`absolute inset-0 bg-secondary transition-opacity duration-500 ${
          loaded ? "opacity-0" : "opacity-100"
        }`}
        aria-hidden="true"
      >
        <div className="absolute inset-0 bg-gradient-to-br from-secondary via-muted/40 to-secondary animate-pulse" />
      </div>

      {/* Error fallback */}
      {error && (
        <div className="absolute inset-0 flex items-center justify-center bg-secondary">
          <span className="text-[10px] font-mono uppercase tracking-[0.2em] text-muted-foreground">
            Image unavailable
          </span>
        </div>
      )}

      <img
        src={src}
        alt={alt}
        loading="lazy"
        onLoad={() => setLoaded(true)}
        onError={() => setError(true)}
        className={`block h-full w-full object-cover grayscale group-hover:grayscale-0 transition-all duration-500 ${
          loaded ? "opacity-100" : "opacity-0"
        }`}
      />
    </div>
  );
}
