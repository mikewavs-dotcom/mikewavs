import { Link } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, Calendar, Check, Loader2, Mail } from "lucide-react";
import { useMemo, useRef, useState } from "react";
import { InstagramLink } from "@/components/InstagramLink";
import logo from "@/assets/mikewavs-logo.png.asset.json";
import { services, getService, CONSULT_URL } from "@/lib/services-data";
import { submitInquiry } from "@/lib/contact.functions";
import {
  BUDGETS,
  TIMELINES,
  getPromptsForService,
  type FormState,
} from "@/lib/contact-form";

export function ContactPageInner({ preselected }: { preselected: string }) {
  const [form, setForm] = useState<FormState>({
    serviceSlug: preselected,
    name: "",
    email: "",
    company: "",
    role: "",
    phone: "",
    website: "",
    socials: "",
    budget: "",
    timeline: "",
    goals: "",
    currentSituation: "",
    additionalInfo: "",
  });
  const [status, setStatus] = useState<"idle" | "submitting" | "success" | "error">(
    "idle",
  );
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [hp, setHp] = useState("");
  const formLoadedAtRef = useRef<number>(Date.now());

  const selectedService = useMemo(
    () => (form.serviceSlug ? getService(form.serviceSlug) : null),
    [form.serviceSlug],
  );
  const prompts = useMemo(
    () => getPromptsForService(form.serviceSlug),
    [form.serviceSlug],
  );

  function update<K extends keyof FormState>(k: K, v: FormState[K]) {
    setForm((f) => ({ ...f, [k]: v }));
  }

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setErrorMsg(null);

    if (form.name.trim().length < 1) {
      setErrorMsg("Please enter your name.");
      return;
    }
    if (!/^\S+@\S+\.\S+$/.test(form.email.trim())) {
      setErrorMsg("Please enter a valid email address.");
      return;
    }
    if (form.goals.trim().length < 10) {
      setErrorMsg("Please share a bit more about your goals (at least 10 characters).");
      return;
    }

    setStatus("submitting");
    try {
      await submitInquiry({
        data: {
          serviceSlug: form.serviceSlug || null,
          serviceName: selectedService?.t ?? null,
          name: form.name.trim(),
          email: form.email.trim(),
          company: form.company.trim() || null,
          role: form.role.trim() || null,
          phone: form.phone.trim() || null,
          website: form.website.trim() || null,
          socials: form.socials.trim() || null,
          budget: form.budget || null,
          timeline: form.timeline || null,
          goals: form.goals.trim(),
          currentSituation: form.currentSituation.trim() || null,
          additionalInfo: form.additionalInfo.trim() || null,
          hp,
          formLoadedAt: formLoadedAtRef.current,
        },
      });
      setStatus("success");
    } catch (err) {
      setStatus("error");
      setErrorMsg(
        err instanceof Error
          ? err.message
          : "Something went wrong. Please try again or email mike@nocoolpoints.com.",
      );
    }
  }

  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      <div aria-hidden className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
        <div
          className="absolute -top-40 left-1/2 h-[600px] w-[1200px] -translate-x-1/2 opacity-60"
          style={{ background: "var(--gradient-glow)" }}
        />
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage:
              "radial-gradient(circle at 1px 1px, white 1px, transparent 0)",
            backgroundSize: "32px 32px",
          }}
        />
      </div>

      <header className="sticky top-0 z-50 border-b border-border/40 backdrop-blur-xl bg-background/70">
        <div className="mx-auto grid grid-cols-[auto_1fr_auto] items-center gap-3 max-w-7xl px-4 py-3 md:px-8 md:py-4">
          <Link to="/" className="flex items-center gap-2">
            <img src={logo.url} alt="Mikewavs" className="h-7 w-auto md:h-8 object-contain" />
          </Link>
          <nav className="hidden md:flex justify-center items-center gap-6 text-xs font-mono uppercase tracking-widest text-muted-foreground">
            <Link to="/" className="hover:text-foreground transition-colors">Home</Link>
            <Link to="/blog" className="hover:text-foreground transition-colors">Artist Resources</Link>
            <Link to="/contact" className="text-foreground transition-colors">Contact</Link>
          </nav>
          <div className="flex items-center gap-2 md:gap-3">
            <InstagramLink />
            <a
              href={CONSULT_URL}
              className="inline-flex items-center gap-2 rounded-full bg-gradient-primary px-4 py-2 md:px-5 md:py-2.5 text-xs md:text-sm font-semibold text-primary-foreground glow-primary"
            >
              <Calendar className="h-4 w-4" /> Book
            </a>
          </div>
        </div>
      </header>

      <main className="relative z-10">
        <section className="mx-auto max-w-3xl px-4 pt-10 pb-6 sm:px-6 md:px-8 md:pt-16">
          <Link
            to="/"
            hash="services"
            className="inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-widest text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="h-3.5 w-3.5" /> Back
          </Link>
          <div className="mt-6 inline-flex items-center gap-2 rounded-full border border-border bg-card/50 px-3 py-1 text-[11px] md:text-xs font-medium text-muted-foreground">
            <Mail className="h-3.5 w-3.5 text-primary" />
            <span>Replies come from mike@nocoolpoints.com</span>
          </div>
          <h1 className="mt-4 font-display text-3xl sm:text-4xl md:text-5xl font-extrabold uppercase leading-[1.02] tracking-tight">
            Start your <span className="text-gradient-primary">inquiry.</span>
          </h1>
          <p className="mt-4 text-sm sm:text-base text-muted-foreground leading-relaxed">
            Tell me about the project and what you need. The more detail, the better the
            first response. Expect a reply within 1–2 business days.
          </p>
        </section>

        {status === "success" ? (
          <section className="mx-auto max-w-3xl px-4 sm:px-6 md:px-8 pb-24">
            <div className="glass-card shadow-card-elevated p-8 md:p-12 text-center">
              <div className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-gradient-primary text-primary-foreground glow-primary">
                <Check className="h-7 w-7" />
              </div>
              <h2 className="mt-5 font-display text-2xl md:text-3xl font-extrabold uppercase">
                Inquiry received.
              </h2>
              <p className="mt-3 text-sm md:text-base text-muted-foreground leading-relaxed">
                Thanks {form.name.split(" ")[0] || "—"}. Mike has your details and will reply
                from <span className="text-foreground font-semibold">mike@nocoolpoints.com</span>{" "}
                within 1–2 business days.
              </p>
              <div className="mt-6 flex flex-wrap justify-center gap-3">
                <a
                  href={CONSULT_URL}
                  className="inline-flex items-center gap-2 rounded-full bg-gradient-primary px-5 py-3 text-sm font-semibold text-primary-foreground glow-primary"
                >
                  <Calendar className="h-4 w-4" /> Book a consultation now
                </a>
                <Link
                  to="/"
                  className="inline-flex items-center gap-2 rounded-full border border-border bg-card/50 px-5 py-3 text-sm font-semibold hover:bg-card"
                >
                  Back to home
                </Link>
              </div>
            </div>
          </section>
        ) : (
          <section className="mx-auto max-w-3xl px-4 sm:px-6 md:px-8 pb-24">
            <form
              onSubmit={onSubmit}
              className="glass-card shadow-card-elevated p-5 sm:p-7 md:p-10 space-y-7"
            >
              {/* Honeypot — hidden from real users, bots fill it and get silently dropped server-side. */}
              <div
                aria-hidden="true"
                style={{
                  position: "absolute",
                  left: "-10000px",
                  width: "1px",
                  height: "1px",
                  overflow: "hidden",
                }}
              >
                <label>
                  Leave this field empty
                  <input
                    type="text"
                    name="company_website"
                    tabIndex={-1}
                    autoComplete="off"
                    value={hp}
                    onChange={(e) => setHp(e.target.value)}
                  />
                </label>
              </div>

              <Field label="What service is this about?" required>
                <select
                  required
                  value={form.serviceSlug}
                  onChange={(e) => update("serviceSlug", e.target.value)}
                  className={inputCls}
                >
                  <option value="">Select a service…</option>
                  {services.map((s) => (
                    <option key={s.slug} value={s.slug}>
                      {s.t}
                    </option>
                  ))}
                  <option value="">General / Not sure yet</option>
                </select>
                {selectedService ? (
                  <p className="mt-2 text-xs text-muted-foreground leading-relaxed">
                    {selectedService.d}
                  </p>
                ) : null}
              </Field>

              <div className="grid gap-5 sm:grid-cols-2">
                <Field label="Your name" required>
                  <input
                    required
                    type="text"
                    autoComplete="name"
                    maxLength={120}
                    value={form.name}
                    onChange={(e) => update("name", e.target.value)}
                    className={inputCls}
                    placeholder="Jane Smith"
                  />
                </Field>
                <Field label="Email" required>
                  <input
                    required
                    type="email"
                    autoComplete="email"
                    maxLength={200}
                    value={form.email}
                    onChange={(e) => update("email", e.target.value)}
                    className={inputCls}
                    placeholder="you@email.com"
                  />
                </Field>
              </div>

              <div className="grid gap-5 sm:grid-cols-2">
                <Field label="Artist / Label / Company">
                  <input
                    type="text"
                    maxLength={200}
                    value={form.company}
                    onChange={(e) => update("company", e.target.value)}
                    className={inputCls}
                    placeholder="Project or brand name"
                  />
                </Field>
                <Field label="Your role">
                  <input
                    type="text"
                    maxLength={120}
                    value={form.role}
                    onChange={(e) => update("role", e.target.value)}
                    className={inputCls}
                    placeholder="Artist, manager, label, A&R…"
                  />
                </Field>
              </div>

              <div className="grid gap-5 sm:grid-cols-2">
                <Field label="Phone (optional)">
                  <input
                    type="tel"
                    autoComplete="tel"
                    maxLength={60}
                    value={form.phone}
                    onChange={(e) => update("phone", e.target.value)}
                    className={inputCls}
                    placeholder="+1…"
                  />
                </Field>
                <Field label="Website (optional)">
                  <input
                    type="url"
                    maxLength={300}
                    value={form.website}
                    onChange={(e) => update("website", e.target.value)}
                    className={inputCls}
                    placeholder="https://"
                  />
                </Field>
              </div>

              <Field label="Socials / streaming links (optional)">
                <input
                  type="text"
                  maxLength={500}
                  value={form.socials}
                  onChange={(e) => update("socials", e.target.value)}
                  className={inputCls}
                  placeholder="IG, TikTok, Spotify, YouTube…"
                />
              </Field>

              <div className="grid gap-5 sm:grid-cols-2">
                <Field label="Budget range">
                  <select
                    value={form.budget}
                    onChange={(e) => update("budget", e.target.value)}
                    className={inputCls}
                  >
                    <option value="">Select a range…</option>
                    {BUDGETS.map((b) => (
                      <option key={b} value={b}>
                        {b}
                      </option>
                    ))}
                  </select>
                </Field>
                <Field label="Timeline">
                  <select
                    value={form.timeline}
                    onChange={(e) => update("timeline", e.target.value)}
                    className={inputCls}
                  >
                    <option value="">Select a timeline…</option>
                    {TIMELINES.map((t) => (
                      <option key={t} value={t}>
                        {t}
                      </option>
                    ))}
                  </select>
                </Field>
              </div>

              <Field label={prompts.goalsLabel} required>
                <textarea
                  required
                  rows={5}
                  maxLength={4000}
                  value={form.goals}
                  onChange={(e) => update("goals", e.target.value)}
                  className={inputCls}
                  placeholder={prompts.goalsPlaceholder}
                />
              </Field>

              <Field label={prompts.currentLabel}>
                <textarea
                  rows={4}
                  maxLength={4000}
                  value={form.currentSituation}
                  onChange={(e) => update("currentSituation", e.target.value)}
                  className={inputCls}
                  placeholder={prompts.currentPlaceholder}
                />
              </Field>

              <Field label="Anything else worth knowing? (optional)">
                <textarea
                  rows={3}
                  maxLength={4000}
                  value={form.additionalInfo}
                  onChange={(e) => update("additionalInfo", e.target.value)}
                  className={inputCls}
                  placeholder="Links, references, vibes, hard constraints…"
                />
              </Field>

              {errorMsg ? (
                <div className="rounded-lg border border-destructive/50 bg-destructive/10 px-4 py-3 text-sm text-destructive">
                  {errorMsg}
                </div>
              ) : null}

              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pt-2">
                <p className="text-[11px] text-muted-foreground leading-relaxed">
                  By submitting, you agree to be contacted at the email you provided.
                </p>
                <button
                  type="submit"
                  disabled={status === "submitting"}
                  className="inline-flex items-center justify-center gap-2 rounded-full bg-gradient-primary px-6 py-3.5 text-sm font-semibold text-primary-foreground transition-all hover:scale-[1.02] disabled:opacity-60 disabled:cursor-not-allowed glow-primary"
                >
                  {status === "submitting" ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" /> Sending…
                    </>
                  ) : (
                    <>
                      Send Inquiry <ArrowRight className="h-4 w-4" />
                    </>
                  )}
                </button>
              </div>
            </form>
          </section>
        )}
      </main>

      <footer className="relative z-10 border-t border-border">
        <div className="mx-auto flex max-w-7xl flex-col gap-3 px-4 py-8 sm:px-5 md:px-8 md:py-10 md:flex-row md:items-center md:justify-between">
          <div className="flex items-center gap-2.5">
            <img src={logo.url} alt="Mikewavs" className="h-7 w-auto object-contain" />
            <span className="font-mono text-[10px] md:text-[11px] uppercase tracking-[0.25em] text-muted-foreground">
              © 2026 / Mikewavs / All Rights Reserved
            </span>
          </div>
          <p className="font-mono text-[10px] md:text-[11px] uppercase tracking-[0.3em] text-muted-foreground">
            mike@nocoolpoints.com
          </p>
        </div>
      </footer>
    </div>
  );
}

const inputCls =
  "w-full rounded-lg border border-border bg-background/60 px-3.5 py-2.5 text-sm text-foreground placeholder:text-muted-foreground/70 outline-none transition-colors focus:border-primary/60 focus:bg-background";

function Field({
  label,
  required,
  children,
}: {
  label: string;
  required?: boolean;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block font-mono text-[10px] uppercase tracking-[0.25em] text-muted-foreground">
        {label}
        {required ? <span className="ml-1 text-primary">*</span> : null}
      </span>
      {children}
    </label>
  );
}