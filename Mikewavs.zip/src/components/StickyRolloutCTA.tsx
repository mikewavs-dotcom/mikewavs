import { Link } from "@tanstack/react-router";
import { ArrowRight, Sparkles } from "lucide-react";

/**
 * Mobile-only sticky bottom CTA that routes to the rollout tool.
 * Hidden on md+ to avoid covering desktop layout.
 */
export function StickyRolloutCTA() {
  return (
    <div className="md:hidden fixed inset-x-0 bottom-0 z-40 px-3 pb-3 pt-2 pointer-events-none">
      <div
        aria-hidden
        className="absolute inset-0 bg-gradient-to-t from-background via-background/90 to-transparent"
      />
      <Link
        to="/tools/music-rollout-builder"
        className="pointer-events-auto relative flex items-center justify-center gap-2 rounded-full bg-gradient-primary px-5 py-3.5 text-sm font-semibold text-primary-foreground shadow-[0_8px_32px_-8px_rgba(129,65,247,0.6)] glow-primary"
      >
        <Sparkles className="h-4 w-4" />
        Free Rollout Score
        <ArrowRight className="h-4 w-4" />
      </Link>
    </div>
  );
}