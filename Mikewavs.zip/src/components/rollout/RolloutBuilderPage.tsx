import { Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useState, useRef, useEffect } from "react";
import { ArrowRight, Calendar, Check, X, Sparkles, AlertCircle } from "lucide-react";
import { submitRolloutLead, type SubmitRolloutInput } from "@/lib/rollout.functions";
import { ITEMS, type RolloutAnswers, type ScoreResult } from "@/lib/rollout-scoring";

const ROLES = ["Artist", "Independent Label", "Record Label", "Artist Manager", "Producer Manager", "Distribution Company", "Other"];
const RELEASE_TYPES = ["Single", "EP", "Album", "Merch Drop", "Campaign", "Other"];
const GOALS = ["More Streams", "Email/SMS Fan Capture", "Merch Sales", "Bookings", "Brand Awareness", "Fanbase Growth"];

const initialAnswers: RolloutAnswers = {
  has_website: false,
  has_email_capture: false,
  has_sms_capture: false,
  has_crm: false,
  has_merch: false,
  has_content_plan: false,
  has_smart_link: false,
  has_tracking: false,
  has_post_release_plan: false,
};

export function RolloutBuilderPage() {
  const submit = useServerFn(submitRolloutLead);
  const formRef = useRef<HTMLDivElement>(null);
  const resultRef = useRef<HTMLDivElement>(null);

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [artistCompany, setArtistCompany] = useState("");
  const [role, setRole] = useState("");
  const [releaseType, setReleaseType] = useState("");
  const [releaseDate, setReleaseDate] = useState("");
  const [mainGoal, setMainGoal] = useState("");
  const [answers, setAnswers] = useState<RolloutAnswers>(initialAnswers);
  // Honeypot value — visible to bots auto-filling forms, hidden from humans.
  const [hp, setHp] = useState("");
  // Epoch ms when the form first mounted; server rejects sub-3s submits.
  const formLoadedAtRef = useRef<number>(Date.now());

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [result, setResult] = useState<ScoreResult | null>(null);

  useEffect(() => {
    if (result && resultRef.current) {
      resultRef.current.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }, [result]);

  function scrollToForm() {
    formRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    const errs: Record<string, string> = {};
    if (!name.trim()) errs.name = "Name is required.";
    if (!email.trim()) errs.email = "Email is required.";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) errs.email = "Enter a valid email.";
    if (!artistCompany.trim()) errs.artistCompany = "Artist or company name is required.";
    if (!role) errs.role = "Select your role.";
    if (!releaseType) errs.releaseType = "Select a release type.";
    if (!mainGoal) errs.mainGoal = "Select your main goal.";

    if (Object.keys(errs).length > 0) {
      setFieldErrors(errs);
      setError("Please complete the required fields above.");
      return;
    }
    setFieldErrors({});

    setSubmitting(true);
    try {
      const payload: SubmitRolloutInput = {
        name: name.trim(),
        email: email.trim(),
        artist_company_name: artistCompany.trim(),
        role: role,
        release_type: releaseType,
        release_date: releaseDate || null,
        main_goal: mainGoal,
        ...answers,
        hp,
        formLoadedAt: formLoadedAtRef.current,
      };
      const r = await submit({ data: payload });
      setResult(r);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Something went wrong. Please try again.";
      setError(msg);
    } finally {
      setSubmitting(false);
    }
  }

  function reset() {
    setResult(null);
    setTimeout(scrollToForm, 50);
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />

      <main>
        <Hero onStart={scrollToForm} />
        <WhoFor />

        <section ref={formRef} id="rollout-form" className="relative z-10 mx-auto max-w-4xl px-4 py-16 sm:px-5 sm:py-20 md:px-8 md:py-24 border-t border-border">
          {!result ? (
            <>
              <SectionLabel number="02 //">Rollout Check</SectionLabel>
              <h2 className="mt-4 font-display text-[1.25rem] xs:text-[1.5rem] sm:text-4xl md:text-5xl font-extrabold uppercase leading-[1.05] tracking-tight [text-wrap:balance]">
                Tell us about <span className="text-gradient-primary">your release.</span>
              </h2>
              <p className="mt-4 text-sm sm:text-base text-muted-foreground leading-relaxed max-w-2xl">
                Takes about 2 minutes. You'll get an honest readiness score and a breakdown of what your rollout is missing.
              </p>

              <form onSubmit={onSubmit} className="mt-10 space-y-10">
                {/* Honeypot — hidden from real users, attractive to bots. */}
                <div aria-hidden="true" className="absolute left-[-9999px] top-[-9999px] h-0 w-0 overflow-hidden">
                  <label>
                    Leave this field blank
                    <input
                      type="text"
                      tabIndex={-1}
                      autoComplete="off"
                      value={hp}
                      onChange={(e) => setHp(e.target.value)}
                    />
                  </label>
                </div>
                <FormBlock title="About you">
                  <div className="grid gap-5 sm:grid-cols-2">
                    <Field label="Your name" required error={fieldErrors.name}>
                      <input value={name} onChange={(e) => setName(e.target.value)} maxLength={120} className={inputCls} />
                    </Field>
                    <Field label="Email" required error={fieldErrors.email}>
                      <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} maxLength={255} className={inputCls} />
                    </Field>
                    <Field label="Artist or company name" required error={fieldErrors.artistCompany}>
                      <input value={artistCompany} onChange={(e) => setArtistCompany(e.target.value)} maxLength={160} className={inputCls} />
                    </Field>
                    <Field label="Your role" required error={fieldErrors.role}>
                      <select value={role} onChange={(e) => setRole(e.target.value)} className={inputCls}>
                        <option value="">Select…</option>
                        {ROLES.map((r) => <option key={r} value={r}>{r}</option>)}
                      </select>
                    </Field>
                    <Field label="Release type" required error={fieldErrors.releaseType}>
                      <select value={releaseType} onChange={(e) => setReleaseType(e.target.value)} className={inputCls}>
                        <option value="">Select…</option>
                        {RELEASE_TYPES.map((r) => <option key={r} value={r}>{r}</option>)}
                      </select>
                    </Field>
                    <Field label="Release date (optional)">
                      <input type="date" value={releaseDate} onChange={(e) => setReleaseDate(e.target.value)} className={inputCls} />
                    </Field>
                    <Field label="Main goal" required className="sm:col-span-2" error={fieldErrors.mainGoal}>
                      <select value={mainGoal} onChange={(e) => setMainGoal(e.target.value)} className={inputCls}>
                        <option value="">Select…</option>
                        {GOALS.map((g) => <option key={g} value={g}>{g}</option>)}
                      </select>
                    </Field>
                  </div>
                </FormBlock>

                <FormBlock title="Rollout checklist" subtitle="Answer honestly. This is for you, not us.">
                  <div className="space-y-3">
                    {ITEMS.map((item) => (
                      <YesNo
                        key={item.key}
                        label={questionFor(item.key)}
                        value={answers[item.key]}
                        onChange={(v) => setAnswers((a) => ({ ...a, [item.key]: v }))}
                      />
                    ))}
                  </div>
                </FormBlock>

                {error ? (
                  <div className="flex items-start gap-3 rounded-2xl border border-secondary/40 bg-secondary/10 p-4 text-sm text-foreground">
                    <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-secondary" />
                    <div>{error}</div>
                  </div>
                ) : null}

                <div className="flex flex-col sm:flex-row sm:items-center gap-3 pt-2">
                  <button
                    type="submit"
                    disabled={submitting}
                    className="inline-flex items-center justify-center gap-2 rounded-full bg-gradient-primary px-6 py-3.5 text-sm font-semibold text-primary-foreground transition-all hover:-translate-y-0.5 hover:scale-[1.02] hover:shadow-[0_0_32px_-6px_rgba(129,65,247,0.6)] glow-primary disabled:opacity-60 disabled:cursor-not-allowed"
                  >
                    {submitting ? "Scoring…" : "Get My Rollout Score"} <ArrowRight className="h-4 w-4" />
                  </button>
                  <p className="text-xs text-muted-foreground">We only use your email to send your results and follow up.</p>
                </div>
              </form>
            </>
          ) : (
            <div ref={resultRef}>
              <Results result={result} onReset={reset} />
            </div>
          )}
        </section>

        <FinalCTA />
      </main>

      <Footer />
    </div>
  );
}

/* ---------------------------- Sections ---------------------------- */

function Header() {
  return (
    <header className="relative z-20 border-b border-border">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-5 sm:px-5 md:px-8">
        <Link to="/" className="font-display text-base font-extrabold uppercase tracking-tight">
          Mikewavs
        </Link>
        <nav className="flex items-center gap-4 text-xs sm:text-sm">
          <Link to="/" className="text-muted-foreground hover:text-foreground transition-colors">Home</Link>
          <Link to="/contact" className="rounded-full border border-border bg-card/50 px-4 py-2 font-semibold text-foreground transition-colors hover:bg-card hover:border-primary/40">Contact</Link>
        </nav>
      </div>
    </header>
  );
}

function Hero({ onStart }: { onStart: () => void }) {
  return (
    <section className="relative z-10 mx-auto max-w-7xl px-4 py-16 sm:px-5 sm:py-24 md:px-8 md:py-32">
      <div className="max-w-3xl">
        <div className="inline-flex items-center gap-2 rounded-full border border-border bg-card/50 px-3 py-1 text-[11px] md:text-xs font-medium text-muted-foreground">
          <Sparkles className="h-3 w-3 text-primary" />
          Free Tool // Rollout Readiness
        </div>
        <h1 className="mt-5 font-display text-[1.5rem] xs:text-[1.75rem] sm:text-4xl md:text-5xl lg:text-6xl font-extrabold uppercase leading-[1.05] tracking-tight [text-wrap:balance]">
          Check if your music rollout is <span className="text-gradient-primary">actually ready.</span>
        </h1>
        <p className="mt-5 max-w-2xl text-sm sm:text-base md:text-lg text-muted-foreground leading-relaxed">
          Most artists have attention, but no system to capture fans, follow up, sell merch, or turn a release into long-term growth. Use this free tool to see what your rollout is missing before you drop.
        </p>
        <div className="mt-7">
          <button onClick={onStart} className="inline-flex items-center justify-center gap-2 rounded-full bg-gradient-primary px-6 py-3.5 text-sm font-semibold text-primary-foreground transition-all hover:-translate-y-0.5 hover:scale-[1.02] hover:shadow-[0_0_32px_-6px_rgba(129,65,247,0.6)] glow-primary">
            Start Free Rollout Check <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      </div>
    </section>
  );
}

function WhoFor() {
  const audiences = ["Independent Artists", "Record Labels", "Artist Managers", "Distribution Teams"];
  return (
    <section className="relative z-10 mx-auto max-w-7xl px-4 py-12 sm:px-5 sm:py-16 md:px-8 md:py-20 border-t border-border">
      <div className="grid gap-8 lg:grid-cols-[1fr_1.2fr] lg:gap-12">
        <div>
          <SectionLabel number="01 //">Who it's for</SectionLabel>
          <h2 className="mt-4 font-display text-[1.25rem] xs:text-[1.5rem] sm:text-3xl md:text-4xl font-extrabold uppercase leading-[1.05] tracking-tight [text-wrap:balance]">
            Built for teams that take <span className="text-gradient-primary">releases seriously.</span>
          </h2>
        </div>
        <div>
          <p className="text-sm sm:text-base md:text-lg text-muted-foreground leading-relaxed">
            This tool is for independent artists, labels, managers, distribution companies, and music teams running real release campaigns. If you care about owning your fanbase (not just streaming numbers), this gives you a clear, honest readiness score.
          </p>
          <div className="mt-6 flex flex-wrap gap-2">
            {audiences.map((a) => (
              <span key={a} className="rounded-full border border-border bg-card/50 px-3 py-1 font-mono text-[10px] md:text-[11px] uppercase tracking-[0.2em] text-muted-foreground">{a}</span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function Results({ result, onReset }: { result: ScoreResult; onReset: () => void }) {
  return (
    <div>
      <SectionLabel number="03 //">Your Result</SectionLabel>
      <h2 className="mt-4 font-display text-[1.25rem] xs:text-[1.5rem] sm:text-4xl md:text-5xl font-extrabold uppercase leading-[1.05] tracking-tight [text-wrap:balance]">
        {result.category.headline}
      </h2>

      <div className="mt-8 grid gap-6 md:grid-cols-[auto_1fr] md:items-center">
        <div className="glass-card shadow-card-elevated p-6 md:p-8 text-center md:text-left">
          <div className="font-mono text-[10px] uppercase tracking-[0.3em] text-primary">Rollout Score</div>
          <div className="mt-2 font-display text-5xl md:text-6xl font-extrabold text-gradient-primary leading-none">
            {result.score}<span className="text-2xl md:text-3xl text-muted-foreground">/100</span>
          </div>
          <div className="mt-3 font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Range {result.category.range}</div>
        </div>
        <p className="text-sm sm:text-base text-muted-foreground leading-relaxed">{result.category.message}</p>
      </div>

      <div className="mt-10 grid gap-6 md:grid-cols-2">
        <div className="glass-card shadow-card-elevated p-6">
          <div className="font-mono text-[10px] uppercase tracking-[0.3em] text-primary">What you already have</div>
          {result.have.length === 0 ? (
            <p className="mt-4 text-sm text-muted-foreground">Nothing yet — but that's what this is for. See the missing list and start one piece at a time.</p>
          ) : (
            <ul className="mt-4 space-y-2.5">
              {result.have.map((h) => (
                <li key={h.key} className="flex items-start gap-3 text-sm text-foreground/90">
                  <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                  <span>{h.label}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
        <div className="glass-card shadow-card-elevated p-6">
          <div className="font-mono text-[10px] uppercase tracking-[0.3em] text-secondary">What you're missing</div>
          {result.missing.length === 0 ? (
            <p className="mt-4 text-sm text-muted-foreground">Nothing. Your foundation is in place — focus on execution.</p>
          ) : (
            <ul className="mt-4 space-y-2.5">
              {result.missing.map((m) => (
                <li key={m.key} className="flex items-start gap-3 text-sm text-foreground/90">
                  <X className="mt-0.5 h-4 w-4 shrink-0 text-secondary" />
                  <span>{m.label}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      {result.missing.length > 0 ? (
        <div className="mt-10">
          <div className="font-mono text-[10px] uppercase tracking-[0.3em] text-primary">Recommended next steps</div>
          <ol className="mt-4 space-y-3">
            {result.missing.map((m, i) => (
              <li key={m.key} className="rounded-2xl border border-border bg-card/40 p-4 sm:p-5">
                <div className="flex items-start gap-3">
                  <span className="font-mono text-[11px] text-primary/80 mt-0.5">{String(i + 1).padStart(2, "0")}</span>
                  <div>
                    <div className="font-semibold text-sm">{m.label}</div>
                    <p className="mt-2 text-sm text-foreground/80 leading-relaxed">{m.whyItMatters}</p>
                    <p className="mt-2 text-sm text-muted-foreground leading-relaxed"><span className="font-mono text-[10px] uppercase tracking-[0.2em] text-primary/80">Next step // </span>{m.nextStep}</p>
                  </div>
                </div>
              </li>
            ))}
          </ol>
        </div>
      ) : null}

      {result.recommendedServices.length > 0 ? (
        <div className="mt-10">
          <div className="font-mono text-[10px] uppercase tracking-[0.3em] text-primary">Recommended Mikewavs services</div>
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            {result.recommendedServices.map((s) => (
              <div key={s} className="rounded-2xl border border-border bg-card/40 p-4">
                <div className="font-display text-base font-extrabold uppercase tracking-tight">{s}</div>
              </div>
            ))}
          </div>
        </div>
      ) : null}

      <div className="mt-10 flex flex-col sm:flex-row gap-3">
        <a
          href="https://calendly.com/nocoolpoints/1-1-consultation"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center justify-center gap-2 rounded-full bg-gradient-primary px-6 py-3.5 text-sm font-semibold text-primary-foreground transition-all hover:-translate-y-0.5 hover:scale-[1.02] hover:shadow-[0_0_32px_-6px_rgba(129,65,247,0.6)] glow-primary"
        >
          <Calendar className="h-4 w-4" /> Book a free 15-min strategy call
        </a>
        <button onClick={onReset} className="inline-flex items-center justify-center gap-2 rounded-full border border-border bg-card/50 px-6 py-3.5 text-sm font-semibold text-foreground transition-colors hover:bg-card hover:border-primary/40">
          Retake the check
        </button>
      </div>
    </div>
  );
}

function FinalCTA() {
  return (
    <section className="relative z-10 mx-auto max-w-7xl px-4 py-16 sm:px-5 sm:py-20 md:px-8 md:py-24 border-t border-border">
      <div className="glass-card shadow-card-elevated relative overflow-hidden p-6 sm:p-10 md:p-16 text-center">
        <SectionLabel number="04 //">Next Step</SectionLabel>
        <h2 className="mt-4 mx-auto max-w-3xl font-display text-[1.25rem] xs:text-[1.5rem] sm:text-3xl md:text-5xl font-extrabold uppercase leading-[1.05] tracking-tight [text-wrap:balance]">
          Want help building this <span className="text-gradient-primary">before your next release?</span>
        </h2>
        <p className="mt-5 mx-auto max-w-2xl text-sm sm:text-base md:text-lg text-muted-foreground leading-relaxed">
          Mikewavs helps artists, labels, managers, and music teams build websites, fan capture systems, CRM follow-ups, merch setups, and digital campaigns that turn attention into owned fan data.
        </p>
        <div className="mt-7 flex justify-center">
          <Link
            to="/contact"
            className="inline-flex items-center justify-center gap-2 rounded-full bg-gradient-primary px-6 py-3.5 text-sm font-semibold text-primary-foreground transition-all hover:-translate-y-0.5 hover:scale-[1.02] hover:shadow-[0_0_32px_-6px_rgba(129,65,247,0.6)] glow-primary"
          >
            <Calendar className="h-4 w-4" /> Book a Consultation
          </Link>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="relative z-10 mx-auto max-w-7xl px-4 py-10 sm:px-5 md:px-8 border-t border-border">
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-muted-foreground">
        <div>© {new Date().getFullYear()} Mikewavs. All rights reserved.</div>
        <Link to="/" className="hover:text-foreground transition-colors">← Back to home</Link>
      </div>
    </footer>
  );
}

/* ---------------------------- Building blocks ---------------------------- */

const inputCls =
  "w-full rounded-xl border border-border bg-card/40 px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:border-primary/60 focus:ring-2 focus:ring-primary/20 transition-colors";

function SectionLabel({ children, number }: { children: React.ReactNode; number?: string }) {
  return (
    <div className="inline-flex items-center gap-3 font-mono text-[10px] md:text-[11px] uppercase tracking-[0.35em] text-primary">
      {number ? <span className="text-primary/80">{number}</span> : null}
      <span className="h-px w-8 bg-primary/60" />
      <span className="text-primary">{children}</span>
    </div>
  );
}

function FormBlock({ title, subtitle, children }: { title: string; subtitle?: string; children: React.ReactNode }) {
  return (
    <div className="rounded-3xl border border-border bg-card/30 p-5 sm:p-7 md:p-8">
      <div className="mb-5">
        <div className="font-display text-base sm:text-lg font-extrabold uppercase tracking-tight">{title}</div>
        {subtitle ? <div className="mt-1 text-xs sm:text-sm text-muted-foreground">{subtitle}</div> : null}
      </div>
      {children}
    </div>
  );
}

function Field({ label, required, className, error, children }: { label: string; required?: boolean; className?: string; error?: string; children: React.ReactNode }) {
  return (
    <label className={`block ${className ?? ""}`}>
      <span className="font-mono text-[10px] uppercase tracking-[0.25em] text-muted-foreground">
        {label}{required ? <span className="text-primary"> *</span> : null}
      </span>
      <div className="mt-2">{children}</div>
      {error ? <div className="mt-1.5 text-xs text-secondary">{error}</div> : null}
    </label>
  );
}

function YesNo({ label, value, onChange }: { label: string; value: boolean; onChange: (v: boolean) => void }) {
  return (
    <div className="flex flex-col gap-3 rounded-2xl border border-border bg-card/40 p-4 sm:flex-row sm:items-center sm:justify-between">
      <div className="text-sm text-foreground/90 leading-relaxed pr-2">{label}</div>
      <div className="flex shrink-0 items-center gap-2">
        <button
          type="button"
          onClick={() => onChange(true)}
          className={`flex-1 sm:flex-none rounded-full px-4 py-2 text-xs font-semibold uppercase tracking-wider transition-colors ${value ? "bg-primary text-primary-foreground" : "border border-border bg-card/50 text-muted-foreground hover:text-foreground hover:border-primary/40"}`}
        >
          Yes
        </button>
        <button
          type="button"
          onClick={() => onChange(false)}
          className={`flex-1 sm:flex-none rounded-full px-4 py-2 text-xs font-semibold uppercase tracking-wider transition-colors ${!value ? "bg-secondary text-secondary-foreground" : "border border-border bg-card/50 text-muted-foreground hover:text-foreground hover:border-primary/40"}`}
        >
          No
        </button>
      </div>
    </div>
  );
}

function questionFor(key: keyof RolloutAnswers): string {
  switch (key) {
    case "has_website": return "Do you have a website or landing page for this release?";
    case "has_email_capture": return "Do you have email capture set up?";
    case "has_sms_capture": return "Do you have SMS capture set up?";
    case "has_crm": return "Do you have a CRM or follow-up system?";
    case "has_merch": return "Do you have merch or an offer ready?";
    case "has_content_plan": return "Do you have a content plan for before and after the release?";
    case "has_smart_link": return "Do you have a pre-save, smart link, or music link hub?";
    case "has_tracking": return "Do you have analytics, pixels, or tracking installed?";
    case "has_post_release_plan": return "Do you have a post-release follow-up plan?";
  }
}