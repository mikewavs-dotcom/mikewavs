import { useEffect, useRef } from "react";
import logo from "@/assets/mikewavs-logo.png.asset.json";

/**
 * VinylHeroBackground
 * Interactive hero background: spinning vinyl record with rim-light tracking
 * the cursor, gold groove sheen, Mikewavs mark pressed into the label, and
 * a constant film grain overlay.
 */

const COLORS = {
  bg: "#080810",
  fg: "#E8E8F0",
  card: "#0C0C14",
  gold: "#8141F7",
  goldDeep: "#6A2FD9",
  goldMuted: "#9A8FB8",
  border: "rgba(129,65,247,0.22)",
};

export default function VinylHeroBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rafRef = useRef<number | undefined>(undefined);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d", { alpha: true });
    if (!ctx) return;

    const prefersReducedMotion = window.matchMedia(
      "(prefers-reduced-motion: reduce)"
    ).matches;

    let width = 0;
    let height = 0;
    let dpr = Math.min(window.devicePixelRatio || 1, 2);

    const pointer = { x: 0.72, y: 0.42 };
    const pointerTarget = { x: 0.72, y: 0.42 };
    // Scratch state: extra angular velocity driven by pointer movement
    let scratchVel = 0;
    let scratchTargetVel = 0;
    let lastPointer = { x: pointerTarget.x, y: pointerTarget.y, t: performance.now() };
    const vinylGeom = { cx: 0, cy: 0, radius: 1 };

    // Trail: recent pointer positions in pixel space, plus a per-point
    // "intensity" sampled from the current scratch velocity so faster
    // gestures leave a brighter streak. Points fade out over ~450ms.
    type TrailPoint = { x: number; y: number; t: number; intensity: number };
    const trail: TrailPoint[] = [];
    const TRAIL_MAX = 48;
    const TRAIL_LIFE = 450;

    // Per-input-device tuning. Trackpads report as 'mouse' in PointerEvents,
    // so we detect them heuristically: very small, high-frequency wheel-like
    // movements (sub-pixel) get a slightly lower gain than a real mouse.
    // Touch fingers travel many more pixels per gesture, so they need a
    // much lower gain and a higher decay (gesture lingers like a real spin).
    const DEVICE_TUNE: Record<
      "mouse" | "trackpad" | "touch" | "pen",
      { gain: number; maxVel: number; decay: number }
    > = {
      mouse:    { gain: 0.38, maxVel: 0.028, decay: 0.90 },
      trackpad: { gain: 0.28, maxVel: 0.022, decay: 0.91 },
      touch:    { gain: 0.18, maxVel: 0.045, decay: 0.94 },
      pen:      { gain: 0.30, maxVel: 0.030, decay: 0.91 },
    };
    let activeDevice: keyof typeof DEVICE_TUNE = "mouse";

    let grainCanvas: HTMLCanvasElement | null = null;

    let tintedMark: HTMLCanvasElement | null = null;
    let markReady = false;
    const markImg = new Image();
    markImg.crossOrigin = "anonymous";
    markImg.onload = () => {
      const size = 256;
      const t = document.createElement("canvas");
      t.width = size;
      t.height = size;
      const tctx = t.getContext("2d");
      if (!tctx) return;
      const ratio = Math.min(size / markImg.width, size / markImg.height);
      const w = markImg.width * ratio;
      const h = markImg.height * ratio;
      tctx.drawImage(markImg, (size - w) / 2, (size - h) / 2, w, h);
      // Recolor silhouette to a muted deep gold using source-in (works on
      // any opaque/alpha source — full-color or white-on-transparent).
      tctx.globalCompositeOperation = "source-in";
      tctx.fillStyle = "#FFFFFF";
      tctx.fillRect(0, 0, size, size);
      tctx.globalCompositeOperation = "source-over";
      tintedMark = t;
      markReady = true;
    };
    markImg.src = logo.url;

    function buildGrain() {
      const size = 160;
      const g = document.createElement("canvas");
      g.width = size;
      g.height = size;
      const gctx = g.getContext("2d");
      if (!gctx) return null;
      const imageData = gctx.createImageData(size, size);
      for (let i = 0; i < imageData.data.length; i += 4) {
        const v = Math.random() * 255;
        imageData.data[i] = v;
        imageData.data[i + 1] = v;
        imageData.data[i + 2] = v;
        imageData.data[i + 3] = Math.random() * 18;
      }
      gctx.putImageData(imageData, 0, 0);
      return g;
    }

    function resize() {
      const rect = canvas!.getBoundingClientRect();
      width = rect.width;
      height = rect.height;
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas!.width = width * dpr;
      canvas!.height = height * dpr;
      ctx!.setTransform(dpr, 0, 0, dpr, 0, 0);
      grainCanvas = buildGrain();
    }

    resize();
    window.addEventListener("resize", resize);

    function handlePointerMove(e: PointerEvent) {
      const rect = canvas!.getBoundingClientRect();
      const px = e.clientX - rect.left;
      const py = e.clientY - rect.top;
      const nx = px / rect.width;
      const ny = py / rect.height;
      const now = performance.now();

      // Classify the input. Touch/pen are explicit; mouse vs trackpad is
      // inferred from per-event displacement (trackpads emit many tiny
      // sub-pixel deltas, mice emit larger ones).
      if (e.pointerType === "touch") {
        activeDevice = "touch";
      } else if (e.pointerType === "pen") {
        activeDevice = "pen";
      } else {
        const stepPx = Math.hypot(
          (nx - lastPointer.x) * rect.width,
          (ny - lastPointer.y) * rect.height
        );
        activeDevice = stepPx > 0 && stepPx < 1.5 ? "trackpad" : "mouse";
      }
      const tune = DEVICE_TUNE[activeDevice];

      // Pixel-space math against the actual rendered vinyl keeps the
      // scratch feel identical across viewport sizes & aspect ratios.
      const rx = px - vinylGeom.cx;
      const ry = py - vinylGeom.cy;
      const r = Math.sqrt(rx * rx + ry * ry);
      const radius = vinylGeom.radius || 1;

      if (r > radius * 0.06) {
        const dxPx = (nx - lastPointer.x) * rect.width;
        const dyPx = (ny - lastPointer.y) * rect.height;
        // unit tangent perpendicular to the radius vector
        const tx = -ry / r;
        const ty = rx / r;
        // angular delta = tangential pixel displacement / radius
        const dAngle = (dxPx * tx + dyPx * ty) / radius;

        // Proximity peaks near the rim (where a real hand would scratch),
        // softens toward center and just outside the disc.
        const norm = r / radius;
        const proximity =
          norm <= 1
            ? 0.35 + 0.65 * Math.min(1, norm / 0.85)
            : Math.max(0, 1 - (norm - 1) / 0.4);

        scratchTargetVel = dAngle * proximity * tune.gain;
      }

      if (scratchTargetVel >  tune.maxVel) scratchTargetVel =  tune.maxVel;
      if (scratchTargetVel < -tune.maxVel) scratchTargetVel = -tune.maxVel;

      // Record a trail point in pixel space BEFORE we overwrite lastPointer
      // so we can derive pointer speed from the previous sample.
      const speed = Math.hypot(
        (nx - lastPointer.x) * rect.width,
        (ny - lastPointer.y) * rect.height
      );
      const intensity = Math.min(
        1,
        Math.abs(scratchTargetVel) / (DEVICE_TUNE[activeDevice].maxVel || 1) +
          speed * 0.04
      );
      trail.push({ x: px, y: py, t: now, intensity });
      if (trail.length > TRAIL_MAX) trail.shift();

      lastPointer = { x: nx, y: ny, t: now };
      pointerTarget.x = nx;
      pointerTarget.y = ny;
    }
    window.addEventListener("pointermove", handlePointerMove, { passive: true });
    // Touch also dispatches pointer events, but we want the same scratch
    // feel from a tap-and-drag; mark the device on pointerdown too.
    function handlePointerDown(e: PointerEvent) {
      if (e.pointerType === "touch") activeDevice = "touch";
      else if (e.pointerType === "pen") activeDevice = "pen";
    }
    window.addEventListener("pointerdown", handlePointerDown, { passive: true });

    let angle = 0;
    let lastTime = performance.now();

    function drawGrooves(cx: number, cy: number, radius: number, lightAngle: number, lightStrength: number) {
      const grooveCount = 46;
      const innerRatio = 0.22;
      for (let i = 0; i < grooveCount; i++) {
        const t = i / (grooveCount - 1);
        const r = radius * (innerRatio + t * (1 - innerRatio));
        ctx!.beginPath();
        ctx!.arc(cx, cy, r, 0, Math.PI * 2);

        const baseAlpha = 0.5 + 0.5 * Math.sin(t * Math.PI * 9);
        ctx!.strokeStyle = `rgba(0,0,0,${0.18 + baseAlpha * 0.08})`;
        ctx!.lineWidth = 1;
        ctx!.stroke();

        const sheenSpread = 1.15;
        ctx!.save();
        ctx!.beginPath();
        ctx!.arc(cx, cy, r, lightAngle - sheenSpread / 2, lightAngle + sheenSpread / 2);
        const sheenAlpha = lightStrength * (0.16 + 0.1 * Math.sin(t * Math.PI * 5 + angle));
        ctx!.strokeStyle = `rgba(224,184,74,${Math.max(0, sheenAlpha)})`;
        ctx!.lineWidth = 1;
        ctx!.stroke();
        ctx!.restore();
      }
    }

    function drawLabel(cx: number, cy: number, radius: number, spinAngle: number) {
      const labelRadius = radius * 0.22;

      ctx!.save();
      ctx!.translate(cx, cy);
      ctx!.rotate(spinAngle);

      const labelGrad = ctx!.createRadialGradient(0, 0, 0, 0, 0, labelRadius);
      labelGrad.addColorStop(0, COLORS.goldDeep);
      labelGrad.addColorStop(1, "#7a5e22");
      ctx!.beginPath();
      ctx!.arc(0, 0, labelRadius, 0, Math.PI * 2);
      ctx!.fillStyle = labelGrad;
      ctx!.fill();

      ctx!.strokeStyle = "rgba(13,11,7,0.35)";
      ctx!.lineWidth = labelRadius * 0.5;
      ctx!.beginPath();
      ctx!.arc(0, 0, labelRadius * 0.62, 0.4, 2.1);
      ctx!.stroke();

      if (markReady && tintedMark) {
        const markSize = labelRadius * 1.5;
        ctx!.globalAlpha = 0.85;
        ctx!.drawImage(tintedMark, -markSize / 2, -markSize / 2, markSize, markSize);
        ctx!.globalAlpha = 1;
      }

      ctx!.beginPath();
      ctx!.arc(0, 0, labelRadius * 0.09, 0, Math.PI * 2);
      ctx!.fillStyle = COLORS.bg;
      ctx!.fill();

      ctx!.restore();
    }

    function frame() {
      const now = performance.now();
      const dt = Math.min(now - lastTime, 48);
      lastTime = now;

      pointer.x += (pointerTarget.x - pointer.x) * 0.04;
      pointer.y += (pointerTarget.y - pointer.y) * 0.04;

      if (!prefersReducedMotion) {
        // ~30°/sec idle spin — slow enough that the scratch reads clearly
        // on the label, fast enough to look alive.
        angle += dt * 0.0005;
      }
      // Two-stage eased scratch: target velocity eases toward the pointer
      // input with an exponential curve, then the smoothed velocity drives
      // the disc. This gives the vinyl natural inertia and eliminates jitter
      // on start / stop.
      const ease = 1 - Math.pow(0.22, dt / 16);
      scratchVel += (scratchTargetVel - scratchVel) * ease;
      scratchTargetVel *= Math.pow(0.78, dt / 16);

      angle += scratchVel * (dt / 16);
      scratchVel *= Math.pow(DEVICE_TUNE[activeDevice].decay, dt / 16);

      ctx!.clearRect(0, 0, width, height);

      const cx = width * 0.78;
      const cy = height * 0.42;
      const radius = Math.min(width, height) * 0.62;
      vinylGeom.cx = cx;
      vinylGeom.cy = cy;
      vinylGeom.radius = radius;

      const ambient = ctx!.createRadialGradient(cx, cy, radius * 0.1, cx, cy, radius * 1.35);
      ambient.addColorStop(0, "rgba(224,184,74,0.10)");
      ambient.addColorStop(1, "rgba(224,184,74,0)");
      ctx!.fillStyle = ambient;
      ctx!.fillRect(0, 0, width, height);

      ctx!.beginPath();
      ctx!.arc(cx, cy, radius, 0, Math.PI * 2);
      ctx!.fillStyle = COLORS.card;
      ctx!.fill();

      const dx = pointer.x * width - cx;
      const dy = pointer.y * height - cy;
      const lightAngle = Math.atan2(dy, dx);
      const dist = Math.sqrt(dx * dx + dy * dy);
      const lightStrength = Math.max(0.35, 1 - dist / (radius * 2.2));

      drawGrooves(cx, cy, radius, lightAngle, lightStrength);

      ctx!.save();
      ctx!.beginPath();
      ctx!.arc(cx, cy, radius, 0, Math.PI * 2);
      ctx!.lineWidth = 2;
      ctx!.strokeStyle = COLORS.border;
      ctx!.stroke();

      ctx!.beginPath();
      ctx!.arc(cx, cy, radius - 1, lightAngle - 0.5, lightAngle + 0.5);
      ctx!.lineWidth = 2.5;
      ctx!.strokeStyle = `rgba(224,184,74,${0.35 * lightStrength + 0.15})`;
      ctx!.stroke();
      ctx!.restore();

      // Label rotates 1:1 with the disc so a scratch visibly grabs and
      // turns the middle (instead of being washed out by a fast base spin).
      drawLabel(cx, cy, radius, angle);

      // Cursor trail — gold streak that follows the scratch. Drawn after
      // the disc so it reads on top of the grooves but under the vignette
      // / grain for a filmic feel.
      if (trail.length > 1) {
        // Drop stale points.
        while (trail.length && now - trail[0].t > TRAIL_LIFE) trail.shift();

        ctx!.save();
        ctx!.globalCompositeOperation = "lighter";
        ctx!.lineCap = "round";
        ctx!.lineJoin = "round";
        for (let i = 1; i < trail.length; i++) {
          const a = trail[i - 1];
          const b = trail[i];
          const ageB = (now - b.t) / TRAIL_LIFE;
          if (ageB >= 1) continue;
          const fade = 1 - ageB;
          const intensity = (a.intensity + b.intensity) * 0.5;
          const alpha = 0.45 * fade * (0.25 + 0.75 * intensity);
          const w = (1.2 + 4.5 * intensity) * fade;
          ctx!.beginPath();
          ctx!.moveTo(a.x, a.y);
          ctx!.lineTo(b.x, b.y);
          ctx!.strokeStyle = `rgba(224,184,74,${alpha})`;
          ctx!.lineWidth = w;
          ctx!.stroke();
          // Inner hot line for a sharper highlight.
          ctx!.strokeStyle = `rgba(180,140,255,${alpha * 0.6})`;
          ctx!.lineWidth = Math.max(0.6, w * 0.35);
          ctx!.stroke();
        }
        ctx!.restore();
      }

      const vignette = ctx!.createRadialGradient(
        width * 0.5,
        height * 0.5,
        0,
        width * 0.5,
        height * 0.5,
        Math.max(width, height) * 0.75
      );
      vignette.addColorStop(0, "rgba(13,11,7,0)");
      vignette.addColorStop(1, COLORS.bg);
      ctx!.fillStyle = vignette;
      ctx!.fillRect(0, 0, width, height);

      if (grainCanvas) {
        const pattern = ctx!.createPattern(grainCanvas, "repeat");
        if (pattern) {
          ctx!.fillStyle = pattern;
          ctx!.fillRect(0, 0, width, height);
        }
      }

      rafRef.current = requestAnimationFrame(frame);
    }

    rafRef.current = requestAnimationFrame(frame);

    return () => {
      window.removeEventListener("resize", resize);
      window.removeEventListener("pointermove", handlePointerMove);
      window.removeEventListener("pointerdown", handlePointerDown);
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      style={{
        position: "absolute",
        inset: 0,
        width: "100%",
        height: "100%",
        display: "block",
        background: COLORS.bg,
        pointerEvents: "none",
      }}
    />
  );
}