export function InstagramLink({ className = "" }: { className?: string }) {
  return (
    <a
      href="https://instagram.com/mikewavs"
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Instagram"
      className={`inline-flex items-center justify-center rounded-full border border-border bg-card/50 h-9 w-9 md:h-10 md:w-10 text-muted-foreground hover:text-foreground transition-colors shrink-0 ${className}`}
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="20"
        height="20"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="h-[18px] w-[18px]"
      >
        <rect width="20" height="20" x="2" y="2" rx="5" ry="5" />
        <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
        <line x1="17.5" x2="17.51" y1="6.5" y2="6.5" />
      </svg>
    </a>
  );
}
