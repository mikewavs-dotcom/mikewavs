import logo from "@/assets/mikewavs-logo.png.asset.json";

export function Footer() {
  return (
    <footer className="relative z-10 border-t border-border">
      <div className="mx-auto flex max-w-7xl flex-col gap-3 px-4 py-8 sm:px-5 md:px-8 md:py-10 md:flex-row md:items-center md:justify-between">
        <div className="flex items-center gap-2.5">
          <img src={logo.url} alt="Mikewavs" className="h-7 w-auto object-contain" />
          <span className="font-mono text-[10px] md:text-[11px] uppercase tracking-[0.25em] text-muted-foreground">© 2026 / Mikewavs / All Rights Reserved</span>
        </div>
        <p className="font-mono text-[10px] md:text-[11px] uppercase tracking-[0.3em] text-muted-foreground">
          Digital Strategy / Web Design / Direct-To-Fan Systems
        </p>
      </div>
    </footer>
  );
}