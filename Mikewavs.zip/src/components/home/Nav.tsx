import { useState } from "react";
import { ArrowRight, Calendar, Menu, X } from "lucide-react";
import { InstagramLink } from "@/components/InstagramLink";
import logo from "@/assets/mikewavs-logo.png.asset.json";

export function Nav() {
  const [open, setOpen] = useState(false);
  const links = [
    { href: "#about", label: "About" },
    { href: "#services", label: "Services" },
    { href: "#clients", label: "PAST & CURRENT CLIENTS" },
    { href: "/blog", label: "Artist Resources" },
    { href: "#download-link", label: "Free Music Rollout Checklist" },
    { href: "/contact", label: "Contact" },
  ];
  return (
    <>
      <header data-anim="nav" className="sticky top-0 z-50 border-b border-border/40 backdrop-blur-xl bg-background/70">
        <div className="mx-auto grid grid-cols-[auto_1fr_auto] items-center gap-3 max-w-7xl px-4 py-3 lg:px-8 lg:py-4">
          <a href="#top" className="flex min-w-0 items-center gap-2 group">
            <img src={logo.url} alt="Mikewavs" className="h-8 lg:h-10 w-auto object-contain" />
          </a>
          <nav className="hidden lg:flex justify-center items-center gap-6 xl:gap-8 text-[13px] xl:text-sm text-muted-foreground whitespace-nowrap">
            {links.map((l) => (
              <a key={l.href} href={l.href} className="hover:text-primary transition-colors">{l.label}</a>
            ))}
          </nav>
          <div className="flex items-center gap-2 lg:gap-3 justify-self-end">
            <InstagramLink />
            <a href="https://calendly.com/nocoolpoints/1-1-consultation?month=2026-06" className="cta hidden lg:inline-flex items-center gap-1.5 rounded-full bg-gradient-primary px-4 py-2 text-sm font-semibold text-primary-foreground transition-all hover:opacity-90 hover:-translate-y-0.5 hover:shadow-[0_0_28px_-6px_rgba(129,65,247,0.55)] shadow-card-elevated whitespace-nowrap">
              Book Consultation <ArrowRight className="h-3.5 w-3.5" />
            </a>
            <button
              type="button"
              aria-label={open ? "Close menu" : "Open menu"}
              aria-expanded={open}
              onClick={() => setOpen((v) => !v)}
              className="lg:hidden inline-flex h-10 w-10 items-center justify-center rounded-full border border-border bg-card/50 text-foreground transition-colors hover:bg-card"
            >
              {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>
      </header>

      <div
        className={`lg:hidden fixed inset-0 z-[60] transition-opacity duration-300 ${
          open ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"
        }`}
        aria-hidden={!open}
      >
        <div
          onClick={() => setOpen(false)}
          className={`absolute inset-0 bg-black/80 transition-opacity duration-300 ${
            open ? "opacity-100" : "opacity-0"
          }`}
        />
        <nav
          role="dialog"
          aria-label="Mobile navigation"
          className={`absolute right-0 top-0 h-dvh w-[82%] max-w-sm border-l border-border/60 bg-black shadow-card-elevated transform-gpu transition-transform duration-300 ease-[cubic-bezier(0.22,1,0.36,1)] ${
            open ? "translate-x-0" : "translate-x-full"
          }`}
        >
          <div className="flex items-center justify-between border-b border-border/40 px-5 py-4">
            <img src={logo.url} alt="Mikewavs" className="h-8 w-auto object-contain" />
            <button
              type="button"
              aria-label="Close menu"
              onClick={() => setOpen(false)}
              className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-border bg-card/50 text-foreground transition-colors hover:bg-card"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
          <div className="flex flex-col px-5 py-4">
            {links.map((l) => (
              <a
                key={l.href}
                href={l.href}
                onClick={() => setOpen(false)}
                className="border-b border-border/40 py-3 text-sm font-semibold text-foreground/90 last:border-b-0"
              >
                {l.label}
              </a>
            ))}
            <a
              href="https://calendly.com/nocoolpoints/1-1-consultation?month=2026-06"
              onClick={() => setOpen(false)}
              className="cta mt-5 inline-flex items-center justify-center gap-2 rounded-full bg-gradient-primary px-5 py-3 text-sm font-semibold text-primary-foreground transition-shadow hover:shadow-[0_0_28px_-6px_rgba(129,65,247,0.55)]"
            >
              <Calendar className="h-4 w-4" /> Book Consultation
            </a>
          </div>
        </nav>
      </div>
    </>
  );
}