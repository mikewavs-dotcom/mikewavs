export function BackgroundFX() {
  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
      {/* Soft warm spotlight near hero — no visible circle */}
      <div
        className="absolute inset-x-0 top-0 h-[80vh]"
        style={{
          backgroundImage:
            "radial-gradient(80% 60% at 50% 0%, rgba(129,65,247,0.10) 0%, rgba(129,65,247,0.05) 35%, transparent 70%)",
        }}
      />
      {/* Static film grain */}
      <div className="absolute inset-0 editorial-grain" />
    </div>
  );
}