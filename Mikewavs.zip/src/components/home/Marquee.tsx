export function Marquee() {
  const items = ["Release Campaigns", "Artist Websites", "Fan Capture", "CRM Systems", "Email & SMS", "Merch Support", "Analytics", "Direct-To-Fan Growth"];
  const row = [...items, ...items];
  return (
    <section data-anim="section" aria-label="Capabilities" className="relative z-10 border-y border-primary/30 bg-card/30 py-4 md:py-5 overflow-hidden">
      <div className="flex w-max animate-marquee gap-10 md:gap-12 px-6 font-mono text-[10px] md:text-xs uppercase tracking-[0.35em] text-muted-foreground">
        {row.map((t, i) => (
          <span key={i} className="flex items-center gap-10 md:gap-12 whitespace-nowrap">
            {t}
            <span className="h-1.5 w-1.5 rounded-full bg-primary/60" />
          </span>
        ))}
      </div>
    </section>
  );
}