export function SectionLabel({ children, number }: { children: React.ReactNode; number?: string }) {
  return (
    <div className="inline-flex items-center gap-3 font-mono text-[10px] md:text-[11px] uppercase tracking-[0.35em] text-primary">
      {number ? <span className="text-primary/80">{number}</span> : null}
      <span className="h-px w-8 bg-primary/60" />
      <span className="text-primary">{children}</span>
    </div>
  );
}