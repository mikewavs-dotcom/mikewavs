import portrait from "@/assets/mikewavs-studio.png.asset.json";
import { SectionLabel } from "./SectionLabel";

export function About() {
  const timeline = [
    { year: "2014", title: "Started in Digital Strategy", body: "Began working in direct-to-fan strategy, release campaigns, touring support, Webflow and Shopify websites, CRM systems, email/SMS fan capture, and artist development." },
    { year: "2018+", title: "Artist & Brand Work", body: "Supported artists and music brands including Luh Kiddo, Darkchild's Alienz Alive, Damon Elliott, Young Nudy, Chaz French, Nardo Wick, and projects connected to the Chris Brown camp." },
    { year: "2024", title: "Major Activations", body: "Worked with Affiliation Group on major activations connected to BigXthaPlug, Young Nudy, Nardo Wick, Chris Brown, Skillibeng, Miguel, and Freddie Dredd." },
    { year: "2025", title: "Co-Founded VA Distribution", body: "Co-founded a Virginia-based distribution company with Octavion X, Lamarr Johnson, and Ken Kwaku — a hub for independent artists across the East Coast." },
  ];
  return (
    <section className="surface-raised border-y border-border/60">
      <div data-anim="section" id="about" className="relative z-10 mx-auto max-w-7xl px-6 sm:px-8 md:px-10 py-20 md:py-28">
      <div className="max-w-3xl">
        <SectionLabel number="01 //">Vision</SectionLabel>
        <h2 className="mt-4 font-display text-[1.75rem] sm:text-[2rem] md:text-[2.5rem] font-extrabold uppercase leading-[1.05] tracking-tight">
          Built at the intersection of <span className="text-foreground/40">music, digital strategy,</span> <span className="text-gradient-primary">and systems.</span>
        </h2>
      </div>

      <div className="mt-12 md:mt-14 grid gap-10 lg:grid-cols-[0.85fr_1.15fr] lg:gap-16 items-start">
        {/* Portrait */}
        <div className="relative">
          <div className="relative overflow-hidden rounded-2xl md:rounded-3xl border border-border shadow-card-elevated">
            <img
              src={portrait.url}
              alt="Mikewavs at Patchwerk Recording Studios"
              className="block w-full h-auto object-cover aspect-[3/4]"
              loading="lazy"
            />
            <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-background/80 via-background/10 to-transparent" />
            <div className="absolute inset-x-0 bottom-0 p-4 md:p-6">
              <p className="font-display text-sm sm:text-base font-bold uppercase tracking-tight text-foreground/90">Mike Wavs — Digital Strategist</p>
            </div>
          </div>

          <div className="mt-4 md:mt-6 grid grid-cols-2 gap-2.5 md:gap-3">
            {[
              { n: "10+", l: "Years" },
              { n: "50+", l: "Artists & Brands" },
            ].map((s) => (
              <div key={s.l} className="glass-card p-2.5 md:p-3 text-center">
                <div className="font-display text-base md:text-xl font-extrabold text-gradient-primary">{s.n}</div>
                <div className="mt-0.5 font-mono text-[9px] md:text-[10px] uppercase tracking-[0.25em] text-muted-foreground leading-tight">{s.l}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Bio + Timeline */}
        <div>
          <p className="text-[15px] md:text-base text-muted-foreground leading-[1.7]">
            <span className="text-foreground font-semibold">Mikewavs</span> is a digital strategist, web designer, and digital infrastructure builder with over 10 years of experience helping independent artists, labels, and managers grow their fanbases and monetize their audience.
          </p>

          <ol className="mt-10 relative border-l-2 border-accent-muted/60 pl-6 md:pl-7 space-y-6 md:space-y-7">
            {timeline.map((t) => (
              <li key={t.year} className="relative">
                <span aria-hidden className="absolute -left-[27px] md:-left-[31px] top-1.5 grid h-4 w-4 place-items-center rounded-full bg-background ring-2 ring-accent-muted">
                  <span className="h-1.5 w-1.5 rounded-full bg-accent-muted" />
                </span>
                <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
                  <span className="font-mono text-[10px] md:text-[11px] tracking-[0.3em] text-accent-muted">{t.year}</span>
                  <h3 className="font-display text-[15px] md:text-lg font-bold uppercase tracking-tight leading-snug">{t.title}</h3>
                </div>
                <p className="mt-2 text-[14px] md:text-[15px] text-muted-foreground leading-[1.7]">{t.body}</p>
              </li>
            ))}
          </ol>
        </div>
      </div>
      </div>
    </section>
  );
}