import { SectionLabel } from "./SectionLabel";
import noCoolPointsLogo from "@/assets/partners/no-cool-points.png.asset.json";
import wavsDigitalLogo from "@/assets/partners/wavs-digital.png.asset.json";
import brandMarkLogo from "@/assets/partners/brand-mark.png.asset.json";
import cultrhausLogo from "@/assets/partners/cultrhaus.png.asset.json";
import mediumCreativeLogo from "@/assets/partners/medium-creative-agency.png.asset.json";

export function Partners() {
  const partners = [
    { name: "No Cool Points", src: noCoolPointsLogo.url, invert: false },
    { name: "Wavs Digital", src: wavsDigitalLogo.url, invert: false },
    { name: "Brand Mark", src: brandMarkLogo.url, invert: false },
    { name: "Cultrhaus", src: cultrhausLogo.url, invert: false },
    { name: "Medium Creative Agency", src: mediumCreativeLogo.url, invert: false },
  ];
  const row = [...partners, ...partners];
  return (
    <section className="surface-raised border-y border-border/60">
      <div data-anim="section" id="partners" className="relative z-10 mx-auto max-w-7xl px-6 sm:px-8 md:px-10 py-20 md:py-28">
      <div className="max-w-3xl">
        <SectionLabel number="04 //">Partners</SectionLabel>
        <h2 className="mt-4 font-display text-[1.75rem] sm:text-[2rem] md:text-[2.5rem] font-extrabold uppercase leading-[1.05] tracking-tight [text-wrap:balance]">
          Collaborators, platforms, <span className="text-gradient-primary">and partners.</span>
        </h2>
        <p className="mt-6 text-[15px] md:text-base text-muted-foreground leading-[1.7] whitespace-pre-line">
          {"\n"}
        </p>
      </div>

      <div className="mt-12 relative overflow-hidden rounded-2xl border border-border bg-card/30">
        <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-16 md:w-24 bg-gradient-to-r from-background to-transparent" />
        <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-16 md:w-24 bg-gradient-to-l from-background to-transparent" />
        <div className="flex w-max animate-marquee-reverse items-center gap-8 sm:gap-12 md:gap-16 lg:gap-24 py-10 md:py-14 px-4 sm:px-6 md:px-8 will-change-transform [transform:translateZ(0)] [backface-visibility:hidden]">
          {row.map((p, i) => (
            <div
              key={`${p.name}-${i}`}
              className="shrink-0 flex items-center justify-center h-16 sm:h-20 md:h-24 lg:h-28 opacity-70 hover:opacity-100 transition-all duration-300 rounded-xl hover:ring-1 hover:ring-primary/40 px-3"
              title={p.name}
            >
              <img
                src={p.src}
                alt={`${p.name} — Mikewavs partner`}
                loading="eager"
                decoding="async"
                draggable={false}
                className={`h-full w-auto max-w-[160px] sm:max-w-[220px] md:max-w-[280px] lg:max-w-[340px] object-contain ${p.invert ? "brightness-0 invert" : ""}`}
              />
            </div>
          ))}

        </div>
      </div>
      </div>
    </section>
  );
}