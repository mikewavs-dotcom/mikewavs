import { Link } from "@tanstack/react-router";
import { ArrowRight, Download, Sparkles, Library } from "lucide-react";
import { SectionLabel } from "./SectionLabel";

export function FreeDownload() {
  return (
    <section className="surface-base">
      <div data-anim="section" id="download-link" className="relative z-10 mx-auto max-w-7xl px-6 sm:px-8 md:px-10 py-20 md:py-28">
      <div className="grid gap-10 lg:grid-cols-[1.2fr_1fr] lg:gap-16 items-center">
        <div>
          <SectionLabel number="05 //">Free Rollout Checklist</SectionLabel>
          <h2 className="mt-4 font-display text-3xl sm:text-4xl md:text-5xl font-extrabold uppercase leading-[1.05] tracking-tight [text-wrap:balance]">
            Start with a <span className="text-gradient-primary">stronger rollout.</span>
          </h2>
          <p className="mt-6 text-[15px] md:text-base text-muted-foreground leading-[1.7] max-w-xl">
            Grab the Music Rollout Checklist and use it to organize your release plan, content, website, fan capture, and follow-up before your next drop.
          </p>
          <div className="mt-8 flex flex-col sm:flex-row sm:flex-wrap gap-3">
            <a href="https://portal.wavsdigital.com/public/6a209501ae3dfd51b118f21f" target="_blank" rel="noopener noreferrer" className="inline-flex items-center justify-center gap-2 rounded-full bg-gradient-primary px-5 py-3 md:px-6 md:py-3.5 text-sm font-semibold text-primary-foreground transition-all hover:-translate-y-0.5 hover:scale-[1.02] hover:shadow-[0_0_32px_-6px_rgba(129,65,247,0.6)] glow-primary">
              <Download className="h-4 w-4" /> Download Checklist
            </a>
            <Link to="/tools/music-rollout-builder" className="inline-flex items-center justify-center gap-2 rounded-full border-2 border-accent-muted/60 bg-transparent px-5 py-3 md:px-6 md:py-3.5 text-sm font-semibold text-foreground transition-all hover:bg-accent-muted/10 hover:-translate-y-0.5 hover:shadow-[0_0_24px_-8px_rgba(156,133,80,0.45)]">
              <Sparkles className="h-4 w-4 text-primary" /> Free Tool: Check Your Music Rollout Readiness <ArrowRight className="h-4 w-4" />
            </Link>
            <Link to="/resources/music-marketing-stack" className="inline-flex items-center justify-center gap-2 rounded-full border-2 border-accent-muted/60 bg-transparent px-5 py-3 md:px-6 md:py-3.5 text-sm font-semibold text-foreground transition-all hover:bg-accent-muted/10 hover:-translate-y-0.5 hover:shadow-[0_0_24px_-8px_rgba(156,133,80,0.45)]">
              <Library className="h-4 w-4 text-primary" /> The Independent Music Marketing Stack 2026 <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
        <div className="glass-card shadow-card-elevated border-l-2 border-l-accent-muted/60 p-7 sm:p-8 md:p-10 relative overflow-hidden">
          <div className="relative">
            <div className="inline-flex items-center gap-1.5 font-mono text-[10px] md:text-[11px] uppercase tracking-[0.3em] text-accent-muted">
              <Download className="h-3.5 w-3.5" /> Free Asset
            </div>
            <h3 className="mt-3 font-display text-lg md:text-xl font-bold uppercase tracking-tight leading-snug">Music Rollout Checklist</h3>
            <p className="mt-4 text-[14px] md:text-base text-muted-foreground leading-[1.7]">
              A simple planning asset for artists and music teams that want a cleaner, more organized release campaign.
            </p>
            <div className="mt-6 space-y-3">
              {["Pre-release timeline", "Content & creative checklist", "Fan capture setup", "Post-release follow-up"].map((i) => (
                <div key={i} className="flex items-center gap-3 text-[13px] md:text-sm text-foreground/80">
                  <span className="h-1.5 w-1.5 rounded-full bg-accent-muted" /> {i}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
      </div>
    </section>
  );
}