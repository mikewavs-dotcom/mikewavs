import { ClientImage } from "@/components/ClientImage";
import { SectionLabel } from "./SectionLabel";
import roryMal from "@/assets/clients/rory-mal.jpg.asset.json";
import damonElliott from "@/assets/clients/damon-elliott.webp.asset.json";
import darkhildAlienzAlive from "@/assets/clients/darkhild-alienz-alive.jpg.asset.json";
import luhKiddo from "@/assets/clients/luh-kiddo.jpg.asset.json";
import youngNudy from "@/assets/clients/young-nudy.webp.asset.json";
import nardoWick from "@/assets/clients/nardo-wick.webp.asset.json";
import chazFrench from "@/assets/clients/chaz-french.webp.asset.json";
import asapRocky from "@/assets/clients/asap-rocky.webp.asset.json";
import freddieDreadd from "@/assets/clients/freddie-dreadd.jpg.asset.json";
import chrisBrown from "@/assets/clients/chris-brown.jpg.asset.json";
import miguel from "@/assets/clients/miguel.jpg.asset.json";

export function Clients() {
  const clientPhotos = [
    { name: "New Rory & Mal", src: roryMal.url, fit: "cover" as const },
    { name: "Damon Elliott", src: damonElliott.url, fit: "cover" as const },
    { name: "Darkchild — Alienz Alive", src: darkhildAlienzAlive.url, fit: "cover" as const },
    { name: "Luh Kiddo", src: luhKiddo.url, fit: "cover" as const },
    { name: "Young Nudy", src: youngNudy.url, fit: "cover" as const },
    { name: "Nardo Wick", src: nardoWick.url, fit: "cover" as const },
    { name: "Chaz French", src: chazFrench.url, fit: "cover" as const },
    { name: "A$AP Rocky", src: asapRocky.url, fit: "cover" as const },
    { name: "Freddie Dredd", src: freddieDreadd.url, fit: "cover" as const },
    { name: "Chris Brown", src: chrisBrown.url, fit: "cover" as const },
    { name: "Miguel", src: miguel.url, fit: "cover" as const },
  ];
  const photoRow = [...clientPhotos, ...clientPhotos];
  const proofs = [
    { t: "Web", d: "Artist websites, EPKs, landing pages, campaign pages" },
    { t: "CRM", d: "Email capture, SMS systems, forms, follow-up flows" },
    { t: "Merch", d: "Shopify, product pages, checkout support, fan offers" },
    { t: "Growth", d: "Rollout strategy, analytics, fan data, owned audience" },
  ];
  return (
    <section className="surface-deep border-y border-border/60">
      <div data-anim="section" id="clients" className="relative z-10 mx-auto max-w-7xl px-6 sm:px-8 md:px-10 py-20 md:py-28">
      <div className="max-w-3xl">
        <SectionLabel number="03 //">PAST & CURRENT CLIENTS</SectionLabel>
        <h2 className="mt-4 font-display text-3xl sm:text-5xl md:text-6xl font-extrabold uppercase leading-[1.05] tracking-tight">
          Trusted across music, media, and <span className="text-gradient-primary">entertainment.</span>
        </h2>
        <div className="mt-4 h-0.5 w-16 bg-accent-muted" />
        <p className="mt-6 text-[15px] md:text-base text-muted-foreground leading-[1.7]">
          Experience across independent artists, labels, podcasts, distribution, creative teams, and major music activations.
        </p>
      </div>

      <div className="mt-12 relative overflow-hidden rounded-2xl border border-border bg-card/30">
        <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-16 md:w-24 bg-gradient-to-r from-background to-transparent" />
        <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-16 md:w-24 bg-gradient-to-l from-background to-transparent" />
        <div className="flex w-max animate-marquee gap-4 md:gap-5 py-5 md:py-6 px-4">
          {photoRow.map((c, i) => (
            <figure
              key={`${c.name}-${i}`}
              data-anim="client-photo"
              className="relative shrink-0 w-44 sm:w-52 md:w-64 aspect-[3/4] overflow-hidden rounded-xl md:rounded-2xl border border-border bg-secondary shadow-card-elevated group"
            >
              <ClientImage
                src={c.src}
                alt={`${c.name} — Mikewavs client`}
                className="h-full w-full"
              />
              <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-background/90 via-background/20 to-transparent" />
              <figcaption className="absolute inset-x-0 bottom-0 p-3 md:p-4">
                <span className="font-display text-[12px] md:text-sm font-bold uppercase tracking-tight text-foreground drop-shadow">
                  {c.name}
                </span>
              </figcaption>
            </figure>
          ))}
        </div>
      </div>

      <div className="mt-10 grid gap-5 md:gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {proofs.map((p) => (
          <article key={p.t} className="glass-card p-7 md:p-8 transition-all hover:border-primary/40 hover:-translate-y-1 hover:shadow-[0_10px_30px_-12px_rgba(129,65,247,0.4)]">
            <div className="font-mono text-[10px] md:text-[11px] uppercase tracking-[0.3em] text-accent-muted">{p.t}</div>
            <p className="mt-3 text-[14px] md:text-[15px] text-muted-foreground leading-[1.7]">{p.d}</p>
          </article>
        ))}
      </div>
      </div>
    </section>
  );
}