import { Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { services } from "@/lib/services-data";
import { SectionLabel } from "./SectionLabel";

export function Services() {
  return (
    <section className="surface-base">
      <div data-anim="section" id="services" className="relative z-10 mx-auto max-w-7xl px-6 sm:px-8 md:px-10 py-20 md:py-28">
      <div className="max-w-3xl">
        <SectionLabel number="02 //">Solutions</SectionLabel>
        <h2 className="mt-4 font-display text-3xl sm:text-4xl md:text-5xl font-extrabold uppercase leading-[1.05] tracking-tight">
          What I can build for your <span className="text-gradient-primary">music brand.</span>
        </h2>
        <p className="mt-6 text-[15px] md:text-base text-muted-foreground leading-[1.7]">
          These services are designed to help music teams stop relying only on attention and start building owned systems that support releases, fan growth, merch, data, and revenue.
        </p>
      </div>
      <div className="mt-12 grid gap-5 md:gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {services.map(({ n, slug, icon: Icon, t, d }) => (
          <Link
            key={n}
            to="/services/$slug"
            params={{ slug }}
            aria-label={`Learn more about ${t}`}
            data-anim="service-card"
            className="glass-card p-7 md:p-9 transition-all hover:border-primary/40 hover:-translate-y-1 hover:shadow-[0_10px_40px_-12px_rgba(129,65,247,0.45)] group relative overflow-hidden block"
          >
            <div className="relative">
              <div className="flex items-center justify-between">
                <div className="grid h-10 w-10 md:h-11 md:w-11 place-items-center rounded-xl bg-secondary border border-border text-primary group-hover:bg-gradient-primary group-hover:text-primary-foreground group-hover:border-transparent transition-all">
                  <Icon className="h-5 w-5" />
                </div>
                <span className="font-mono text-[10px] md:text-[11px] tracking-[0.3em] text-accent-muted bg-accent-muted/10 rounded-full px-2.5 py-1">{n}</span>
              </div>
              <h3 className="mt-5 font-display text-lg md:text-xl font-bold uppercase tracking-tight leading-snug">{t}</h3>
              <p className="mt-3 text-[14px] md:text-[15px] text-muted-foreground leading-[1.7]">{d}</p>
              <span className="mt-5 inline-flex items-center gap-1.5 font-mono text-[10px] md:text-[11px] uppercase tracking-[0.3em] text-accent-muted opacity-80 group-hover:gap-3 group-hover:opacity-100 transition-all">
                Learn more about {t} <ArrowRight className="h-3.5 w-3.5" />
              </span>
            </div>
          </Link>
        ))}
      </div>
      </div>
    </section>
  );
}