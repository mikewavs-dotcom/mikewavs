import { Link } from "@tanstack/react-router";
import { ArrowRight, Calendar, Sparkles } from "lucide-react";
import VinylHeroBackground from "@/components/VinylHeroBackground";

export function Hero() {
  return (
    <section className="surface-base relative overflow-hidden min-h-[88vh] flex items-center">
      <VinylHeroBackground />
      {/* Readability scrim — only on the left so the vinyl on the right stays visible */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-y-0 left-0 z-[1] w-full lg:w-[62%]"
        style={{
          background:
            "linear-gradient(90deg, rgba(13,11,7,0.92) 0%, rgba(13,11,7,0.78) 45%, rgba(13,11,7,0.35) 80%, rgba(13,11,7,0) 100%)",
        }}
      />
      <div id="top" className="relative z-10 w-full mx-auto max-w-7xl px-6 sm:px-8 md:px-10 pt-20 pb-20 md:pt-28 md:pb-28">
        <div className="max-w-2xl lg:max-w-[36rem]">
          <div className="inline-flex items-center gap-2 rounded-full border border-border bg-card/50 px-3 py-1 text-[11px] md:text-xs font-medium text-muted-foreground">
            <span className="h-1.5 w-1.5 rounded-full bg-primary animate-pulse-glow" />
            Digital Strategy &amp; Direct-To-Fan Growth
          </div>
          <h1 data-anim="hero-headline" className="mt-5 font-display text-[1.25rem] xs:text-[1.5rem] sm:text-4xl md:text-5xl lg:text-[3.25rem] xl:text-6xl font-extrabold uppercase leading-[1.05] tracking-tight [text-wrap:balance]">
            Build your system.<br />Grow your <span className="text-gradient-primary">fanbase.</span>
          </h1>
          <p data-anim="hero-sub" className="mt-6 max-w-xl text-[15px] md:text-base text-muted-foreground leading-[1.7]">
            Mikewavs helps artists, labels, managers, and music teams build direct-to-fan systems for music releases, fan data, websites, CRM, email/SMS, merch, and long-term audience growth.
          </p>
          <div data-anim="hero-sub" className="mt-7 flex flex-col sm:flex-row sm:flex-wrap gap-3">
            <a href="https://calendly.com/nocoolpoints/1-1-consultation?month=2026-06" className="inline-flex items-center justify-center gap-2 rounded-full bg-gradient-primary px-5 py-3 md:px-6 md:py-3.5 text-sm font-semibold text-primary-foreground transition-all hover:-translate-y-0.5 hover:scale-[1.02] hover:shadow-[0_0_32px_-6px_rgba(129,65,247,0.6)] glow-primary">
              <Calendar className="h-4 w-4" /> Book Consultation
            </a>
            <a href="#services" className="inline-flex items-center justify-center gap-2 rounded-full border-2 border-accent-muted/60 bg-transparent px-5 py-3 md:px-6 md:py-3.5 text-sm font-semibold text-foreground transition-all hover:bg-accent-muted/10 hover:-translate-y-0.5 hover:shadow-[0_0_24px_-8px_rgba(156,133,80,0.45)]">
              View Services <ArrowRight className="h-4 w-4" />
            </a>
            <Link to="/tools/music-rollout-builder" className="inline-flex items-center justify-center gap-2 rounded-full bg-primary/10 border border-primary/40 px-5 py-3 md:px-6 md:py-3.5 text-sm font-semibold text-primary transition-all hover:bg-primary/20 hover:-translate-y-0.5">
              <Sparkles className="h-4 w-4" /> Free Rollout Score
            </Link>
          </div>

          <div data-anim="hero-sub" className="mt-10 grid grid-cols-3 gap-4 sm:gap-6 border-t border-border/60 pt-6 max-w-lg">
            {[
              { n: "10+", l: "Years in digital strategy" },
              { n: "2014", l: "Started building in music" },
              { n: "2025", l: "Co-founded VA distribution" },
            ].map((s) => (
              <div key={s.n}>
                <div className="font-display text-lg sm:text-xl md:text-2xl font-extrabold text-gradient-primary">{s.n}</div>
                <div className="mt-1 font-mono text-[9px] md:text-[10px] uppercase tracking-[0.15em] text-muted-foreground leading-snug break-words">{s.l}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}