import { Calendar } from "lucide-react";
import { SectionLabel } from "./SectionLabel";

export function FinalCTA() {
  return (
    <section className="surface-deep border-y border-border/60">
      <div data-anim="section" className="relative z-10 mx-auto max-w-7xl px-6 sm:px-8 md:px-10 py-20 md:py-28">
      <div className="glass-card shadow-card-elevated relative overflow-hidden p-8 sm:p-12 md:p-16 text-center">
        <div className="relative">
          <div className="mx-auto mb-6 h-px w-24 bg-accent-muted" />
          <SectionLabel number="06 //">Mikewavs</SectionLabel>
          <h2 className="mt-4 mx-auto max-w-4xl font-display text-3xl sm:text-5xl md:text-6xl font-extrabold uppercase leading-[1.05] tracking-tight [text-wrap:balance]">
            Build your system, grow your fanbase, <span className="text-gradient-primary">monetize your audience.</span>
          </h2>
          <p className="mt-6 mx-auto max-w-2xl text-[15px] md:text-base text-muted-foreground leading-[1.7]">
            Whether you need a website, CRM, release campaign structure, merch setup, or a full direct-to-fan system, this is where the digital side of your music brand gets organized.
          </p>
          <a href="https://calendly.com/nocoolpoints/1-1-consultation?month=2026-06" className="mt-8 inline-flex items-center gap-2 rounded-full bg-gradient-primary px-6 py-3.5 md:px-7 md:py-4 text-sm md:text-base font-semibold text-primary-foreground transition-all hover:-translate-y-0.5 hover:scale-[1.02] hover:shadow-[0_0_36px_-6px_rgba(129,65,247,0.6)] glow-primary">
            <Calendar className="h-4 w-4" /> Book Consultation
          </a>
        </div>
      </div>
      </div>
    </section>
  );
}