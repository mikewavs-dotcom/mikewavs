import { useEffect } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

if (typeof window !== "undefined") {
  gsap.registerPlugin(ScrollTrigger);
}

const DEBUG =
  typeof window !== "undefined" &&
  (new URLSearchParams(window.location.search).has("debugAnim") ||
    import.meta.env?.DEV);
const log = (...args: unknown[]) => {
  if (DEBUG) console.log("[anim]", ...args);
};
const warn = (...args: unknown[]) => console.warn("[anim]", ...args);

export function useSiteAnimations() {
  useEffect(() => {
    if (typeof window === "undefined") return;
    const mql = window.matchMedia("(prefers-reduced-motion: reduce)");
    if (mql.matches) {
      log("prefers-reduced-motion active — skipping animations");
      return;
    }

    log("init", { gsap: gsap.version, scrollTrigger: !!ScrollTrigger });

    // Surface elements that never get revealed (opacity 0 stuck) after 3s.
    const stuckCheck = window.setTimeout(() => {
      const all = document.querySelectorAll<HTMLElement>(
        "[data-anim='section'],[data-anim='service-card'],[data-anim='client-photo'],[data-anim='hero-headline'],[data-anim='hero-sub']",
      );
      const stuck: { kind: string | null; rect: DOMRect }[] = [];
      all.forEach((el) => {
        const cs = getComputedStyle(el);
        if (parseFloat(cs.opacity) < 0.05 || cs.visibility === "hidden") {
          stuck.push({ kind: el.getAttribute("data-anim"), rect: el.getBoundingClientRect() });
        }
      });
      if (stuck.length) {
        warn(`${stuck.length} element(s) still hidden after 3s — forcing reveal`, stuck);
        all.forEach((el) => gsap.set(el, { clearProps: "opacity,visibility,transform" }));
        ScrollTrigger.refresh();
      } else {
        log("post-load check: all animated elements visible");
      }
    }, 3000);

    const ctx = gsap.context(() => {
      const counts = {
        nav: document.querySelectorAll("[data-anim='nav']").length,
        heroHeadline: document.querySelectorAll("[data-anim='hero-headline']").length,
        heroSub: document.querySelectorAll("[data-anim='hero-sub']").length,
        section: document.querySelectorAll("[data-anim='section']").length,
        serviceCard: document.querySelectorAll("[data-anim='service-card']").length,
        clientPhoto: document.querySelectorAll("[data-anim='client-photo']").length,
        glow: document.querySelectorAll("[data-anim='glow']").length,
      };
      log("selector counts", counts);
      Object.entries(counts).forEach(([k, v]) => {
        if (v === 0) warn(`no elements matched for [data-anim='${k}']`);
      });

      // Header fade-down
      gsap.from("[data-anim='nav']", {
        y: -16,
        opacity: 0,
        duration: 0.7,
        ease: "power3.out",
      });

      // Hero headline
      gsap.from("[data-anim='hero-headline']", {
        y: 26,
        opacity: 0,
        duration: 0.9,
        ease: "power3.out",
        delay: 0.1,
      });

      // Hero paragraph + CTA buttons (stagger)
      gsap.from("[data-anim='hero-sub']", {
        y: 18,
        opacity: 0,
        duration: 0.7,
        ease: "power3.out",
        delay: 0.35,
        stagger: 0.12,
      });

      // Helper: reveal each element independently so a single stuck trigger
      // can't leave content invisible.
      const revealEach = (
        selector: string,
        vars: gsap.TweenVars,
      ) => {
        const els = gsap.utils.toArray<HTMLElement>(selector);
        log(`revealEach ${selector} →`, els.length);
        els.forEach((el, idx) => {
          const tween = gsap.fromTo(
            el,
            { autoAlpha: 0, y: vars.y ?? 24, scale: vars.scale ?? 1 },
            {
              autoAlpha: 1,
              y: 0,
              scale: 1,
              duration: vars.duration ?? 0.7,
              ease: vars.ease ?? "power3.out",
              immediateRender: false,
              scrollTrigger: {
                trigger: el,
                start: "top 95%",
                toggleActions: "play none none none",
                onEnter: () => log(`enter ${selector}#${idx}`),
              },
            },
          );
          // Safety net: if the ScrollTrigger never fires within 4s of being
          // created, force the tween to play so content never stays hidden.
          window.setTimeout(() => {
            if (tween.progress() === 0) {
              warn(`forcing play for ${selector}#${idx} (ScrollTrigger never fired)`);
              tween.play();
            }
          }, 4000);
        });
      };

      revealEach("[data-anim='section']", { y: 28, duration: 0.9 });
      revealEach("[data-anim='service-card']", { y: 22, duration: 0.6 });
      revealEach("[data-anim='client-photo']", {
        y: 0,
        scale: 0.96,
        duration: 0.7,
        ease: "power2.out",
      });

      // Breathing glow on blue background elements
      gsap.utils.toArray<HTMLElement>("[data-anim='glow']").forEach((el, i) => {
        gsap.to(el, {
          opacity: "+=0.12",
          scale: 1.05,
          duration: 3.2 + (i % 4) * 0.45,
          ease: "sine.inOut",
          yoyo: true,
          repeat: -1,
          transformOrigin: "center center",
        });
      });

      // Recalculate positions after layout settles (deep-link / images loading).
      requestAnimationFrame(() => {
        ScrollTrigger.refresh();
        log("ScrollTrigger.refresh (raf)", ScrollTrigger.getAll().length, "triggers");
      });
      window.addEventListener(
        "load",
        () => {
          ScrollTrigger.refresh();
          log("ScrollTrigger.refresh (load)");
        },
        { once: true },
      );
    });

    return () => {
      window.clearTimeout(stuckCheck);
      ctx.revert();
    };
  }, []);
}