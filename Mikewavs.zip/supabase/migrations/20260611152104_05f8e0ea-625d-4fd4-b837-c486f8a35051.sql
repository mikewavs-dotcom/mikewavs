
SELECT cron.schedule(
  'prune-email-send-log',
  '0 3 * * *',
  $cron$
  DELETE FROM public.email_send_log
  WHERE created_at < now() - interval '90 days'
    AND status IN ('sent', 'suppressed', 'dlq');
  $cron$
);
