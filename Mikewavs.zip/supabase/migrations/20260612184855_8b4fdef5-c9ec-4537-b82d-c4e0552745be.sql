ALTER TABLE public.music_rollout_leads
  ADD COLUMN IF NOT EXISTS lead_status text NOT NULL DEFAULT 'New',
  ADD COLUMN IF NOT EXISTS notes text;

ALTER TABLE public.music_rollout_leads
  DROP CONSTRAINT IF EXISTS music_rollout_leads_lead_status_check;

ALTER TABLE public.music_rollout_leads
  ADD CONSTRAINT music_rollout_leads_lead_status_check
  CHECK (lead_status IN ('New','Reviewed','Hot Lead','Contacted','Booked','Not a Fit'));

CREATE INDEX IF NOT EXISTS music_rollout_leads_created_at_idx
  ON public.music_rollout_leads (created_at DESC);

DROP POLICY IF EXISTS "Admins can read leads" ON public.music_rollout_leads;
CREATE POLICY "Admins can read leads"
  ON public.music_rollout_leads
  FOR SELECT
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins can update leads" ON public.music_rollout_leads;
CREATE POLICY "Admins can update leads"
  ON public.music_rollout_leads
  FOR UPDATE
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));