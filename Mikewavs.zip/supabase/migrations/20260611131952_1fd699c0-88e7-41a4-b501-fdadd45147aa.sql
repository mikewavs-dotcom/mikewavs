CREATE TABLE public.blog_email_leads (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    email TEXT NOT NULL,
    source_post_slug TEXT,
    consent_status TEXT NOT NULL DEFAULT 'granted',
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

GRANT INSERT ON public.blog_email_leads TO anon;
GRANT INSERT, SELECT ON public.blog_email_leads TO authenticated;
GRANT ALL ON public.blog_email_leads TO service_role;

ALTER TABLE public.blog_email_leads ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can submit email leads"
ON public.blog_email_leads
FOR INSERT
TO anon, authenticated
WITH CHECK (true);

CREATE POLICY "Authenticated users can view email leads"
ON public.blog_email_leads
FOR SELECT
TO authenticated
USING (true);