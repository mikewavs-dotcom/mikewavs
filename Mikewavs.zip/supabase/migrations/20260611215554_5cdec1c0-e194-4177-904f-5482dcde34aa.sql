DO $$ BEGIN PERFORM pgmq.purge_queue('transactional_emails'); EXCEPTION WHEN OTHERS THEN NULL; END $$;
DO $$ BEGIN PERFORM pgmq.purge_queue('transactional_emails_dlq'); EXCEPTION WHEN OTHERS THEN NULL; END $$;

UPDATE public.email_send_log
SET status = 'dlq',
    error_message = 'Cleaned up during audit (queue purged, message never delivered)'
WHERE status = 'pending'
  AND created_at < now() - interval '1 hour';