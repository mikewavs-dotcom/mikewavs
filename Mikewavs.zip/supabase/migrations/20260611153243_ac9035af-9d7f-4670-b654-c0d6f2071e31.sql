CREATE OR REPLACE FUNCTION public.rotate_queue_processor_secret(_new_secret text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, vault, pg_temp
AS $$
DECLARE
  v_id uuid;
BEGIN
  IF _new_secret IS NULL OR length(_new_secret) < 32 THEN
    RAISE EXCEPTION 'Secret must be at least 32 characters';
  END IF;

  SELECT id INTO v_id FROM vault.secrets WHERE name = 'email_queue_processor_secret';

  IF v_id IS NULL THEN
    PERFORM vault.create_secret(_new_secret, 'email_queue_processor_secret',
      'Shared secret used by pg_cron to authenticate to /lovable/email/queue/process');
  ELSE
    PERFORM vault.update_secret(v_id, _new_secret);
  END IF;
END;
$$;

REVOKE ALL ON FUNCTION public.rotate_queue_processor_secret(text) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.rotate_queue_processor_secret(text) FROM anon, authenticated;
GRANT EXECUTE ON FUNCTION public.rotate_queue_processor_secret(text) TO service_role;