CREATE OR REPLACE FUNCTION public.check_contact_rate_limit(
  _ip_hash TEXT,
  _email   TEXT
) RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  ip_count   INT;
  email_count INT;
  normalized_ip TEXT := NULLIF(_ip_hash, '');
BEGIN
  IF normalized_ip IS NOT NULL THEN
    SELECT count(*) INTO ip_count
    FROM public.contact_inquiries
    WHERE ip_hash = normalized_ip
      AND created_at > now() - interval '1 hour';
    IF ip_count >= 3 THEN
      RETURN 'ip_hourly';
    END IF;
  END IF;

  SELECT count(*) INTO email_count
  FROM public.contact_inquiries
  WHERE lower(email) = lower(_email)
    AND created_at > now() - interval '24 hours';
  IF email_count >= 5 THEN
    RETURN 'email_daily';
  END IF;

  RETURN NULL;
END;
$$;