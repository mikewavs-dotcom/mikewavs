
-- Store the dedicated queue processor secret in Vault.
-- Value mirrors the QUEUE_PROCESSOR_SECRET runtime env var the route validates against.
DO $$
DECLARE
  v_secret text := '5159635735d7f9b59a629f364df790b27f1b54767dec45377810c6f37d3dc3b2';
BEGIN
  IF EXISTS (SELECT 1 FROM vault.secrets WHERE name = 'email_queue_processor_secret') THEN
    PERFORM vault.update_secret(
      (SELECT id FROM vault.secrets WHERE name = 'email_queue_processor_secret'),
      v_secret,
      'email_queue_processor_secret'
    );
  ELSE
    PERFORM vault.create_secret(v_secret, 'email_queue_processor_secret');
  END IF;
END $$;

-- Reschedule the cron job to send the queue-processor secret as the Bearer token.
SELECT cron.unschedule('process-email-queue');

SELECT cron.schedule(
  'process-email-queue',
  '5 seconds',
  $cron$
  SELECT CASE
    WHEN (SELECT retry_after_until FROM public.email_send_state WHERE id = 1) > now()
      THEN NULL
    WHEN EXISTS (SELECT 1 FROM pgmq.q_auth_emails LIMIT 1)
      OR EXISTS (SELECT 1 FROM pgmq.q_transactional_emails LIMIT 1)
      THEN net.http_post(
        url := 'https://id-preview--6d96f9f5-a788-4771-bfc0-20724e68242d.lovable.app/lovable/email/queue/process',
        headers := jsonb_build_object(
          'Content-Type', 'application/json',
          'Authorization', 'Bearer ' || (
            SELECT decrypted_secret FROM vault.decrypted_secrets
            WHERE name = 'email_queue_processor_secret'
          )
        ),
        body := '{}'::jsonb
      )
    ELSE NULL
  END;
  $cron$
);
