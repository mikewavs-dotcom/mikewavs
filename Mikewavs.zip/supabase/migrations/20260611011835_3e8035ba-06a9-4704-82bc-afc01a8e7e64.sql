-- Add ip_hash column for rate limiting and a SECURITY DEFINER helper to check throttle.
ALTER TABLE public.contact_inquiries
  ADD COLUMN IF NOT EXISTS ip_hash TEXT;

CREATE INDEX IF NOT EXISTS contact_inquiries_ip_hash_created_at_idx
  ON public.contact_inquiries (ip_hash, created_at DESC);

CREATE INDEX IF NOT EXISTS contact_inquiries_email_created_at_idx
  ON public.contact_inquiries (lower(email), created_at DESC);

-- Returns null if allowed, else a short reason string.
CREATE OR REPLACE FUNCTION public.check_contact_rate_limit(
  _ip_hash TEXT,
  _email   TEXT
) RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  ip_count   INT;
  email_count INT;
BEGIN
  IF _ip_hash IS NOT NULL THEN
    SELECT count(*) INTO ip_count
    FROM public.contact_inquiries
    WHERE ip_hash = _ip_hash
      AND created_at > now() - interval '1 hour';
    IF ip_count >= 3 THEN
      RETURN 'ip_hourly';
    END IF;
  END IF;

  SELECT count(*) INTO email_count
  FROM public.contact_inquiries
  WHERE lower(email) = lower(_email)
    AND created_at > now() - interval '24 hours';
  IF email_count >= 5 THEN
    RETURN 'email_daily';
  END IF;

  RETURN NULL;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.check_contact_rate_limit(TEXT, TEXT) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.check_contact_rate_limit(TEXT, TEXT) TO service_role;