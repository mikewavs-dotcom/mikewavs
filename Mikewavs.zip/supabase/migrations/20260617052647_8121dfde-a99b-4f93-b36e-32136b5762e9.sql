
REVOKE EXECUTE ON FUNCTION public.check_rollout_rate_limit(text, text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.check_rollout_rate_limit(text, text) TO service_role;
