DROP POLICY IF EXISTS "Anyone can submit a rollout lead" ON public.music_rollout_leads;

CREATE POLICY "Anyone can submit a valid rollout lead"
  ON public.music_rollout_leads
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (
    length(btrim(name)) > 0
    AND length(btrim(email)) BETWEEN 3 AND 255
    AND email LIKE '%_@_%.__%'
    AND score >= 0
    AND score <= 100
  );