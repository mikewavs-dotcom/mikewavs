
ALTER TABLE public.music_rollout_leads ADD COLUMN IF NOT EXISTS ip_hash text;
CREATE INDEX IF NOT EXISTS music_rollout_leads_ip_hash_created_at_idx
  ON public.music_rollout_leads (ip_hash, created_at DESC);
CREATE INDEX IF NOT EXISTS music_rollout_leads_email_lower_created_at_idx
  ON public.music_rollout_leads (lower(email), created_at DESC);

CREATE OR REPLACE FUNCTION public.check_rollout_rate_limit(_ip_hash text, _email text)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public', 'pg_temp'
AS $function$
DECLARE
  ip_count    INT;
  email_count INT;
  normalized_ip TEXT := NULLIF(_ip_hash, '');
BEGIN
  IF normalized_ip IS NOT NULL THEN
    SELECT count(*) INTO ip_count
    FROM public.music_rollout_leads
    WHERE ip_hash = normalized_ip
      AND created_at > now() - interval '1 hour';
    IF ip_count >= 3 THEN
      RETURN 'ip_hourly';
    END IF;
  END IF;

  SELECT count(*) INTO email_count
  FROM public.music_rollout_leads
  WHERE lower(email) = lower(_email)
    AND created_at > now() - interval '24 hours';
  IF email_count >= 5 THEN
    RETURN 'email_daily';
  END IF;

  RETURN NULL;
END;
$function$;
