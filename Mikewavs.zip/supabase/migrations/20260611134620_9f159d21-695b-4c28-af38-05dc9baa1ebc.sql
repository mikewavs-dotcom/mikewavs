
-- Restrict SELECT on blog_email_leads to service_role only
DROP POLICY IF EXISTS "Authenticated users can view email leads" ON public.blog_email_leads;
REVOKE SELECT ON public.blog_email_leads FROM authenticated;

CREATE POLICY "Service role can read email leads"
  ON public.blog_email_leads
  FOR SELECT
  TO public
  USING (auth.role() = 'service_role');

-- Tighten INSERT policy: replace WITH CHECK (true) with input validation
DROP POLICY IF EXISTS "Anyone can submit email leads" ON public.blog_email_leads;

CREATE POLICY "Anyone can submit email leads"
  ON public.blog_email_leads
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (
    length(COALESCE(email, '')) BETWEEN 3 AND 320
    AND POSITION('@' IN email) > 1
    AND length(COALESCE(source_post_slug, '')) <= 200
    AND consent_status IN ('granted','pending','revoked')
  );
