
-- Lock down SECURITY DEFINER queue helper functions: set explicit search_path
-- and restrict execute to service_role only (the queue processor uses service role).
ALTER FUNCTION public.read_email_batch(text, integer, integer) SET search_path = public, pg_temp;
ALTER FUNCTION public.delete_email(text, bigint) SET search_path = public, pg_temp;
ALTER FUNCTION public.enqueue_email(text, jsonb) SET search_path = public, pg_temp;
ALTER FUNCTION public.move_to_dlq(text, text, bigint, jsonb) SET search_path = public, pg_temp;

REVOKE ALL ON FUNCTION public.read_email_batch(text, integer, integer) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.delete_email(text, bigint) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.enqueue_email(text, jsonb) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.move_to_dlq(text, text, bigint, jsonb) FROM PUBLIC, anon, authenticated;

GRANT EXECUTE ON FUNCTION public.read_email_batch(text, integer, integer) TO service_role;
GRANT EXECUTE ON FUNCTION public.delete_email(text, bigint) TO service_role;
GRANT EXECUTE ON FUNCTION public.enqueue_email(text, jsonb) TO service_role;
GRANT EXECUTE ON FUNCTION public.move_to_dlq(text, text, bigint, jsonb) TO service_role;

-- Tighten the contact inquiry insert policy: replace WITH CHECK (true) with
-- basic shape validation so the policy isn't unconditionally permissive.
DROP POLICY IF EXISTS "Anyone can submit an inquiry" ON public.contact_inquiries;
CREATE POLICY "Anyone can submit an inquiry"
  ON public.contact_inquiries
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (
    length(coalesce(name, '')) BETWEEN 1 AND 200
    AND length(coalesce(email, '')) BETWEEN 3 AND 320
    AND position('@' in email) > 1
    AND length(coalesce(goals, '')) BETWEEN 1 AND 5000
    AND length(coalesce(company, '')) <= 200
    AND length(coalesce(role, '')) <= 200
    AND length(coalesce(phone, '')) <= 50
    AND length(coalesce(website, '')) <= 500
    AND length(coalesce(socials, '')) <= 1000
    AND length(coalesce(budget, '')) <= 100
    AND length(coalesce(timeline, '')) <= 100
    AND length(coalesce(current_situation, '')) <= 5000
    AND length(coalesce(additional_info, '')) <= 5000
    AND length(coalesce(service_slug, '')) <= 100
    AND length(coalesce(service_name, '')) <= 200
  );
