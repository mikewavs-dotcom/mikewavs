
CREATE INDEX IF NOT EXISTS email_subscribers_ip_hash_created_at_idx
  ON public.email_subscribers (ip_hash, created_at DESC);
CREATE INDEX IF NOT EXISTS email_subscribers_email_lower_created_at_idx
  ON public.email_subscribers (lower(email), created_at DESC);

CREATE OR REPLACE FUNCTION public.check_subscriber_rate_limit(_ip_hash text, _email text)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public', 'pg_temp'
AS $function$
DECLARE
  ip_count    INT;
  email_count INT;
  normalized_ip TEXT := NULLIF(_ip_hash, '');
BEGIN
  IF normalized_ip IS NOT NULL THEN
    SELECT count(*) INTO ip_count
    FROM public.email_subscribers
    WHERE ip_hash = normalized_ip
      AND created_at > now() - interval '1 hour';
    IF ip_count >= 3 THEN
      RETURN 'ip_hourly';
    END IF;
  END IF;

  SELECT count(*) INTO email_count
  FROM public.email_subscribers
  WHERE lower(email) = lower(_email)
    AND created_at > now() - interval '24 hours';
  IF email_count >= 5 THEN
    RETURN 'email_daily';
  END IF;

  RETURN NULL;
END;
$function$;

REVOKE EXECUTE ON FUNCTION public.check_subscriber_rate_limit(text, text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.check_subscriber_rate_limit(text, text) TO service_role;
