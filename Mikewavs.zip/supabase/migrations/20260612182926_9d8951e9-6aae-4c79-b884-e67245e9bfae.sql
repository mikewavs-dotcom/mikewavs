CREATE TABLE public.music_rollout_leads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz NOT NULL DEFAULT now(),
  name text NOT NULL,
  email text NOT NULL,
  artist_company_name text,
  role text,
  release_type text,
  release_date date,
  main_goal text,
  score int NOT NULL,
  score_category text NOT NULL,
  has_website boolean NOT NULL DEFAULT false,
  has_email_capture boolean NOT NULL DEFAULT false,
  has_sms_capture boolean NOT NULL DEFAULT false,
  has_crm boolean NOT NULL DEFAULT false,
  has_merch boolean NOT NULL DEFAULT false,
  has_content_plan boolean NOT NULL DEFAULT false,
  has_smart_link boolean NOT NULL DEFAULT false,
  has_tracking boolean NOT NULL DEFAULT false,
  has_post_release_plan boolean NOT NULL DEFAULT false,
  missing_items text[] NOT NULL DEFAULT '{}',
  recommended_services text[] NOT NULL DEFAULT '{}'
);

GRANT INSERT ON public.music_rollout_leads TO anon, authenticated;
GRANT ALL ON public.music_rollout_leads TO service_role;

ALTER TABLE public.music_rollout_leads ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can submit a rollout lead"
  ON public.music_rollout_leads
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);